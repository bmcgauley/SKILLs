---
name: mba-case-study-analyzer
description: Specialized skill for conducting rigorous MBA-level case study analysis using a systematic three-column draw.io diagram methodology. This skill should be used when users request case study analysis, case study diagrams, or mention conducting a case study using the established analytical framework. Produces professional diagrams that map Events/Issues → Objectives/Actions → Business Impacts with precise chronological and logical flow.
license: MIT
---

# MBA Case Study Analyzer

## Overview

This skill implements a rigorous, systematic methodology for conducting MBA-level case studies using draw.io diagrams. The approach transforms complex business cases into structured visual analyses that reveal cause-and-effect relationships, strategic decision-making patterns, and business outcomes.

The methodology uses a three-column analytical framework that maps:
1. **Events Occurring / Issues Faced** → 
2. **Objectives Pursued / Actions Taken** → 
3. **Business Impacts of Actions**

## When to Use This Skill

Trigger this skill when users:
- Request a case study analysis
- Ask to "do a case study" or "analyze this case"
- Reference conducting case study analysis using the three-column methodology
- Upload case study materials and request diagram creation
- Mention creating a case study diagram or visualization

## Core Principles

### Analytical Framework
- **Evidence-based analysis**: Every diagram element must trace directly to case study source material
- **Chronological integrity**: Maintain temporal sequence in left and right columns
- **Logical hierarchy**: Middle column flows from broad objectives (top) to specific actions (bottom)
- **Complete connectivity**: No isolated elements—every item connects to the broader analytical flow
- **Visual clarity**: Perfect alignment and spacing enable immediate comprehension

### Execution Standards
- **Minimal text output**: Acknowledge task receipt, ask only essential clarifying questions, deliver final diagram
- **Internal organization**: Use mental scratch pad for organizing case elements before diagram creation
- **Single deliverable**: Final output is the draw.io diagram link only, with brief completion acknowledgment
- **Zero intermediate artifacts**: Do not show working notes, organizational steps, or process details to user

## Workflow Process

### Phase 1: Case Study Analysis and Organization

#### Step 1: Comprehend Case Materials
- Read or re-evaluate the complete case study thoroughly
- Identify all key events, decisions, actions, and outcomes
- Note temporal sequence and causal relationships
- Extract specific data points, metrics, and concrete details

#### Step 2: Organize Events (Column 1 Preparation)
Mentally catalog all events and issues in strict chronological order:
- **Format**: Bold one-line title + supporting details
- **Sequencing**: Earliest event at top, latest at bottom
- **Granularity**: Include all significant events that drive subsequent actions
- **Source fidelity**: Use only information explicitly stated in case study

#### Step 3: Map Objectives and Actions (Column 2 Preparation)
Create objective-action pairs following this structure:
- **Objective ("To" statement)**:
  - Begins with "To" followed by infinitive verb phrase
  - Describes strategic goal or purpose
  - Example: "To modernize digital capabilities"
  - **Bold formatting** for these statements
  - Connect horizontally FROM events in Column 1
  
- **Action statement**:
  - Direct verb phrase describing specific action taken
  - Includes concrete details from case (investments, personnel, initiatives)
  - Example: "Invest $200M in technology and add 500 IT personnel"
  - Regular formatting (not bold)
  - Connects vertically DOWN from its objective
  - Connects horizontally TO outcomes in Column 3

**Critical Middle Column Logic**:
- Forms a vertical "ladder" readable both upward and downward
- Broad objectives at top → Specific actions at bottom (when chronology allows)
- Each objective can have multiple actions
- Actions can ladder up through multiple objectives
- Vertical arrows show how/why relationships (action → objective above it)
- Horizontal arrows show means-ends relationships (event → objective, action → impact)

#### Step 4: Identify Business Impacts (Column 3 Preparation)
For each action, determine the resulting business impact:
- **Format**: Bold one-line title + outcome details
- **Evidence**: Must directly result from the linked action
- **Specificity**: Include metrics, market position changes, competitive effects
- **Failure notation**: Use minimal red coloring for negative outcomes only
- **Sequencing**: Chronological progression top to bottom
- **Final outcome**: Last item represents case study's culminating result

#### Step 5: Craft Summary Statement
Develop a single, concise sentence that captures the entire case essence:
- **Scope**: Synthesizes the complete case narrative
- **Style**: Clear, professional, human-readable (use human-writing skill if available)
- **Length**: One sentence maximum
- **Specificity**: Conveys core insight without excessive detail
- **Placement**: Full-width rectangle at diagram bottom

### Phase 2: Draw.io Diagram Construction

#### Initial Setup

**Step 1: Create Base Diagram**
Use the draw.io MCP to create the foundational structure:
```
Title: [Appropriate case study title]
Type: Custom/Flowchart hybrid
Canvas: Standard dimensions with adequate space for content
```

**Step 2: Establish Column Headers**
Create three equally-spaced headers spanning full diagram width:
- **Mathematics**: Divide total width by 3 for equal column widths
- **Left Header**: "Events Occurring / Issues Faced"
- **Middle Header**: "Objectives Pursued / Actions Taken"
- **Right Header**: "Business Impacts of Actions"
- **Formatting**: Bold, centered within each column section
- **Positioning**: Top of diagram with adequate vertical spacing

**Step 3: Create Header Separator**
Draw a solid black horizontal line:
- **Span**: 100% of diagram width
- **Position**: Directly beneath all three headers
- **Style**: Solid, black, standard weight
- **Purpose**: Visually separates headers from analytical content

**Step 4: Create Column Dividers**
Draw two vertical dashed lines:
- **Position 1**: Midpoint between columns 1 and 2
- **Position 2**: Midpoint between columns 2 and 3
- **Style**: Dashed, dark grey
- **Span**: From header separator to summary rectangle
- **Mathematics**: Precise calculations for equal spacing

#### Content Population

**Standard Measurement System**:
- Establish consistent unit increments (e.g., 20px, 40px, 60px)
- Use evenly divisible numbers throughout
- Ensure all shapes use standard dimensions
- Calculate positions mathematically for perfect alignment

**Column 1: Events and Issues**

For each event in chronological order:
1. **Create rectangle shape**:
   - **Position**: Left column, maintaining vertical spacing standards
   - **Width**: Column width minus margins
   - **Content**: Bold title line + supporting details
   - **Color**: White background, black border (red border only for critical failures)

2. **Connect to next event**:
   - **Arrow type**: Downward pointing
   - **Style**: Solid black
   - **Logic**: Shows chronological progression
   - **Source**: Bottom of current event
   - **Target**: Top of next event

**Column 2: Objectives and Actions**

For each objective-action pair:
1. **Create "To" statement rectangle**:
   - **Position**: Vertically aligned with triggering event from Column 1
   - **Content**: "To [objective]" in **bold**
   - **Color**: White background, black border
   
2. **Create action statement rectangle**:
   - **Position**: Directly below "To" statement (standard spacing)
   - **Content**: Action description in regular text
   - **Color**: White background, black border

3. **Vertical connections within Column 2**:
   - **Connect**: "To" statement → Action statement (downward arrow)
   - **Connect**: Action statement → Next "To" statement (downward arrow)
   - **Logic**: Creates vertical ladder showing increasing specificity

4. **Horizontal connections**:
   - **Inbound**: Arrow FROM Column 1 event → "To" statement
   - **Outbound**: Arrow FROM action statement → Column 3 impact

**Column 3: Business Impacts**

For each business impact:
1. **Create rectangle shape**:
   - **Position**: Horizontally aligned with source action from Column 2
   - **Content**: Bold title line + impact details
   - **Color**: White background, black border (red text for negative impacts)

2. **Connect to next impact**:
   - **Arrow type**: Downward pointing
   - **Style**: Solid black
   - **Logic**: Shows progression of business effects
   - **Source**: Bottom of current impact
   - **Target**: Top of next impact

**Summary Rectangle**:
1. **Create full-width rectangle**:
   - **Width**: 100% of diagram width
   - **Position**: Below all column content with standard spacing
   - **Content**: Single synthesizing sentence
   - **Integration**: Vertical dashed lines connect to top edge

#### Alignment and Spacing Requirements

**CRITICAL: Perfect Alignment**

**Vertical Alignment**:
- Items in Column 2 must align EXACTLY with their source items in Column 1
- Items in Column 3 must align EXACTLY with their source actions in Column 2
- Use consistent Y-coordinates for horizontally-connected elements

**Horizontal Alignment**:
- All items within a column must align to column boundaries
- Shapes must be centered within their respective columns
- Margins must be consistent on both sides of each column

**Spacing Standards**:
- **Vertical gaps**: Column 1 may have gaps waiting for Column 2 items to align
- **Vertical gaps**: Column 3 may start lower, waiting for first action alignment
- **Rationale**: Horizontal alignment takes precedence over continuous vertical flow
- **Result**: Some vertical white space is acceptable and necessary for readability

**Mathematical Precision**:
- Calculate exact positions for all elements
- Use standard increments consistently (e.g., all Y-positions divisible by 20)
- Verify alignment before creating connections
- Test that horizontal lines are truly horizontal (same Y-coordinate)

### Phase 3: Connection Validation

**Connectivity Requirements**:

**Column 1 Connections**:
- ✅ All events connect downward to next event (except last)
- ✅ Events connect horizontally to at least one "To" statement in Column 2
- ❌ No isolated events without downstream connections

**Column 2 Connections**:
- ✅ Each "To" statement connects horizontally FROM at least one Column 1 event
- ✅ Each "To" statement connects vertically DOWN to at least one action
- ✅ Each action connects vertically UP from a "To" statement
- ✅ Each action connects horizontally TO at least one Column 3 impact
- ✅ Actions connect vertically DOWN to next "To" statement (forming ladder)
- ❌ No isolated objectives or actions

**Column 3 Connections**:
- ✅ Each impact connects horizontally FROM at least one Column 2 action
- ✅ Impacts connect downward to next impact (except last)
- ✅ Final impact connects downward to summary rectangle
- ❌ No isolated impacts

**Cardinality Notes**:
- **One-to-many**: Single Column 1 event may connect to multiple "To" statements
- **One-to-many**: Single "To" statement may connect to multiple actions
- **One-to-one**: Each action connects to exactly one primary impact (though impacts may accumulate from multiple actions)
- **Many-to-one**: Multiple impacts may contribute to final outcome

### Phase 4: Styling and Formatting

**Color Scheme**:
- **Primary**: White backgrounds, black borders and text
- **Failure indication**: Red used minimally and only for failure case items
- **Consistency**: Avoid introducing additional colors unless absolutely necessary
- **Professionalism**: Clean, academic aesthetic

**Text Formatting**:
- **Column 1**: Bold for one-line event titles
- **Column 2**: Bold ONLY for "To" statements (objectives)
- **Column 3**: Bold for one-line impact titles
- **Details**: Regular text for all supporting details
- **Summary**: Regular text for synthesizing statement

**Shape Styling**:
- **Type**: Rectangles (rounded rectangles acceptable)
- **Consistency**: Same shape type throughout
- **Sizing**: Adequate for content without excessive whitespace
- **Borders**: Consistent weight throughout diagram

### Phase 5: Final Delivery

**User Communication Protocol**:

**Initial Response** (upon receiving case study request):
```
Acknowledged. Conducting case study analysis using three-column methodology.
[Ask only ESSENTIAL clarifying questions if case details are ambiguous]
```

**During Processing**:
- **Silent execution**: No status updates or intermediate outputs
- **Internal organization**: Use mental scratch pad—do not share with user
- **Focus**: Maintain concentration on case analysis and diagram accuracy

**Final Delivery**:
```
Case study analysis complete.

[draw.io diagram link]
```

**No Additional Content**:
- ❌ Do not explain the methodology
- ❌ Do not describe what was done
- ❌ Do not provide summary of findings (summary is IN the diagram)
- ❌ Do not offer additional analysis or insights
- ✅ Provide only: Brief acknowledgment + diagram link

## Quality Assurance Checklist

Before delivering the final diagram, verify:

**Content Accuracy**:
- [ ] All events sourced directly from case study
- [ ] All objectives reflect actual strategic goals from case
- [ ] All actions include specific details from case
- [ ] All impacts accurately reflect business outcomes
- [ ] No invented or assumed information

**Structural Integrity**:
- [ ] Three columns properly established with headers
- [ ] Header separator and column dividers correctly placed
- [ ] All elements positioned within correct columns
- [ ] Summary rectangle spans full width

**Alignment Precision**:
- [ ] Horizontally-connected items share same Y-coordinate
- [ ] All items within columns aligned to column boundaries
- [ ] Consistent spacing using standard increments
- [ ] No misaligned connections or floating elements

**Connectivity Completeness**:
- [ ] Zero isolated elements (no islands)
- [ ] All Column 1 events connect downward and to Column 2
- [ ] All Column 2 "To" statements connect to events and actions
- [ ] All Column 2 actions connect to "To" statements and impacts
- [ ] All Column 3 impacts connect from actions and downward
- [ ] Summary rectangle connects to final impact

**Visual Clarity**:
- [ ] Bold formatting applied correctly (titles and "To" statements only)
- [ ] Color scheme limited to white/black (minimal red for failures)
- [ ] Arrow directions clearly indicate flow
- [ ] Text readable and appropriately sized
- [ ] Professional aesthetic suitable for MBA-level work

**Logical Flow**:
- [ ] Column 1 follows chronological sequence
- [ ] Column 2 shows broad-to-specific progression (when possible)
- [ ] Column 3 demonstrates cumulative business impacts
- [ ] Vertical arrows show how/why relationships
- [ ] Horizontal arrows show cause-effect relationships

## Tool Integration

**Primary Tool**:
- **draw.io MCP**: Use for all diagram creation and manipulation
- **Capabilities**: Shape creation, connection drawing, positioning, styling
- **Output**: XML-based diagram files that open in draw.io web interface

**Supporting Skills**:
- **human-writing**: Apply when crafting summary statement for natural, professional tone
- **project-knowledge-search**: Reference when case study materials are in project knowledge
- **Additional MCP servers**: Utilize as needed for case study processing

## Advanced Considerations

**Complex Cases**:
- **Multiple decision points**: May require multiple objective-action chains in Column 2
- **Concurrent events**: Align horizontally when events occur simultaneously
- **Long-term impacts**: May require extended vertical space in Column 3
- **Iterative decisions**: Show cycles using feedback arrows when case demonstrates iteration

**Edge Cases**:
- **Sparse Column 3**: Some actions may not have immediate observable impacts—include "Outcome pending" or similar notation
- **Dense Column 2**: Multiple actions addressing single objective—stack vertically under that objective
- **Ambiguous causality**: When case doesn't clearly link action to impact, use dotted lines to indicate uncertainty

**Scaling**:
- **Brief cases**: Adjust canvas size to avoid excessive whitespace
- **Extensive cases**: Extend canvas vertically, maintain standard column widths
- **Complex cases**: Consider splitting into multiple diagrams if single diagram becomes unwieldy (rare)

## Success Criteria

A successfully completed case study diagram demonstrates:

1. **Analytical rigor**: Every element traceable to case source material
2. **Structural precision**: Perfect adherence to three-column methodology
3. **Visual excellence**: Professional appearance suitable for MBA coursework
4. **Logical clarity**: Immediate comprehension of cause-effect relationships
5. **Complete connectivity**: Zero isolated elements, all relationships shown
6. **Alignment perfection**: Horizontally-connected items precisely aligned
7. **Appropriate synthesis**: Summary statement captures case essence concisely

The diagram should enable any MBA professor or business professional to immediately understand:
- What events occurred and what issues the organization faced
- What strategic objectives were pursued in response
- What concrete actions were taken to achieve those objectives
- What business impacts resulted from those actions
- What the overall case demonstrates about business decision-making

## Final Notes

This methodology transforms complex business narratives into structured analytical frameworks that reveal strategic decision-making patterns and organizational responses to challenges. The discipline of fitting case materials into this three-column structure forces rigorous analysis and clear articulation of cause-and-effect relationships.

The visual format makes the analysis immediately accessible while the structured approach ensures intellectual rigor. This combination makes the methodology particularly valuable for MBA-level coursework where both analytical depth and professional presentation are essential.

Remember: The skill's power lies in its systematic execution. Every case study, regardless of complexity, follows the same fundamental structure. Mastery comes from disciplined application of these principles, not from shortcuts or compromises.

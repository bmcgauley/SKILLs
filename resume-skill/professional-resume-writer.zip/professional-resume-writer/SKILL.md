---
name: professional-resume-writer
description: Comprehensive guide for crafting ATS-optimized, professional resumes and cover letters. Use when users need help creating, updating, or improving job application documents including resumes, CVs, cover letters, or need guidance on professional writing style, formatting, and content strategy for job applications.
---

# Professional Resume and Cover Letter Writer

Comprehensive toolkit for creating professional, ATS-optimized resumes and cover letters that pass automated screening and impress human recruiters. This skill provides expert guidance on formatting, content strategy, professional language, and industry best practices for 2025.

## When to Use This Skill

Activate this skill when users request help with:
- Creating a resume or CV from scratch
- Updating or improving an existing resume
- Writing a cover letter for a job application
- Optimizing documents for Applicant Tracking Systems (ATS)
- Improving professional writing style and language
- Formatting job application documents professionally
- Tailoring application materials to specific jobs or industries
- Understanding resume/cover letter best practices
- Quantifying achievements and using the STAR method
- Selecting appropriate action verbs and power words

## Core Principles

All resume and cover letter writing follows these fundamental principles:

1. **ATS Optimization First**: Documents must pass automated screening before reaching humans
2. **Quantification**: Use metrics and numbers to demonstrate impact and value
3. **Customization**: Tailor each document to the specific job and company
4. **Professional Presentation**: Clean, scannable, error-free formatting
5. **Results-Focused**: Emphasize outcomes and achievements, not just responsibilities
6. **Keyword Integration**: Match job description language naturally throughout content
7. **Authentic Voice**: Maintain professional tone while showing personality

## Resume Creation Workflow

### Step 1: Gather Information

Before creating a resume, collect:
- Job description(s) for target position(s)
- Work history (companies, titles, dates, responsibilities, achievements)
- Education (degrees, institutions, dates, honors, relevant coursework)
- Skills (technical, soft, certifications, languages)
- Notable achievements with quantifiable results
- Industry or field of work
- Career level (entry-level, mid-career, senior, executive)

### Step 2: Select Resume Format and Structure

**Default to Reverse Chronological Format** (most ATS-friendly):
- Contact information header
- Professional summary (3-4 lines)
- Work experience (most recent first, with 3-5 achievement bullets each)
- Education
- Skills
- Optional sections (certifications, publications, volunteer work)

**ATS-Compatible Formatting Requirements**:
- Use DOCX format (or PDF if specified in job posting)
- Standard fonts: Arial, Calibri, Helvetica, Times New Roman (10-12pt)
- Single-column layout (most reliable) or carefully designed two-column
- Standard section headers: "Professional Summary," "Work Experience," "Education," "Skills"
- Simple bullet points (•, ○, ■)
- 1-inch margins
- No images, graphics, tables, text boxes, or headers/footers with critical info

### Step 3: Craft Content Using STAR Method

For each work experience entry, create 3-5 bullets using action verbs and quantified results.

**Consult** `references/action-verbs.md` to select strong, varied action verbs.
**Consult** `references/star-examples.md` for industry-specific examples and formatting templates.

**STAR Method Structure**:
- **S**ituation: Context or challenge (often implicit)
- **T**ask: Your responsibility (often implicit)
- **A**ction: What you did (start with action verb)
- **R**esult: Measurable outcome (include metrics)

**Example Formats**:
- Action-Result: "Implemented automated testing framework, reducing bug detection time by 60%"
- Result-Action: "Increased quarterly sales by 145% by implementing data-driven prospecting strategy"
- Compact: "Overhauled content strategy to address declining traffic, increasing visits by 250%"

**Key Metrics to Include**:
- Financial: Revenue, cost savings, ROI percentages, budget managed
- Performance: Percentage improvements, time saved, efficiency gains
- Scale: Number of users, customers, team size, projects completed
- Comparison: Before vs. after, target vs. actual, you vs. team average

### Step 4: Optimize for ATS

**Consult** `references/ats-guidelines.md` for comprehensive ATS optimization strategies.

**Critical ATS Checklist**:
- [ ] Extract keywords from job description (skills, technologies, qualifications)
- [ ] Integrate keywords naturally throughout resume (summary, experience, skills)
- [ ] Use standard section headings ATS recognizes
- [ ] Include exact terminology from job posting (not synonyms)
- [ ] Avoid images, graphics, complex formatting
- [ ] Test readability by copying into plain text editor
- [ ] Target 75-85% keyword match (not 100% = over-optimized)
- [ ] Save with professional filename: FirstName_LastName_Resume.pdf

### Step 5: Polish and Proofread

- Review for spelling and grammar errors (zero tolerance)
- Ensure consistent formatting throughout
- Verify dates, companies, and titles are accurate
- Check that bullet points are parallel in structure
- Confirm contact information is correct and professional
- Remove any irrelevant or outdated information
- Ensure document is 1 page (or 2 for extensive experience)

## Cover Letter Creation Workflow

### Step 1: Research and Prepare

Gather:
- Job description and requirements
- Company information (mission, values, recent news, culture)
- Hiring manager's name (if possible - search LinkedIn, company website)
- 2-3 key achievements that match job requirements
- Specific examples demonstrating fit for role

### Step 2: Choose Cover Letter Format

**Select format based on industry and role**:

**Problem-Solution Format** (Best for most roles):
- Opening: Identify specific company challenge or opportunity
- Body: Explain how your skills/experience solve the problem
- Provide evidence of past success with similar challenges
- Close with enthusiasm and call to action

**Achievement-Focused Format** (Technical/data-driven roles):
- Open with strongest quantifiable achievement
- Detail 2-3 major accomplishments with metrics
- Connect achievements to job requirements
- Close emphasizing continued impact

**Narrative Format** (Creative/mission-driven roles):
- Tell compelling career story
- Connect experiences to company's mission
- Show authentic passion and cultural fit
- Emphasize soft skills and values alignment

### Step 3: Structure the Cover Letter

**Standard Business Letter Format**:

```
[Your Name]
[Phone] | [Email] | [City, State] | [LinkedIn]

[Date]

[Hiring Manager Name]
[Title]
[Company Name]
[Company Address]

Dear [Mr./Ms. Last Name]:

[Opening Paragraph - Hook and position statement]
[Body Paragraph(s) - 2-3 key qualifications with examples]
[Closing Paragraph - Gratitude, enthusiasm, call to action]

Sincerely,
[Your Name]
```

**Formatting Requirements**:
- Length: 150-300 words, maximum 1 page
- Font: Match resume (Arial, Calibri, Times New Roman, 10-12pt)
- Spacing: Single or 1.15 line spacing
- Margins: 1-inch on all sides
- Alignment: Left-align all text
- Save as: PDF or DOCX (check job posting)

### Step 4: Write Compelling Content

**Opening Paragraph**:
- Hook reader with enthusiasm, achievement, or company insight
- State position applying for and how you learned about it
- Brief introduction establishing credibility

**Body Paragraph(s)**:
- Highlight 2-3 key qualifications matching job description
- Provide specific examples using STAR method
- Quantify achievements when possible
- Show understanding of company's needs and how you can contribute
- Don't repeat resume - add context, personality, and depth

**Closing Paragraph**:
- Express sincere appreciation for consideration
- Reiterate enthusiasm for role and company
- Call to action: Request interview or next steps
- Provide contact information

**Professional Sign-off**:
- "Sincerely," "Best regards," "Respectfully," followed by full name

### Step 5: Match Tone to Industry

**Corporate/Legal/Finance**: Formal, conservative, professional
**Tech/Startups**: Professional with personality, enthusiastic, innovative
**Creative**: Casual but serious, showcase unique voice, playful acceptable
**Healthcare/Education**: Compassionate, evidence-based, mission-focused
**Engineering/Technical**: Detail-oriented, results-focused, precise

## Creating Documents in DOCX Format

**When creating resume or cover letter in Word/DOCX format**, use the docx skill capabilities to:

1. Apply professional formatting with consistent fonts and spacing
2. Create clean, ATS-compatible layouts
3. Include subtle professional design elements where appropriate
4. Ensure documents are properly structured and styled
5. Generate matching resume and cover letter sets

## Professional Language Guidelines

**Always**:
- Start bullet points with action verbs (never "Responsible for")
- Use active voice, not passive
- Write in past tense for previous roles, present for current role
- Vary verb choice - don't repeat same verbs
- Be specific and concrete, not vague
- Use industry-appropriate terminology and jargon (matches job description)
- Maintain professional tone throughout

**Never**:
- Use first person ("I," "my," "we") in resume bullets
- Include pronouns in achievement statements
- Use informal language, slang, or contractions
- Include humor (unless very carefully considered for creative roles)
- Make unsupported claims or exaggerations
- Use clichés or overused buzzwords without context

## Industry-Specific Considerations

Different industries prioritize different elements. Adjust emphasis based on target industry:

**Technology**: Technical skills prominently, GitHub/portfolio links, specific technologies/frameworks, certifications, metrics on performance/scale

**Finance**: Quantifiable results emphasized, relevant certifications (CFA, CPA), education pedigree, specific financial systems/software

**Creative**: Portfolio links essential, design skills showcased, unique but professional formatting acceptable, project highlights

**Healthcare**: Licenses and certifications upfront, patient outcomes and metrics, specific systems/EMR experience, compliance knowledge

**Sales**: Revenue numbers prominent, quota attainment percentages, client retention rates, CRM experience, specific industries served

**Marketing**: Campaign results and ROI, growth metrics, analytics tools expertise, specific platforms/channels

**Education**: Teaching philosophy in summary, student outcomes data, curriculum development experience, technology integration

**Legal**: Case results and outcomes, publications or speaking engagements, bar admissions listed clearly, practice areas specified

## Quality Checklist

Before finalizing any resume or cover letter:

**Content**:
- [ ] Customized for specific job and company
- [ ] Keywords from job description integrated naturally
- [ ] All achievements quantified with metrics where possible
- [ ] 3-5 strong bullets per role using action verbs
- [ ] Professional summary matches job requirements
- [ ] Skills section includes relevant technical and soft skills

**Formatting**:
- [ ] ATS-friendly format (standard fonts, simple layout, no graphics)
- [ ] Consistent formatting throughout
- [ ] Professional appearance (clean, scannable, organized)
- [ ] Appropriate length (1 page ideal, 2 acceptable for senior roles)
- [ ] Contact information complete and professional
- [ ] Saved with professional filename

**Language**:
- [ ] Zero spelling or grammar errors
- [ ] Active voice, strong action verbs throughout
- [ ] Professional, industry-appropriate tone
- [ ] Varied vocabulary (no repeated phrases)
- [ ] Specific and concrete, not vague or generic

**Strategic**:
- [ ] Tells compelling professional story
- [ ] Demonstrates clear value proposition
- [ ] Shows career progression and growth
- [ ] Addresses potential concerns (gaps, career changes)
- [ ] Positions candidate for target role

## Delivering Final Documents

When providing completed resumes and cover letters:

1. Create professional DOCX files using docx skill
2. Save to `/mnt/user-data/outputs/` for user access
3. Use clear filenames: `FirstName_LastName_Resume.docx` and `FirstName_LastName_CoverLetter.docx`
4. Provide brief summary highlighting key strengths and strategic positioning
5. Offer next steps: customize for specific applications, test with ATS scanner

## Reference Materials

This skill includes comprehensive reference files:

- `references/action-verbs.md` - Categorized list of powerful action verbs
- `references/ats-guidelines.md` - Detailed ATS optimization strategies
- `references/star-examples.md` - Industry-specific achievement examples using STAR method

Consult these references throughout the creation process for guidance on language, formatting, and content strategy.

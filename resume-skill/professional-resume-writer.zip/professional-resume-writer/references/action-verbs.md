# Resume Action Verbs Reference

## Leadership & Management

### Leading Teams
- Spearheaded, Orchestrated, Directed, Championed, Steered
- Led, Managed, Supervised, Coordinated, Delegated
- Chaired, Oversaw, Administered, Governed, Presided

### Developing People
- Mentored, Coached, Trained, Developed, Cultivated
- Guided, Nurtured, Empowered, Enabled, Upskilled
- Taught, Instructed, Educated, Counseled, Advised

### Decision Making
- Decided, Determined, Resolved, Approved, Authorized
- Established, Set, Defined, Prioritized, Allocated

## Achievement & Results

### Exceeding Goals
- Achieved, Exceeded, Surpassed, Attained, Accomplished
- Delivered, Secured, Captured, Earned, Won
- Outperformed, Topped, Maximized, Optimized

### Generating Value
- Generated, Produced, Yielded, Created value
- Drove, Catalyzed, Propelled, Accelerated
- Multiplied, Compounded, Amplified

## Innovation & Improvement

### Transforming Processes
- Redesigned, Reimagined, Revolutionized, Transformed, Modernized
- Overhauled, Reengineered, Restructured, Refactored
- Streamlined, Optimized, Enhanced, Refined, Improved

### Creating New Solutions
- Implemented, Launched, Introduced, Pioneered, Initiated
- Developed, Created, Designed, Built, Established
- Formulated, Devised, Engineered, Constructed, Invented

### Problem Solving
- Resolved, Rectified, Corrected, Fixed, Troubleshot
- Mitigated, Addressed, Remedied, Solved, Debugged

## Growth & Expansion

### Increasing Metrics
- Increased, Boosted, Elevated, Raised, Amplified
- Expanded, Grew, Scaled, Extended, Broadened
- Accelerated, Advanced, Progressed, Strengthened

### Building & Scaling
- Built, Scaled, Expanded, Grew, Developed
- Established, Founded, Formed, Created, Launched
- Scaled up, Ramped up, Rolled out, Deployed

## Communication & Influence

### Presenting & Speaking
- Presented, Communicated, Articulated, Conveyed, Expressed
- Delivered, Spoke, Addressed, Briefed, Reported

### Persuading & Negotiating
- Negotiated, Persuaded, Influenced, Convinced, Advocated
- Secured buy-in, Garnered support, Built consensus
- Brokered, Mediated, Arbitrated, Reconciled

### Collaborating
- Collaborated, Partnered, Cooperated, Teamed, Allied
- Coordinated, Liaised, Interfaced, Synergized
- Consulted, Advised, Counseled, Guided

## Organization & Efficiency

### Planning & Organizing
- Organized, Coordinated, Arranged, Systematized, Structured
- Planned, Scheduled, Prepared, Outlined, Mapped
- Strategized, Charted, Designed, Blueprinted

### Executing & Managing
- Executed, Implemented, Administered, Managed, Handled
- Processed, Conducted, Operated, Ran, Performed
- Facilitated, Enabled, Orchestrated, Coordinated

### Improving Efficiency
- Streamlined, Automated, Simplified, Consolidated, Centralized
- Expedited, Accelerated, Fast-tracked, Quickened
- Eliminated, Reduced, Minimized, Trimmed, Cut

## Analysis & Research

### Investigating
- Analyzed, Assessed, Evaluated, Examined, Investigated
- Researched, Studied, Explored, Surveyed, Probed
- Audited, Reviewed, Inspected, Scrutinized

### Interpreting Data
- Interpreted, Synthesized, Translated, Decoded, Extrapolated
- Forecasted, Projected, Predicted, Estimated, Calculated
- Measured, Quantified, Tracked, Monitored, Gauged

### Strategic Thinking
- Strategized, Conceptualized, Envisioned, Anticipated
- Identified, Recognized, Discovered, Uncovered, Detected

## Technical & Specialized

### Development & Engineering
- Developed, Engineered, Coded, Programmed, Scripted
- Built, Designed, Architected, Constructed, Created
- Debugged, Tested, Validated, Verified, Optimized

### Data & Analytics
- Analyzed, Modeled, Visualized, Forecasted, Simulated
- Processed, Cleaned, Normalized, Aggregated, Segmented
- Mined, Extracted, Queried, Retrieved, Compiled

### Creative & Design
- Designed, Created, Developed, Conceptualized, Envisioned
- Crafted, Composed, Produced, Illustrated, Rendered
- Styled, Branded, Visualized, Prototyped, Mocked up

## Financial & Business

### Revenue & Sales
- Sold, Closed, Secured, Generated revenue
- Upsold, Cross-sold, Converted, Acquired clients
- Negotiated deals, Won contracts, Landed accounts

### Cost Management
- Reduced costs, Cut expenses, Saved, Economized
- Budgeted, Allocated, Forecasted, Projected
- Controlled, Managed budget, Monitored spending

### Financial Analysis
- Analyzed, Evaluated, Assessed financial performance
- Reconciled, Balanced, Audited, Verified
- Forecasted, Projected, Modeled, Estimated

## Customer & Client Relations

### Serving Customers
- Served, Assisted, Helped, Supported, Aided
- Resolved issues, Addressed concerns, Satisfied needs
- Retained, Maintained relationships, Built loyalty

### Building Relationships
- Cultivated, Developed, Nurtured, Fostered relationships
- Engaged, Connected, Networked, Partnered
- Strengthened ties, Built rapport, Established trust

## Compliance & Quality

### Ensuring Compliance
- Ensured, Maintained, Upheld, Enforced compliance
- Verified, Validated, Certified, Audited
- Monitored, Tracked, Oversaw, Supervised

### Quality Assurance
- Improved, Enhanced, Elevated, Raised quality
- Tested, Inspected, Reviewed, Evaluated, Assessed
- Standardized, Normalized, Systematized, Formalized

## Usage Guidelines

### How to Select Action Verbs
1. **Match the achievement**: Choose verbs that accurately describe what you did
2. **Show impact**: Use verbs that emphasize results and outcomes
3. **Vary vocabulary**: Don't repeat the same verbs throughout resume
4. **Be specific**: Choose precise verbs over generic ones
5. **Use appropriate tense**: Past tense for previous roles, present for current

### Examples of Verb Selection

**Generic**: "Responsible for managing social media"
**Specific**: "Orchestrated social media strategy across 6 platforms"

**Generic**: "Worked on improving sales"
**Specific**: "Boosted quarterly sales by 45% through targeted email campaigns"

**Generic**: "Helped with customer service"
**Specific**: "Resolved 100+ customer inquiries daily, maintaining 98% satisfaction rate"

### Verbs to Avoid
- "Responsible for" (passive, not an action verb)
- "Worked on" (vague, doesn't show ownership)
- "Helped" or "Assisted" (minimizes your contribution)
- "Tried" (suggests you didn't succeed)
- "Was tasked with" (passive voice)

### Power Verb Combinations
Pair action verbs with strong outcomes:
- "Spearheaded initiative that reduced costs by 30%"
- "Architected solution that improved efficiency by 2x"
- "Orchestrated campaign that generated $500K revenue"
- "Pioneered program that increased retention by 25%"

# STAR Method Examples and Templates

## What is the STAR Method?

STAR is a framework for structuring achievement-focused bullet points on resumes:
- **S**ituation: Context or challenge
- **T**ask: Your responsibility
- **A**action: Steps you took
- **R**esult: Measurable outcome

## STAR Bullet Point Structures

### Format 1: Action-Result (Most Common)
**Template**: [Action verb] [what you did], resulting in/leading to [quantified result]

**Examples**:
- Implemented automated testing framework, reducing bug detection time by 60% and deployment errors by 45%
- Redesigned customer onboarding process, increasing activation rate from 35% to 58% within 3 months
- Launched targeted email campaign, generating $500K in revenue and 2,500 new leads

### Format 2: Result-Action (For Impressive Results)
**Template**: [Quantified result] by [action verb] [what you did]

**Examples**:
- Increased quarterly sales by 145% by implementing data-driven prospecting strategy and refining pitch deck
- Reduced customer churn by 30% by creating proactive engagement program and personalized retention campaigns
- Saved $200K annually by identifying inefficiencies and streamlining procurement process

### Format 3: Situation-Task-Action-Result (Complex Achievements)
**Template**: Multiple bullets for single achievement

**Example**:
- Identified 40% decline in user engagement across mobile platform (Situation/Task)
- Conducted user research with 200+ participants to identify pain points and redesigned onboarding flow (Action)
- Increased 30-day retention by 55% and daily active users by 35% within 2 months (Result)

### Format 4: Compact STAR (Single Bullet)
**Template**: [Action] to address [situation], achieving [result]

**Examples**:
- Overhauled content strategy to address declining organic traffic, increasing website visits by 250% in 6 months
- Restructured sales team to improve quota attainment, raising team performance from 65% to 92% of target
- Implemented Agile methodology to accelerate product delivery, reducing time-to-market from 12 to 6 weeks

## Industry-Specific STAR Examples

### Technology / Software Engineering

**Before**: 
- Developed features for main product
- Fixed bugs in codebase
- Wrote documentation

**After**:
- Architected and implemented real-time notification system serving 2M+ users, improving engagement by 40%
- Reduced production incidents by 75% by implementing comprehensive test coverage (from 40% to 95%)
- Created technical documentation that decreased new developer onboarding time from 3 weeks to 1 week

### Sales

**Before**:
- Managed client accounts
- Met sales targets
- Conducted product demonstrations

**After**:
- Grew territory revenue by 180% ($2M to $5.6M) in 18 months by identifying untapped market segments
- Exceeded annual quota by 245% for 3 consecutive years, ranking #1 nationally out of 85 representatives
- Converted 35% of demos to closed deals (vs. 18% team average) through consultative selling approach

### Marketing

**Before**:
- Created marketing campaigns
- Managed social media
- Analyzed campaign performance

**After**:
- Launched integrated marketing campaign that generated 12,000 qualified leads and $3.2M in pipeline
- Increased social media engagement by 320% (Instagram) and 185% (LinkedIn) through data-driven content strategy
- Optimized email marketing funnel, improving open rates from 18% to 34% and conversion rates from 2% to 8%

### Project Management

**Before**:
- Led cross-functional projects
- Coordinated with stakeholders
- Delivered projects on time

**After**:
- Orchestrated company-wide digital transformation initiative across 8 departments, completing 6 weeks ahead of schedule and $400K under budget
- Reduced project delivery time by 35% by implementing Agile methodology and automated reporting dashboards
- Managed $12M infrastructure upgrade serving 50,000+ users, achieving 99.9% uptime during migration

### Customer Service / Support

**Before**:
- Answered customer inquiries
- Resolved customer issues
- Processed returns

**After**:
- Maintained 98% customer satisfaction score while handling 80+ support tickets daily across phone, chat, and email
- Reduced average resolution time from 4 hours to 45 minutes by creating self-service knowledge base with 200+ articles
- Turned around NPS score from -15 to +45 in 6 months by redesigning support workflows and implementing proactive outreach

### Finance / Accounting

**Before**:
- Prepared financial reports
- Managed budgets
- Performed analysis

**After**:
- Identified $2.3M in cost-saving opportunities through comprehensive budget analysis and vendor renegotiation
- Streamlined month-end close process from 12 days to 5 days by automating reconciliations and implementing new controls
- Reduced forecast variance from ±15% to ±3% by developing dynamic financial models incorporating 25+ variables

### Human Resources

**Before**:
- Recruited candidates
- Conducted interviews
- Managed onboarding

**After**:
- Reduced time-to-hire from 45 to 22 days by optimizing recruitment pipeline and implementing applicant tracking system
- Increased employee retention by 28% through redesigned onboarding program and quarterly engagement initiatives
- Built talent pipeline of 500+ qualified candidates, filling 92% of roles with internal referrals or pipeline candidates

### Operations / Logistics

**Before**:
- Managed inventory
- Coordinated shipments
- Optimized processes

**After**:
- Cut logistics costs by 32% ($1.8M annually) by consolidating vendors and renegotiating contracts
- Improved on-time delivery from 78% to 96% by implementing real-time tracking system and predictive routing
- Reduced inventory carrying costs by $600K through demand forecasting model and just-in-time procurement

### Healthcare

**Before**:
- Provided patient care
- Maintained records
- Followed protocols

**After**:
- Improved patient satisfaction scores from 72% to 94% by implementing bedside shift reports and personalized care plans
- Reduced medication errors by 85% through barcode scanning system implementation and staff training program
- Decreased average patient wait time from 45 to 18 minutes while maintaining quality of care standards

### Education

**Before**:
- Taught classes
- Developed curriculum
- Graded assignments

**After**:
- Increased student test scores by average of 22% through differentiated instruction and data-driven interventions
- Designed and launched STEM enrichment program serving 150+ students, with 85% showing improved performance
- Raised class engagement rates from 60% to 92% by integrating technology and project-based learning

## Metrics and Quantification Guide

### What to Quantify

**Financial Impact**:
- Revenue generated, increased, or saved
- Cost reductions or savings
- Budget managed
- ROI percentage

**Scale/Volume**:
- Number of customers/clients/users served
- Size of team managed
- Number of projects completed
- Volume of transactions processed

**Performance Improvements**:
- Percentage increases or decreases
- Time savings
- Efficiency gains
- Quality improvements (error reduction, satisfaction scores)

**Comparative Metrics**:
- Before vs. After
- Actual vs. Target
- Company average vs. Your performance
- Industry benchmark vs. Your achievement

### How to Find Your Metrics

**Review Performance Evaluations**:
- Look for specific achievements mentioned
- Note any data or metrics referenced
- Check goals vs. results

**Analyze Your Work**:
- What changed because of your work?
- How much time/money did you save?
- How many people benefited?
- What was the impact on the team/company?

**Ask Colleagues/Managers**:
- "What was the measurable impact of [project]?"
- "How did my work improve [metric]?"
- "What were the results of [initiative]?"

**Use Approximations if Exact Unknown**:
- "Managed team of ~15 people"
- "Reduced costs by approximately 30%"
- "Served 100+ customers daily"
- "Generated $500K+ in annual revenue"

## Common Weak Bullets Transformed

### Weak → Strong Transformations

**Generic Management**:
❌ "Managed a team"
✅ "Led cross-functional team of 12 developers and designers, delivering 8 product features on time and under budget"

**Vague Improvement**:
❌ "Improved customer satisfaction"
✅ "Elevated NPS from 42 to 73 through enhanced training program and streamlined support processes"

**Passive Responsibility**:
❌ "Responsible for social media"
✅ "Grew Instagram following from 5K to 85K in 10 months, achieving 4.2% engagement rate (3x industry average)"

**Task Without Impact**:
❌ "Created marketing materials"
✅ "Designed sales collateral that contributed to 40% increase in demo-to-close conversion rate"

**Missing Context**:
❌ "Exceeded sales targets"
✅ "Surpassed quota by 165% ($2.8M vs. $1.7M goal), ranking #2 out of 47 regional sales managers"

## STAR Method Best Practices

### Do's:
✅ Start with strong action verbs
✅ Include specific numbers and metrics
✅ Show impact on business/customers/team
✅ Use varied sentence structures
✅ Tailor to job description keywords
✅ Be specific about YOUR contribution
✅ Use concrete, measurable results

### Don'ts:
❌ Use passive voice ("was responsible for")
❌ Be vague about results
❌ Take credit for team work without context
❌ Exaggerate or falsify metrics
❌ Use generic buzzwords without evidence
❌ Write paragraphs (keep bullets concise)
❌ Repeat same metrics/achievements

## Remember

- Every bullet should answer: "So what? What was the impact?"
- Numbers grab attention and prove impact
- Show progression and growth in your career
- Match accomplishments to target job requirements
- Quality over quantity - 3-5 strong bullets beats 8 weak ones

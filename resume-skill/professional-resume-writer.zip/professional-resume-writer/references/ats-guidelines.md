# ATS Formatting Guidelines

## What is an ATS?

An Applicant Tracking System (ATS) is software that scans, parses, and ranks resumes before they reach human recruiters. 99.7% of Fortune 500 companies and 75% of all companies use ATS to manage applications.

## Critical ATS Requirements

### File Format
- **Preferred**: DOCX (Microsoft Word)
- **Also Acceptable**: PDF (most modern ATS can read PDFs)
- **Check job posting**: Some explicitly state preferred format
- **Never use**: Images, scanned PDFs, unusual file types

### Resume Structure
**Most ATS-Friendly Format: Reverse Chronological**
- Lists work experience starting with most recent
- Clearly shows career progression
- Easy for ATS to parse dates and progression

**Avoid**: Functional resumes (skills-focused without clear work history)

### Document Layout
**Single Column (Most Reliable)**
- Linear, top-to-bottom reading
- No parsing confusion
- Maximum ATS compatibility

**Two Column (Use with Caution)**
- Can work if properly structured
- Some ATS may misread order
- Test before submitting

**Never Use**:
- Three or more columns
- Complex tables for layout
- Text boxes
- Headers/footers for critical info

## What ATS Can and Cannot Read

### ✅ ATS-Friendly Elements
- Standard fonts (Arial, Calibri, Helvetica, Times New Roman, Georgia, Roboto)
- Simple bullet points (•, ○, ■, -)
- Standard section headings
- Clear date formatting
- Plain text
- Left-aligned text
- Standard margins (1 inch)

### ❌ ATS Problem Elements
- Images, logos, photos
- Graphics, charts, infographics
- Embedded tables (for layout)
- Text boxes
- Headers/footers with key information
- Columns (can confuse reading order)
- Unusual fonts or symbols
- Colored backgrounds
- Watermarks
- Special characters, emojis
- Underlining (use bold instead)

## Section Naming Conventions

### Standard Headers ATS Recognizes
**Professional Summary/Summary**: 
- "Professional Summary"
- "Summary"
- "Profile"

**Work Experience**:
- "Work Experience"
- "Professional Experience"
- "Experience"
- "Work History"
- "Employment History"

**Education**:
- "Education"
- "Academic Background"
- "Academic Credentials"

**Skills**:
- "Skills"
- "Technical Skills"
- "Core Competencies"
- "Areas of Expertise"

**Certifications**:
- "Certifications"
- "Licenses and Certifications"
- "Professional Certifications"

### Avoid Creative Headers
- Don't use unique headers like "My Journey" or "What I Do"
- ATS may not recognize non-standard section names
- Stick to conventional business language

## Date Formatting

### ATS-Friendly Formats
- "January 2020 - December 2023"
- "Jan 2020 - Dec 2023"
- "01/2020 - 12/2023"
- "2020 - 2023" (year only)

### Formatting Rules
- Be consistent throughout document
- Month-Year OR Year only (not both)
- Use hyphens or "to" between dates
- "Present" for current roles (not "Current")

## Contact Information

### Include (at top of resume)
- Full Name (largest text on page)
- Phone Number (include area code)
- Email Address (professional)
- City, State (full address not necessary)
- LinkedIn URL (optional but recommended)
- Portfolio/Website (if relevant)

### Format
- Can be centered or left-aligned
- Keep simple - no tables or text boxes
- Ensure it's in the main document body

## Keywords Strategy

### Keyword Placement
- Naturally integrated throughout resume
- In skills section
- In work experience bullets
- In professional summary
- In job titles (if accurate)

### How to Find Keywords
1. Read job description carefully
2. Identify required skills and qualifications
3. Note specific technologies, tools, methodologies
4. Extract industry-specific terminology
5. Use exact phrases from posting (not synonyms)

### Keyword Best Practices
- Use exact terminology from job posting
- Include variations (e.g., "SEO" and "Search Engine Optimization")
- Don't stuff keywords unnaturally
- Context matters - show how you used skills
- Target 75-85% match (100% = over-optimized)

## Common ATS Mistakes

### 1. Using Images or Graphics
**Problem**: ATS cannot read image content
**Solution**: Use text only; remove photos, logos, charts

### 2. Complex Formatting
**Problem**: Tables and text boxes confuse parsing
**Solution**: Use simple, linear format with standard bullets

### 3. Non-Standard Fonts
**Problem**: May not render correctly in ATS
**Solution**: Stick to common system fonts

### 4. Headers/Footers for Key Info
**Problem**: Many ATS skip header/footer content
**Solution**: Put all important info in main document body

### 5. Incorrect File Format
**Problem**: Some formats can't be parsed
**Solution**: Save as DOCX or PDF (check job requirements)

### 6. Missing Keywords
**Problem**: Resume doesn't match job description
**Solution**: Customize resume for each application

### 7. Creative Section Names
**Problem**: ATS doesn't recognize sections
**Solution**: Use standard professional headings

### 8. Inconsistent Formatting
**Problem**: Confuses parsing algorithms
**Solution**: Maintain consistent font, size, bullet style

## Testing Your ATS Compatibility

### Manual Check
1. Copy resume text and paste into plain text editor
2. Check if content is readable and in correct order
3. Verify all information transferred correctly

### Professional Check
1. Use resume scanner tools (Jobscan, Resume Worded)
2. Upload to job sites and preview parsed version
3. Check ATS compatibility score

### Red Flags
- Text appears out of order
- Sections missing or jumbled
- Contact information lost
- Dates or bullet points misaligned

## Optimal ATS Resume Template

```
[Name - 16-18pt, Bold]
[Phone] | [Email] | [City, State] | [LinkedIn]

PROFESSIONAL SUMMARY
[3-4 line summary with keywords]

WORK EXPERIENCE

[Job Title] | [Company Name] | [City, State] | [Dates]
• [Achievement with metric using action verb]
• [Achievement with metric using action verb]
• [Achievement with metric using action verb]

[Job Title] | [Company Name] | [City, State] | [Dates]
• [Achievement with metric using action verb]
• [Achievement with metric using action verb]
• [Achievement with metric using action verb]

EDUCATION

[Degree] in [Field] | [University Name] | [Graduation Year]
[GPA if >3.5 and recent graduate]

SKILLS

[Skill Category]: [Skill 1], [Skill 2], [Skill 3]
[Skill Category]: [Skill 1], [Skill 2], [Skill 3]
```

## ATS Best Practices Summary

1. **Use DOCX or PDF format** (check job posting)
2. **Choose reverse-chronological format**
3. **Use standard fonts and simple formatting**
4. **Stick to conventional section headers**
5. **Avoid images, graphics, tables, text boxes**
6. **Include relevant keywords naturally**
7. **Customize for each job application**
8. **Keep it to 1-2 pages maximum**
9. **Use standard bullet points**
10. **Save with professional filename** (FirstName_LastName_Resume.pdf)

## Industry-Specific ATS Considerations

### Technology
- List programming languages, frameworks, tools
- Include version numbers if relevant
- Spell out acronyms first time, then use acronym
- Include certifications (AWS, Azure, etc.)

### Healthcare
- Include all licenses and certifications
- Use standard medical terminology
- List specific systems/software experience
- Include patient care metrics

### Finance
- Reference specific financial software
- Include certifications (CPA, CFA, etc.)
- Use industry-standard terminology
- Quantify financial impact

### Marketing
- Include platform names (Google Ads, HubSpot, etc.)
- Reference analytics tools
- List specific campaign types
- Use industry metrics (CTR, ROI, CAC, etc.)

### Sales
- Include CRM systems (Salesforce, etc.)
- Reference sales methodologies
- Use metrics (quota attainment, revenue, etc.)
- List specific industries/verticals

## Remember

ATS systems are becoming more sophisticated, but they still have limitations. The goal is to create a resume that:
1. Passes ATS screening
2. Impresses human recruiters
3. Accurately represents your qualifications
4. Tells a compelling professional story

Balance ATS optimization with human readability - you need to pass both tests to land an interview.

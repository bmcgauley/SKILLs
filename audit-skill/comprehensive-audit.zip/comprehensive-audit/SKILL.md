---
name: comprehensive-audit
description: Comprehensive audit methodology for conducting professional audits across all domains including IT, cybersecurity, compliance, responsible AI, financial, operational, and other audit types. This skill should be used when users request audit reports, compliance assessments, gap analyses, risk assessments, or systematic evaluations of any organizational processes, controls, or systems. Provides complete ISACA-aligned audit report structure and methodology with human-in-the-loop verification.
---

# Comprehensive Audit

## Overview

Conduct systematic, evidence-based audits following ISACA standards (Information Technology Assurance Framework - ITAF) and professional audit methodology. This skill supports all audit types: IT audits, cybersecurity audits, responsible AI audits, compliance audits, financial audits, operational audits, and specialized domain audits. Produce professional, well-structured audit reports with proper findings documentation, recommendations, and implementation roadmaps.

## When to Use

Use this skill when users request:
- IT audit reports or cybersecurity assessments
- Compliance audits (GDPR, CCPA, HIPAA, SOX, PCI DSS, etc.)
- Responsible AI audits or algorithmic bias assessments
- Operational or process audits
- Control effectiveness evaluations
- Gap analyses against frameworks or standards
- Risk assessments or vulnerability assessments
- Internal control audits
- Third-party vendor audits
- System or application audits

## Audit Methodology

### Phase 1: Audit Planning and Scoping

**1. Understand the Audit Subject**
- Identify what is being audited (organization, system, process, application, controls, etc.)
- Determine the audit type (examination, review, agreed-upon procedures)
- Define temporal scope (period under review, when audit is performed)
- Establish organizational context and boundaries

**2. Define Audit Objectives**
- Phrase as "To determine whether..." or "To assess the adequacy of..."
- Examples:
  - "To determine whether controls are adequate to protect customer data"
  - "To assess compliance with GDPR requirements"
  - "To evaluate the effectiveness of AI governance processes"
- Align objectives with stakeholder needs and risk areas

**3. Identify Applicable Criteria**
- Use entity-defined standards (policies, procedures, SLAs, contracts)
- Apply industry frameworks (ISACA, NIST, ISO, COBIT, etc.)
- Reference regulations (GDPR, CCPA, HIPAA, SOX, PCI DSS, etc.)
- Incorporate best practices and benchmarks
- For responsible AI: Use NIST AI RMF, IEEE 7000 series, EU AI Act, etc.

**4. Gather Context from User**
Before proceeding, ask clarifying questions:
- "What is the scope of the audit? (specific systems, departments, timeframe)"
- "What are the primary concerns or risk areas?"
- "What frameworks or regulations apply?"
- "Are there existing policies or standards to audit against?"
- "What level of detail is needed in the report?"

### Phase 2: Evidence Collection and Analysis

**1. Document Review**
- Review uploaded documents, policies, procedures, system documentation
- Extract relevant information systematically
- Use web_search for current regulations, frameworks, or industry standards
- Use google_drive_search for internal documentation if available
- Reference past conversations if relevant context exists

**2. Systematic Analysis**
- Map findings to audit objectives
- Identify control gaps and deficiencies
- Assess severity and risk of each finding
- Document evidence supporting each finding
- Track sources for all claims and assertions

**3. Use Supporting Skills**
Call relevant skills based on audit type:
- `docx` skill: For creating professional Word documents
- `xlsx` skill: For creating compliance matrices or tracking spreadsheets
- `web_search`: For latest regulations, frameworks, industry standards
- `google_drive_search`: For internal policies or documentation
- `human-writing` skill: For natural, professional report writing
- `technical-documentation` skill: For technical audit sections
- `project-management` skill: For implementation planning
- Domain-specific skills as needed

### Phase 3: Findings Development

**For Each Finding, Document Five Key Attributes:**

1. **Condition** - What was observed/found
   - State actual state discovered during audit
   - Provide specific evidence and examples
   - Include quantifiable data where possible

2. **Criteria** - What should be (the standard)
   - Reference specific policy, regulation, or standard
   - Quote or paraphrase the requirement
   - Include section numbers or citations

3. **Cause** - Why the gap exists
   - Root cause analysis
   - Systemic vs. isolated issues
   - Resource, training, or design deficiencies

4. **Effect** - The impact or risk
   - Business impact (operational, financial, reputational)
   - Risk level (critical, high, medium, low)
   - Potential consequences if unaddressed

5. **Recommendation** - How to fix it
   - Specific, actionable steps
   - Prioritized based on risk
   - Realistic and implementable
   - Include responsible party and timeline where appropriate

**Finding Classification:**
- **Critical**: Immediate action required, material weakness, severe risk
- **High**: Significant deficiency, major compliance gap, high risk
- **Medium**: Moderate control weakness, needs attention
- **Low**: Minor improvements, optimization opportunities

### Phase 4: Report Construction

**Use ISACA-Aligned Report Structure:**

**1. Executive Summary** (MANDATORY)
- High-level overview of audit purpose
- Key findings summary (2-4 sentences)
- Overall opinion/conclusion
- Primary recommendations
- Target audience: Senior leadership who may only read this section

**2. Scope of the Audit Engagement** (MANDATORY)
- Define audit subject clearly
- Specify what was included/excluded
- State the period under review
- Identify when fieldwork was conducted
- Define organizational boundaries

**3. Source of Management's Representation** (MANDATORY)
- Document management's assertions or claims
- Reference formal declarations about controls
- Note representations about compliance, security, effectiveness
- Examples: "Management asserts that controls are adequate to..."

**4. Objectives of the Audit** (MANDATORY)
- Clearly state what the audit aimed to achieve
- List all audit objectives
- Align with initial engagement agreement

**5. Source of the Criteria** (MANDATORY)
- List all frameworks, standards, and regulations used
- Cite policies, procedures, and benchmarks
- Provide full references with links where available
- Examples:
  - GDPR (with link to official text)
  - NIST Cybersecurity Framework (with version and link)
  - Company Policy XYZ (with document reference)

**6. Findings, Conclusions and Recommendations** (MANDATORY)
- Present each finding with all five attributes
- Assign severity rating to each finding
- Provide unique reference number (F-001, F-002, etc.)
- Include management response if obtained
- Document responsible party and implementation date
- Consider presenting in order of severity

**7. Expression of Opinion** (MANDATORY)
- Provide overall conclusion regarding audit objectives
- Use professional opinion types:
  - **Unqualified Opinion**: No material exceptions, controls are adequate
  - **Qualified Opinion**: Significant deficiencies but not material weaknesses
  - **Adverse Opinion**: Material weaknesses exist, controls inadequate
  - **Disclaimer of Opinion**: Insufficient evidence to form opinion
- Include explanatory paragraph justifying the opinion

**8. Detailed Findings Analysis** (DISCRETIONARY)
- Deep dive into each finding
- Supporting evidence and documentation
- Technical details or background
- Risk analysis and impact assessment

**9. Recommendations Summary** (DISCRETIONARY)
- Consolidated list of all recommendations
- Implementation roadmap or timeline
- Resource requirements
- Quick wins vs. long-term initiatives

**10. Background and Context** (DISCRETIONARY)
- Organizational context
- Industry background
- Regulatory environment
- Previous audit history

**11. Methodology** (DISCRETIONARY)
- Approach used for the audit
- Evidence gathering methods
- Sampling methodology
- Testing procedures performed

**12. Appendices** (DISCRETIONARY)
- Detailed evidence
- Supporting documentation
- References and citations
- Glossary of terms
- Compliance matrices

### Phase 5: Human-in-the-Loop Verification

**Critical: Verify Findings with User**

1. **Present Initial Analysis**
   - Share preliminary findings before finalizing report
   - Ask: "Based on the provided information, I've identified [X] findings. Would you like me to:
     - Provide more detail on any specific findings?
     - Search for additional information on any regulations/frameworks?
     - Adjust the severity ratings based on organizational context?
     - Add or remove any areas of focus?"

2. **Validate Evidence**
   - For each key finding, cite sources:
     - Document reference: "Per [Document Name], Section X..."
     - Regulation citation: "According to GDPR Article 25..."
     - Framework reference: "NIST CSF function PR.DS-1 requires..."
   - Ask if user needs additional evidence or documentation

3. **Confirm Recommendations**
   - Verify recommendations are realistic for the organization
   - Adjust based on user's knowledge of constraints
   - Ask: "Are these recommendations aligned with organizational capabilities and priorities?"

4. **Resource Verification**
   - For regulations: Provide links to authoritative sources
   - For frameworks: Link to official framework documentation
   - For standards: Reference official publications
   - For all web-sourced information: Include URLs
   - Ask: "Would you like me to fetch the complete text of any referenced regulation or framework?"

### Phase 6: Report Generation

**1. Select Report Format**
Based on user needs:
- Word document (.docx) using `docx` skill - RECOMMENDED for most audits
- PDF using `pdf` skill - For final distribution
- Markdown for collaborative editing
- Excel workbook using `xlsx` skill - For compliance tracking matrices

**2. Apply Professional Standards**
- Use `human-writing` skill to avoid AI writing clichés
- Maintain professional, objective tone
- Use third-person perspective
- Employ clear, concise language
- Follow formatting guidelines:
  - 12pt Times New Roman (or specified font)
  - Single spacing (or as specified)
  - 1-inch margins
  - Professional headers/footers
  - Proper section numbering

**3. Include Proper Citations**
- Reference all sources used
- Provide clickable links where possible
- Use footnotes or endnotes for regulatory citations
- Include bibliography or references section

**4. Create Supporting Documents**
Consider creating:
- Findings tracking spreadsheet (for management follow-up)
- Compliance matrix (mapping requirements to controls)
- Implementation roadmap (timeline for remediation)
- Executive presentation (PowerPoint summary)

### Phase 7: Deliverables and Follow-up

**1. Primary Deliverable**
- Professional audit report in requested format
- Saved to `/mnt/user-data/outputs/` with computer:// link
- Named clearly: `[Organization]_[Audit Type]_Report_[Date].docx`

**2. Supporting Deliverables** (as requested)
- Findings tracking spreadsheet
- Compliance matrices
- Risk heat maps
- Implementation plans
- Presentation materials

**3. Provide User Guidance**
- Explain how to access deliverables
- Suggest next steps
- Offer to create additional materials
- Remind about follow-up audit scheduling

## Domain-Specific Guidance

### IT and Cybersecurity Audits

**Focus Areas:**
- Access controls and authentication
- Network security and segmentation
- Encryption and data protection
- Patch management and vulnerability management
- Incident response and logging
- Business continuity and disaster recovery
- Security awareness and training
- Vendor and third-party risk management

**Common Frameworks:**
- NIST Cybersecurity Framework
- ISO/IEC 27001
- CIS Controls
- COBIT 2019
- SOC 2

**Reference Files:**
- `references/cybersecurity_frameworks.md` for framework details
- `references/nist_csf.md` for NIST CSF specifics

### Responsible AI Audits

**Focus Areas:**
- Algorithmic bias and fairness testing
- Model transparency and explainability
- Data governance and privacy
- AI ethics and oversight structures
- Model monitoring and performance
- Training data quality and representativeness
- Consent and user rights
- Documentation and accountability

**Common Frameworks:**
- NIST AI Risk Management Framework
- IEEE 7000 series standards
- EU AI Act requirements
- ISO/IEC 23894 (AI risk management)
- Partnership on AI guidelines

**Special Considerations:**
- Test for demographic parity and equal opportunity
- Assess model documentation standards
- Evaluate DPIA compliance for high-risk AI
- Review AI ethics board effectiveness
- Check for human oversight in automated decisions

**Reference Files:**
- `references/responsible_ai_frameworks.md`
- `references/ai_bias_testing.md`

### Compliance Audits

**Common Regulations:**
- GDPR (EU data protection)
- CCPA/CPRA (California privacy)
- HIPAA (healthcare)
- SOX (financial controls)
- PCI DSS (payment card security)
- COPPA (children's privacy)
- FERPA (education privacy)

**Audit Approach:**
- Map requirements to controls
- Test control effectiveness
- Review documentation and evidence
- Assess training and awareness
- Verify incident response procedures
- Check third-party compliance

**Reference Files:**
- `references/gdpr_requirements.md`
- `references/compliance_frameworks.md`

### Financial and Operational Audits

**Focus Areas:**
- Internal controls (COSO framework)
- Financial reporting accuracy
- Process efficiency and effectiveness
- Compliance with policies and procedures
- Segregation of duties
- Authorization and approval processes
- Asset management and safeguarding

**Common Frameworks:**
- COSO Internal Control Framework
- COSO ERM Framework
- ISO 9001 (quality management)

## Best Practices

**1. Maintain Independence and Objectivity**
- Present findings without bias
- Base conclusions on evidence
- Avoid assumptions without support
- Challenge assertions with facts

**2. Use Professional Skepticism**
- Question management representations
- Verify through independent evidence
- Don't accept claims at face value
- Look for contradictory evidence

**3. Document Everything**
- Maintain clear audit trail
- Reference all sources
- Save evidence and working papers
- Track decisions and rationale

**4. Communicate Clearly**
- Use plain language, avoid jargon
- Explain technical concepts when necessary
- Structure information logically
- Highlight key points effectively

**5. Be Solution-Oriented**
- Provide actionable recommendations
- Consider organizational constraints
- Prioritize based on risk and impact
- Offer implementation guidance

**6. Verify with User Throughout**
- Confirm understanding of requirements
- Validate preliminary findings
- Check accuracy of organizational context
- Ensure recommendations are realistic

**7. Leverage All Available Tools**
- Use web_search for current regulations and frameworks
- Use google_drive_search for internal documentation
- Call specialized skills as needed
- Reference past conversations when relevant

**8. Provide Comprehensive References**
- Link to authoritative sources
- Cite regulations with article/section numbers
- Reference framework versions and sections
- Include publication dates for standards

## Critical Reminders

- **ALWAYS verify findings and recommendations with the user before finalizing**
- **ALWAYS provide links to authoritative sources for regulations and frameworks**
- **ALWAYS use the five-attribute finding structure (Condition, Criteria, Cause, Effect, Recommendation)**
- **ALWAYS include all MANDATORY report components per ISACA ITAF**
- **ALWAYS rate findings by severity (Critical, High, Medium, Low)**
- **ALWAYS save final deliverables to `/mnt/user-data/outputs/`**
- **ALWAYS use human-writing skill for professional report content**
- **ALWAYS maintain independence and objectivity**

## Example Workflow

1. User requests: "Conduct a responsible AI audit for OmniSecure Corp"
2. Read this SKILL.md and relevant reference files
3. Gather context: scope, objectives, applicable regulations
4. Review uploaded documents systematically
5. Search for applicable frameworks and regulations using web_search
6. Identify findings using the five-attribute structure
7. Present preliminary findings to user for validation
8. Construct report using ISACA-aligned structure
9. Apply human-writing skill for professional content
10. Generate Word document using docx skill
11. Save to outputs directory and provide computer:// link
12. Offer to create supporting materials (tracking spreadsheet, etc.)

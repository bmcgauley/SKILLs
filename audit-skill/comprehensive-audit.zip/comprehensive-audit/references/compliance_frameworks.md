# Compliance Frameworks and Regulations Reference

## Overview

This reference provides detailed information on major compliance regulations and frameworks for conducting compliance audits. Use when auditing adherence to legal and regulatory requirements.

## GDPR (General Data Protection Regulation)

**Official Source**: https://gdpr-info.eu/

**Scope**: EU residents' personal data, regardless of where processing occurs
**Effective**: May 25, 2018
**Penalties**: Up to €20 million or 4% of annual global turnover (whichever is higher)

### Key Principles (Article 5)

1. **Lawfulness, Fairness and Transparency**
   - Process data lawfully, fairly, and in transparent manner
   - Inform data subjects about processing

2. **Purpose Limitation**
   - Collect for specified, explicit, legitimate purposes
   - No further processing incompatible with those purposes

3. **Data Minimization**
   - Adequate, relevant, and limited to what is necessary
   - Only collect what is needed

4. **Accuracy**
   - Accurate and kept up to date
   - Inaccurate data erased or rectified without delay

5. **Storage Limitation**
   - Kept no longer than necessary
   - Define retention periods

6. **Integrity and Confidentiality**
   - Appropriate security measures
   - Protection against unauthorized processing, loss, destruction, damage

7. **Accountability**
   - Controller responsible for compliance
   - Must demonstrate compliance

### Legal Bases for Processing (Article 6)

- **Consent**: Clear, affirmative action
- **Contract**: Necessary for contract performance
- **Legal Obligation**: Required by law
- **Vital Interests**: Protect life of data subject
- **Public Interest**: Performance of public interest task
- **Legitimate Interests**: Pursued by controller or third party

### Data Subject Rights

**Article 15**: Right of Access
- Confirm processing
- Access to personal data
- Copy of data

**Article 16**: Right to Rectification
- Correct inaccurate personal data
- Complete incomplete data

**Article 17**: Right to Erasure ("Right to be Forgotten")
- Delete data when no longer necessary
- Withdrawal of consent
- Object to processing
- Unlawful processing
- Legal obligation requires deletion

**Article 18**: Right to Restriction of Processing
- Accuracy contested
- Unlawful processing but subject opposes erasure
- No longer needed but subject needs for legal claims
- Objection pending verification

**Article 20**: Right to Data Portability
- Receive data in structured, commonly used format
- Transmit data to another controller
- Where technically feasible, direct transmission

**Article 21**: Right to Object
- Object to processing for direct marketing
- Object to automated decision-making
- Object to processing for public interest or legitimate interests

**Article 22**: Automated Decision-Making and Profiling
- Not subject to solely automated decisions with legal/significant effects
- Exceptions: Contract, legal authorization, explicit consent
- Right to human intervention, express view, contest decision

### Key Obligations

**Article 13-14**: Information to be Provided
- Identity of controller
- Purpose of processing
- Legal basis
- Legitimate interests (if applicable)
- Recipients of data
- International transfers
- Retention period
- Data subject rights
- Right to withdraw consent
- Right to complain to supervisory authority
- Source of data (for indirect collection)

**Article 25**: Data Protection by Design and Default
- Implement appropriate technical and organizational measures
- Privacy by design
- Privacy by default (only necessary data processed)

**Article 30**: Records of Processing Activities
- Name and contact details of controller
- Purposes of processing
- Categories of data subjects and personal data
- Categories of recipients
- International transfers
- Retention periods
- Security measures

**Article 32**: Security of Processing
- Pseudonymization and encryption
- Confidentiality, integrity, availability, resilience
- Ability to restore availability after incident
- Regular testing and evaluation
- Risk-appropriate measures

**Article 33-34**: Data Breach Notification
- Notify supervisory authority within 72 hours
- Document breaches
- Notify data subjects if high risk to rights and freedoms

**Article 35-36**: Data Protection Impact Assessment (DPIA)
- Required for high-risk processing
- Systematic description of processing
- Assessment of necessity and proportionality
- Assessment of risks
- Measures to address risks
- Consultation with supervisory authority if high risk remains

**Article 37**: Data Protection Officer (DPO)
- Required for public authorities
- Required for large-scale monitoring
- Required for large-scale special category data processing
- Professional qualities and independence
- Adequate resources

**Article 44-50**: International Transfers
- Adequacy decision
- Appropriate safeguards (SCCs, BCRs)
- Derogations for specific situations
- Prior authorization or notification may be required

### GDPR Audit Checklist

**Data Inventory and Mapping**
- [ ] Inventory of personal data maintained
- [ ] Data flows documented
- [ ] Data categories identified
- [ ] Processing purposes defined
- [ ] Legal bases documented

**Lawful Processing**
- [ ] Legal basis identified for each processing activity
- [ ] Consent mechanisms appropriate (where applicable)
- [ ] Records of consent maintained
- [ ] Legitimate interest assessments performed (where applicable)

**Transparency**
- [ ] Privacy notices provided
- [ ] Privacy notices comprehensive and clear
- [ ] Privacy notices regularly updated
- [ ] Data subjects properly informed

**Data Subject Rights**
- [ ] Procedures to handle access requests
- [ ] Procedures for rectification
- [ ] Procedures for erasure
- [ ] Procedures for restriction
- [ ] Procedures for portability
- [ ] Procedures for objection
- [ ] Response within one month

**Security**
- [ ] Appropriate technical measures implemented
- [ ] Appropriate organizational measures implemented
- [ ] Risk assessments conducted
- [ ] Security regularly tested
- [ ] Encryption implemented (where appropriate)

**Data Breaches**
- [ ] Breach response plan documented
- [ ] Breach detection capabilities
- [ ] Notification procedures defined
- [ ] Breach register maintained

**Accountability**
- [ ] Records of processing activities maintained
- [ ] DPIAs conducted for high-risk processing
- [ ] DPO appointed (if required)
- [ ] Data processing agreements with processors
- [ ] Compliance documented

**International Transfers**
- [ ] Transfers identified and documented
- [ ] Adequate safeguards in place
- [ ] Standard contractual clauses executed
- [ ] Transfer impact assessments conducted

## CCPA/CPRA (California Consumer Privacy Act/Rights Act)

**Official Source**: https://oag.ca.gov/privacy/ccpa

**Scope**: California residents' personal information
**CCPA Effective**: January 1, 2020
**CPRA Effective**: January 1, 2023
**Penalties**: Up to $7,500 per intentional violation, $2,500 per unintentional violation

### Thresholds for Application

Business must meet one of:
- Annual gross revenues > $25 million
- Buy/sell personal information of 100,000+ consumers/households
- Derive 50%+ of annual revenues from selling/sharing personal information

### Consumer Rights

**Right to Know** (Sections 1798.100, 1798.110, 1798.115)
- Categories of personal information collected
- Categories of sources
- Business purpose for collection
- Categories of third parties with whom shared
- Specific pieces of information

**Right to Delete** (Section 1798.105)
- Request deletion of personal information
- Exceptions for legal compliance, fraud prevention, etc.

**Right to Opt-Out** (Section 1798.120)
- Opt out of sale of personal information
- "Do Not Sell My Personal Information" link required

**Right to Non-Discrimination** (Section 1798.125)
- Cannot discriminate for exercising rights
- Cannot deny goods or services
- Cannot charge different prices
- Cannot provide different quality
- May offer financial incentives with consent

**Right to Correct** (CPRA - Section 1798.106)
- Request correction of inaccurate personal information

**Right to Limit Use of Sensitive Personal Information** (CPRA - Section 1798.121)
- Limit use and disclosure of sensitive personal information
- "Limit the Use of My Sensitive Personal Information" link

### Business Obligations

**Privacy Notice** (Section 1798.100(b))
- Categories of personal information collected
- Purposes for collection
- Notice at or before collection

**Consumer Requests** (Sections 1798.130, 1798.135)
- Two methods for submitting requests
- Respond within 45 days (extendable to 90)
- Verify identity of requestor
- Free service (up to 2 requests per 12 months)

**Do Not Sell Link** (Section 1798.135)
- Conspicuous link on homepage
- Clear and conspicuous disclosure
- No requirement to create account

**Service Providers** (Section 1798.140(w))
- Contracts required with service providers
- Prohibit retention, use, disclosure for purposes other than performing services
- Prohibit further selling or sharing

**Data Security** (Section 1798.150)
- Implement reasonable security procedures
- Private right of action for data breaches

**Audits** (CPRA - Section 1798.185(a)(15))
- Annual cybersecurity audit requirement
- Risk assessment for processing sensitive personal information

### Sensitive Personal Information (CPRA)

- Social security, driver's license, passport numbers
- Account credentials
- Precise geolocation
- Racial or ethnic origin
- Religious or philosophical beliefs
- Union membership
- Genetic data
- Biometric information for identification
- Health information
- Sex life or sexual orientation
- Contents of mail, email, text messages

### CCPA/CPRA Audit Checklist

**Applicability**
- [ ] Threshold requirements met
- [ ] Exemptions reviewed

**Notice and Disclosure**
- [ ] Privacy notice at collection
- [ ] Privacy policy comprehensive
- [ ] Notice of right to opt-out posted
- [ ] Notice of right to limit sensitive data (CPRA)

**Consumer Rights**
- [ ] Two methods for requests implemented
- [ ] Identity verification process defined
- [ ] 45-day response process
- [ ] No discrimination policy

**Data Inventory**
- [ ] Personal information categories documented
- [ ] Sources identified
- [ ] Business purposes documented
- [ ] Third-party disclosures tracked
- [ ] Sales/sharing tracked

**Contracts**
- [ ] Service provider agreements compliant
- [ ] Contractor agreements compliant
- [ ] Third-party agreements reviewed

**Security**
- [ ] Reasonable security procedures implemented
- [ ] Encryption for sensitive data
- [ ] Access controls
- [ ] Breach response plan

**Sensitive Personal Information** (CPRA)
- [ ] Sensitive PI identified
- [ ] Limit use mechanisms implemented
- [ ] Purpose limitations enforced

## HIPAA (Health Insurance Portability and Accountability Act)

**Official Source**: https://www.hhs.gov/hipaa/

**Scope**: Protected Health Information (PHI) in US healthcare
**Penalties**: $100 to $50,000 per violation, up to $1.5M per year

### Key Regulations

**Privacy Rule** (45 CFR Part 160 and Part 164, Subparts A and E)
- Standards for PHI privacy
- Individual rights
- Permitted uses and disclosures

**Security Rule** (45 CFR Part 164, Subpart C)
- Administrative safeguards
- Physical safeguards
- Technical safeguards

**Breach Notification Rule** (45 CFR Part 164, Subpart D)
- Individual notification
- HHS notification
- Media notification (if >500 affected)

### Privacy Rule Requirements

**Permitted Uses and Disclosures**:
- Treatment
- Payment
- Healthcare operations
- Required by law
- Public health activities
- Victims of abuse, neglect, or domestic violence
- Health oversight activities
- Judicial and administrative proceedings
- Law enforcement purposes
- Decedents
- Organ donation
- Research
- Serious threat to health or safety
- Essential government functions
- Workers' compensation

**Individual Rights**:
- Right to access PHI
- Right to amend PHI
- Right to accounting of disclosures
- Right to request restrictions
- Right to request confidential communications
- Right to paper copy of privacy notice

**Notice of Privacy Practices**:
- How PHI may be used and disclosed
- Individual rights
- Covered entity's legal duties
- Complaint procedures

### Security Rule - Administrative Safeguards

- Security management process
- Assigned security responsibility
- Workforce security
- Information access management
- Security awareness and training
- Security incident procedures
- Contingency plan
- Evaluation
- Business associate contracts

### Security Rule - Physical Safeguards

- Facility access controls
- Workstation use
- Workstation security
- Device and media controls

### Security Rule - Technical Safeguards

- Access control
- Audit controls
- Integrity controls
- Person or entity authentication
- Transmission security

### HIPAA Audit Checklist

**Privacy Rule Compliance**
- [ ] Notice of Privacy Practices provided
- [ ] Privacy policies and procedures documented
- [ ] Minimum necessary determinations
- [ ] Authorization forms compliant
- [ ] Individual rights procedures implemented
- [ ] Complaints process established

**Security Rule Compliance**
- [ ] Risk analysis conducted
- [ ] Risk management plan implemented
- [ ] Security policies and procedures documented
- [ ] Workforce training completed
- [ ] Sanctions policy for violations
- [ ] Information access controls
- [ ] Encryption implemented (where appropriate)
- [ ] Audit controls enabled
- [ ] Contingency plan with backups

**Breach Notification**
- [ ] Breach assessment procedures
- [ ] Notification procedures (individuals, HHS, media)
- [ ] Breach log maintained

**Business Associates**
- [ ] Business Associate Agreements executed
- [ ] BA compliance monitored
- [ ] Subcontractor flows documented

## SOX (Sarbanes-Oxley Act)

**Official Source**: https://www.sec.gov/

**Scope**: Publicly traded companies in US
**Focus**: Financial reporting and internal controls

### Key Sections

**Section 302**: Corporate Responsibility for Financial Reports
- CEO and CFO certification of financial reports
- Establish and maintain internal controls
- Disclosure of deficiencies and fraud

**Section 404**: Management Assessment of Internal Controls
- Annual internal control report
- Attestation by external auditor
- Document controls over financial reporting

**Section 409**: Real-Time Disclosure
- Rapid disclosure of material changes in financial condition

**Section 802**: Criminal Penalties for Document Destruction
- Penalties for destroying documents in federal investigations

### ITGC (IT General Controls) Areas

**Access Controls**:
- User access management
- Privileged access controls
- Password policies
- Segregation of duties

**Change Management**:
- Change request and approval process
- Testing requirements
- Implementation controls
- Emergency change procedures

**Computer Operations**:
- Job scheduling and monitoring
- Backup and recovery
- Incident management
- Problem management

**Program Development**:
- System development lifecycle
- Testing standards
- Security requirements
- Documentation standards

### SOX IT Audit Checklist

**Access Controls**
- [ ] User access provisioning process
- [ ] Access reviews performed periodically
- [ ] Segregation of duties enforced
- [ ] Privileged access controlled
- [ ] Terminated user access removed timely

**Change Management**
- [ ] Change management policy documented
- [ ] Changes approved before implementation
- [ ] Changes tested before production
- [ ] Emergency changes documented
- [ ] Segregation of duties in change process

**IT Operations**
- [ ] Automated job monitoring
- [ ] Backup procedures documented and tested
- [ ] Disaster recovery plan tested
- [ ] Incident management process
- [ ] Service level monitoring

**System Development**
- [ ] SDLC methodology documented
- [ ] Security requirements defined
- [ ] Testing evidence maintained
- [ ] User acceptance testing performed
- [ ] Production migration controls

## PCI DSS (Payment Card Industry Data Security Standard)

**Official Source**: https://www.pcisecuritystandards.org/

**Scope**: Entities that store, process, or transmit cardholder data
**Version**: 4.0 (effective March 2025)

### 12 Requirements (6 Goals)

**Goal 1: Build and Maintain a Secure Network and Systems**

**Requirement 1**: Install and maintain network security controls
- Firewall configuration
- Network segmentation
- Wireless security
- Configuration standards

**Requirement 2**: Apply secure configurations to all system components
- Vendor defaults changed
- Security parameters configured
- Inventory of system components
- Wireless encryption

**Goal 2: Protect Account Data**

**Requirement 3**: Protect stored account data
- Data retention policy
- Minimize stored data
- Encryption of stored data
- Cryptographic key management
- PAN masking

**Requirement 4**: Protect cardholder data with strong cryptography during transmission
- Encryption during transmission over open networks
- No sending of unprotected PANs via end-user messaging

**Goal 3: Maintain a Vulnerability Management Program**

**Requirement 5**: Protect all systems and networks from malicious software
- Anti-malware deployment
- Regular malware scans
- Malware protection mechanisms

**Requirement 6**: Develop and maintain secure systems and software
- Security patch management
- Secure development lifecycle
- Security vulnerabilities identified
- Change control processes
- Public-facing web application protection

**Goal 4: Implement Strong Access Control Measures**

**Requirement 7**: Restrict access to system components and cardholder data by business need to know
- Limit access based on job function
- Access control systems
- Default "deny all"

**Requirement 8**: Identify users and authenticate access to system components
- User identification assignment
- Multi-factor authentication
- Strong authentication for all access
- Password/passphrase requirements

**Requirement 9**: Restrict physical access to cardholder data
- Facility entry controls
- Physical security controls
- Media handling and disposal

**Goal 5: Regularly Monitor and Test Networks**

**Requirement 10**: Log and monitor all access to system components and cardholder data
- Audit log implementation
- Time synchronization
- Log review procedures
- Audit trail protection

**Requirement 11**: Test security of systems and networks regularly
- Wireless access point inventory
- Vulnerability scans
- Penetration testing
- Intrusion detection/prevention
- File integrity monitoring
- Change detection

**Goal 6: Maintain an Information Security Policy**

**Requirement 12**: Support information security with organizational policies and programs
- Security policy establishment and maintenance
- Risk assessment process
- Security awareness program
- Personnel screening
- Service provider management
- Incident response plan

### PCI DSS Audit Checklist

**Network Security**
- [ ] Firewall rules documented and reviewed
- [ ] Network diagram current
- [ ] DMZ implemented
- [ ] Wireless networks secured
- [ ] Default accounts/passwords changed

**Data Protection**
- [ ] Cardholder data inventory
- [ ] Data retention policy enforced
- [ ] Sensitive authentication data not stored post-authorization
- [ ] PAN masked when displayed
- [ ] Encryption keys protected

**Vulnerability Management**
- [ ] Anti-malware installed and updated
- [ ] Security patches applied monthly
- [ ] Vulnerability scans quarterly
- [ ] Web application firewall deployed
- [ ] Secure coding practices

**Access Control**
- [ ] Access based on need-to-know
- [ ] MFA for remote access and CDE
- [ ] Unique IDs for all users
- [ ] Physical access controls
- [ ] Media destruction procedures

**Monitoring and Testing**
- [ ] Audit logging enabled
- [ ] Logs reviewed daily
- [ ] Time synchronization
- [ ] IDS/IPS deployed
- [ ] Penetration testing annually
- [ ] File integrity monitoring

**Security Policy**
- [ ] Information security policy
- [ ] Risk assessment annually
- [ ] Security awareness training
- [ ] Background checks for personnel
- [ ] Incident response plan tested
- [ ] Service provider compliance verified

## COPPA (Children's Online Privacy Protection Act)

**Official Source**: https://www.ftc.gov/legal-library/browse/rules/childrens-online-privacy-protection-rule-coppa

**Scope**: Online services directed to children under 13 or with actual knowledge of collecting children's data
**Penalties**: Up to $46,517 per violation

### Requirements

**Parental Notice and Consent**:
- Clear privacy policy
- Direct notice to parents
- Verifiable parental consent before collection
- Opportunity for parents to review child's information
- Ability to revoke consent

**Data Minimization**:
- Collect only necessary information
- No conditioning participation on providing more data than needed

**Data Security**:
- Reasonable procedures to protect collected information
- Retention only as long as necessary

**Data Deletion**:
- Provide parents ability to delete child's information

### COPPA Audit Checklist

- [ ] Privacy policy compliant and posted
- [ ] Parental notice provided
- [ ] Verifiable parental consent obtained
- [ ] Consent mechanism appropriate
- [ ] Data minimization practiced
- [ ] Parents can review child's information
- [ ] Parents can delete child's information
- [ ] Reasonable security measures
- [ ] Third-party data sharing disclosed
- [ ] Operators of child-directed portions identified

## Common Compliance Findings

### Documentation Issues
- Missing or incomplete privacy notices/policies
- Policies not updated for regulatory changes
- Lack of data processing records
- Missing vendor contracts
- Inadequate procedure documentation

### Rights Management Issues
- No process to handle subject rights requests
- Delayed responses to requests (beyond regulatory timeframes)
- Inability to locate or delete data upon request
- No identity verification process
- Missing request tracking

### Consent Issues
- Invalid or unclear consent mechanisms
- Consent not freely given
- Inability to withdraw consent
- Pre-checked boxes (GDPR)
- Consent not documented

### Security Issues
- Lack of encryption for sensitive data
- Inadequate access controls
- No regular security assessments
- Missing incident response procedures
- Insufficient logging and monitoring

### Third-Party Issues
- Missing data processing agreements
- No vendor risk assessments
- Inadequate contract terms
- Unknown subprocessors
- No vendor compliance verification

### Cross-Border Transfer Issues
- Inadequate transfer mechanisms
- Missing standard contractual clauses
- No transfer impact assessments
- Lack of adequacy determinations

### Breach Response Issues
- Delays in breach notification
- Incomplete breach documentation
- No breach response plan
- Failure to notify required parties
- Missing breach register

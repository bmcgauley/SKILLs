# Cybersecurity Frameworks Reference

## Overview

This reference provides detailed information on major cybersecurity frameworks for conducting IT and cybersecurity audits. Use when auditing information security controls, cybersecurity programs, or IT risk management.

## NIST Cybersecurity Framework (CSF) 2.0

**Official Source**: https://www.nist.gov/cyberframework

### Six Core Functions

1. **GOVERN (GV)** - Establish and monitor governance structure
2. **IDENTIFY (ID)** - Understand cybersecurity risks
3. **PROTECT (PR)** - Implement safeguards
4. **DETECT (DE)** - Find cybersecurity events
5. **RESPOND (RS)** - Take action on detected events
6. **RECOVER (RC)** - Restore capabilities after incidents

### Function: GOVERN (GV)

**GV.OC** - Organizational Context
- Risk management strategy established
- Cybersecurity supply chain risks addressed
- Legal and regulatory requirements identified

**GV.RM** - Risk Management Strategy
- Priorities established based on risk assessment
- Risk tolerance levels defined
- Risk management processes integrated

**GV.RR** - Roles and Responsibilities
- Cybersecurity responsibilities assigned
- Coordination among teams established
- Third-party responsibilities defined

**GV.PO** - Policy
- Policies address purpose, scope, roles, and responsibilities
- Policies communicated to stakeholders
- Policies regularly reviewed and updated

**GV.OV** - Oversight
- Results of risk assessments inform governance
- Governance informed by cybersecurity posture
- Continuous improvement processes in place

### Function: IDENTIFY (ID)

**ID.AM** - Asset Management
- Physical devices and systems inventoried
- Software platforms and applications inventoried
- Data flows mapped and documented
- External information systems cataloged

**ID.RA** - Risk Assessment
- Vulnerabilities identified and documented
- Cyber threat intelligence received from sources
- Threats (internal and external) identified
- Risk response priorities determined

**ID.IM** - Improvement
- Improvement opportunities from activities identified
- Response and recovery plans tested
- Findings from security events incorporated

**ID.SC** - Supply Chain Risk Management
- Supply chain managed using a strategy
- Suppliers and third-party partners assessed
- Contracts include cybersecurity requirements

### Function: PROTECT (PR)

**PR.AA** - Identity Management and Access Control
- Identities and credentials managed
- Access to assets and data controlled
- Remote access managed
- Physical access controlled

**PR.AT** - Awareness and Training
- Personnel trained and aware
- Privileged users understand responsibilities
- Third-party stakeholders understand responsibilities

**PR.DS** - Data Security
- Data-at-rest protected
- Data-in-transit protected
- Assets formally managed throughout lifecycle
- Availability maintained

**PR.PS** - Platform Security
- Configuration management processes established
- Baselines created and maintained
- Change control processes in place
- Removable media protected

**PR.IR** - Technology Infrastructure Resilience
- Networks protected (segmented, limited)
- Control environment protected
- Resilience incorporated into design

### Function: DETECT (DE)

**DE.CM** - Continuous Monitoring
- Network monitored for anomalous activity
- Physical environment monitored
- Personnel activity monitored
- Malicious code detected

**DE.AE** - Adverse Event Analysis
- Roles and responsibilities for detection defined
- Detected events analyzed for impact
- Information correlated from multiple sources
- Impact of events understood

### Function: RESPOND (RS)

**RS.MA** - Incident Management
- Response plan executed during incidents
- Personnel know their incident response roles
- Information shared per plan
- Coordination with stakeholders occurs

**RS.AN** - Incident Analysis
- Notifications from detection systems investigated
- Impact of incidents understood
- Forensics performed
- Incidents categorized per plan

**RS.MI** - Incident Mitigation
- Incidents contained
- Incidents mitigated
- Incidents resolved
- Information from response activities used

### Function: RECOVER (RC)

**RC.RP** - Recovery Planning
- Recovery plan executed during events
- Recovery plan updated based on lessons learned

**RC.IM** - Recovery Implementation
- Communications coordinated internally and externally
- Services restored
- Assets restored

**RC.CO** - Recovery Communication
- Public relations managed
- Reputation repaired after incident
- Recovery activities communicated to stakeholders

## ISO/IEC 27001:2022 - Information Security Management

**Official Source**: https://www.iso.org/standard/82875.html

### Annex A Control Sets (93 Controls)

**Organizational Controls (37)**
- Information security policies
- Organization of information security
- Human resources security
- Asset management
- Access control
- Cryptography
- Physical and environmental security
- Operations security
- Communications security
- System acquisition, development and maintenance
- Supplier relationships
- Information security incident management
- Information security aspects of business continuity
- Compliance

**People Controls (8)**
- Screening
- Terms and conditions of employment
- Information security awareness, education and training
- Disciplinary process
- Responsibilities after termination or change
- Confidentiality agreements
- Remote working
- Information security event reporting

**Physical Controls (14)**
- Physical security perimeters
- Physical entry controls
- Securing offices, rooms and facilities
- Monitoring and logging
- Protecting against physical and environmental threats
- Working in secure areas
- Clear desk and clear screen
- Equipment siting and protection
- Security of assets off-premises
- Storage media
- Supporting utilities
- Cabling security
- Equipment maintenance
- Secure disposal of equipment

**Technological Controls (34)**
- User endpoint devices
- Privileged access rights
- Information access restriction
- Access to source code
- Secure authentication
- Capacity management
- Protection against malware
- Management of technical vulnerabilities
- Configuration management
- Information deletion
- Data masking
- Data leakage prevention
- Information backup
- Redundancy of information processing facilities
- Logging
- Monitoring activities
- Clock synchronization
- Use of privileged utility programs
- Installation of software on operational systems
- Network security
- Security of network services
- Segregation of networks
- Web filtering
- Use of cryptography
- Secure development lifecycle
- Application security requirements
- Secure system architecture and engineering principles
- Secure coding
- Security testing in development and acceptance
- Outsourced development
- Separation of development, testing and production
- Change management
- Test information
- Protection of information systems during audit testing

### ISO 27001 Audit Approach

**Document Review**:
- Information Security Policy
- Risk Assessment and Treatment Plan
- Statement of Applicability
- Security procedures and controls documentation

**Evidence Collection**:
- Asset inventory records
- Access control logs
- Incident reports
- Backup and recovery tests
- Training records
- Vendor contracts and SLAs

**Testing**:
- Access control effectiveness
- Encryption implementation
- Incident response procedures
- Business continuity plans
- Change management process

## CIS Critical Security Controls v8

**Official Source**: https://www.cisecurity.org/controls

### Implementation Groups

**IG1** - Essential cyber hygiene (small organizations, limited resources)
**IG2** - Increases depth of defenses (mid-size organizations)
**IG3** - Advanced capabilities (large organizations, mature programs)

### 18 CIS Controls

**Control 1: Inventory and Control of Enterprise Assets**
- Establish and maintain hardware asset inventory
- Address unauthorized assets
- Utilize asset inventory for lifecycle management

**Control 2: Inventory and Control of Software Assets**
- Establish and maintain software inventory
- Address unauthorized software
- Use software inventory for vulnerability management

**Control 3: Data Protection**
- Establish and maintain data management process
- Establish and maintain data inventory
- Configure data access control lists
- Enforce data retention policies

**Control 4: Secure Configuration of Enterprise Assets and Software**
- Establish and maintain secure configuration process
- Establish and maintain secure configurations
- Configure automatic session locking
- Implement and manage firewall on servers

**Control 5: Account Management**
- Establish and maintain account inventory
- Use unique passwords
- Disable dormant accounts
- Restrict administrator privileges to dedicated accounts

**Control 6: Access Control Management**
- Establish access granting process
- Establish access revoking process
- Require MFA
- Restrict root and admin access

**Control 7: Continuous Vulnerability Management**
- Establish and maintain vulnerability management process
- Establish and maintain remediation process
- Perform automated vulnerability scans
- Remediate detected vulnerabilities

**Control 8: Audit Log Management**
- Establish and maintain audit log management process
- Collect audit logs
- Ensure adequate storage for logs
- Standardize time synchronization

**Control 9: Email and Web Browser Protections**
- Ensure use of only fully supported browsers
- Use DNS filtering services
- Maintain and enforce email anti-malware
- Block unnecessary file types

**Control 10: Malware Defenses**
- Deploy and maintain anti-malware software
- Configure automatic anti-malware updates
- Disable autorun and autoplay for removable media
- Enable anti-exploitation features

**Control 11: Data Recovery**
- Establish and maintain data recovery process
- Perform automated backups
- Protect recovery data
- Establish and maintain isolated instance of recovery data

**Control 12: Network Infrastructure Management**
- Ensure network infrastructure is up-to-date
- Establish and maintain secure network architecture
- Securely manage network infrastructure
- Centralize network authentication

**Control 13: Network Monitoring and Defense**
- Centralize security event alerting
- Deploy network-based IDS
- Deploy network-based IPS
- Perform traffic filtering between network segments

**Control 14: Security Awareness and Skills Training**
- Establish security awareness program
- Train workforce members on secure authentication
- Train workforce members on data handling
- Train workforce on causes of social engineering

**Control 15: Service Provider Management**
- Establish and maintain inventory of service providers
- Establish and maintain service provider management policy
- Classify service providers
- Monitor service providers

**Control 16: Application Software Security**
- Establish and maintain secure application development process
- Establish and maintain software development security standards
- Perform root cause analysis on security vulnerabilities
- Establish and maintain application security testing

**Control 17: Incident Response Management**
- Establish and maintain incident response process
- Establish and maintain incident response team
- Establish and maintain contact information
- Require post-incident review

**Control 18: Penetration Testing**
- Establish and maintain penetration testing program
- Perform periodic external penetration tests
- Remediate penetration test findings
- Validate security measures

## COBIT 2019

**Official Source**: https://www.isaca.org/resources/cobit

### Governance and Management Objectives

**Governance Objectives**:
- EDM01: Ensured governance framework setting and maintenance
- EDM02: Ensured benefits delivery
- EDM03: Ensured risk optimization
- EDM04: Ensured resource optimization
- EDM05: Ensured stakeholder engagement

**Management Objectives**:

**Align, Plan and Organize (APO)**:
- APO01: Managed IT management framework
- APO02: Managed strategy
- APO03: Managed enterprise architecture
- APO04: Managed innovation
- APO05: Managed portfolio
- APO06: Managed budget and costs
- APO07: Managed human resources
- APO08: Managed relationships
- APO09: Managed service agreements
- APO10: Managed suppliers
- APO11: Managed quality
- APO12: Managed risk
- APO13: Managed security
- APO14: Managed data

**Build, Acquire and Implement (BAI)**:
- BAI01: Managed programs
- BAI02: Managed requirements definition
- BAI03: Managed solutions identification and build
- BAI04: Managed availability and capacity
- BAI05: Managed organizational change
- BAI06: Managed IT changes
- BAI07: Managed IT change acceptance and transitioning
- BAI08: Managed knowledge
- BAI09: Managed assets
- BAI10: Managed configuration
- BAI11: Managed projects

**Deliver, Service and Support (DSS)**:
- DSS01: Managed operations
- DSS02: Managed service requests and incidents
- DSS03: Managed problems
- DSS04: Managed continuity
- DSS05: Managed security services
- DSS06: Managed business process controls

**Monitor, Evaluate and Assess (MEA)**:
- MEA01: Managed performance and conformance monitoring
- MEA02: Managed system of internal control
- MEA03: Managed compliance with external requirements
- MEA04: Managed assurance

## SOC 2 Trust Services Criteria

**Official Source**: https://www.aicpa.org/

### Trust Services Categories

**Security** (Common Criteria - applies to all SOC 2 reports):
- CC1: Control environment
- CC2: Communication and information
- CC3: Risk assessment
- CC4: Monitoring activities
- CC5: Control activities
- CC6: Logical and physical access controls
- CC7: System operations
- CC8: Change management
- CC9: Risk mitigation

**Availability** (Additional Criteria):
- A1: System availability
- A2: Performance
- A3: System monitoring
- A4: Recovery and business continuity

**Processing Integrity** (Additional Criteria):
- PI1: Processing integrity
- PI2: Quality of outputs
- PI3: Data quality

**Confidentiality** (Additional Criteria):
- C1: Confidential information protection
- C2: Disposal of confidential information

**Privacy** (Additional Criteria):
- P1: Notice and communication
- P2: Choice and consent
- P3: Collection
- P4: Use, retention, and disposal
- P5: Access
- P6: Disclosure to third parties
- P7: Quality
- P8: Monitoring and enforcement

## Common Cybersecurity Audit Findings

### Access Control Issues
- Shared administrative accounts
- Lack of multi-factor authentication
- Excessive user permissions
- No periodic access reviews
- Weak password policies

### Network Security Issues
- Lack of network segmentation
- Unencrypted sensitive data transmission
- Missing or misconfigured firewalls
- Open unnecessary ports and services
- No intrusion detection/prevention

### Vulnerability Management Issues
- Missing critical security patches
- No regular vulnerability scanning
- Extended remediation timelines
- Unmanaged shadow IT
- End-of-life systems in use

### Logging and Monitoring Issues
- Insufficient logging coverage
- No log retention policy
- Logs not regularly reviewed
- No centralized log management
- Missing security event alerting

### Incident Response Issues
- No documented incident response plan
- Plan not tested regularly
- Unclear roles and responsibilities
- No communication procedures
- Insufficient forensic capabilities

### Data Protection Issues
- Sensitive data not encrypted
- No data classification scheme
- Inadequate data backup
- Backups not tested
- No data loss prevention controls

### Third-Party Risk Issues
- No vendor security assessments
- Missing SLA security requirements
- No ongoing vendor monitoring
- Inadequate contract terms
- Lack of vendor inventory

## Framework Mapping Resources

**CIS to NIST CSF**: https://www.cisecurity.org/controls/cis-controls-navigator
**NIST CSF to ISO 27001**: https://www.nist.gov/cyberframework/informative-references
**COBIT to Multiple Frameworks**: https://www.isaca.org/resources/cobit

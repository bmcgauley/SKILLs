# YouTube Video Intro Framework

This reference provides the complete strategy for creating video intros that prevent viewer drop-off and create immediate immersion.

## Core Problem: The 90% Drop Phenomenon

**Reality:** Most videos lose massive portions of audience in opening seconds.

**Root Cause:** Viewers click based on title/thumbnail promises, then get DISAPPOINTED when intro doesn't deliver what they expected.

**Central Thesis:** Intro must immediately live up to expectations created by title and thumbnail, both in CONTENT and FEELING.

## Strategy 1: Simultaneous Creation

### The Genius Technique of Top Creators

**What They Do:** Create titles, thumbnails, and intros **at the same time**.

### The Process

**Step 1: Create Title and Thumbnail**
- Craft compelling external marketing
- Make specific promises
- Generate specific curiosity

**Step 2: Ask Critical Questions**
- "What reason to watch did I just give?"
- "What expectations did I create?"
- "What am I promising explicitly?"
- "What am I promising implicitly?"

**Step 3: Create Matching Intro**
- Immediately live up to those expectations
- Show what was promised in title/thumbnail
- Deliver it in the intro

### The Fundamental Rule

**If you put something in title and thumbnail, you MUST show it in intro.**

This isn't optional. This is baseline requirement for intro success.

## Strategy 2: Pacing, Mood, and Style Matching

### Beyond Content: The Feeling Promise

**Critical Insight:** Titles and thumbnails don't just promise content—they promise a **FEELING** and **STYLE**.

### Case Study: Mr. Beast Train Crash Video

**The Title/Thumbnail Promise:**
- Content: Train crash
- Feeling: Action, excitement, intensity

**The Intro Delivery (First 5 Seconds):**

**Visual Elements:**
- Effect makes it seem like we're rushing up to Jimmy
- Train rapidly emerges
- Dynamic camera movement

**Audio Elements:**
- Train horn sound effects
- Jimmy immediately yelling
- High energy vocal delivery

**Pacing:**
- Jimmy spits out 5 words in first second
- Multiple things happening simultaneously
- Complete sensory overload (intentional)

**Timestamp 0:00-0:01 (1 second):**
- Camera rush effect
- Train appears
- Sound effects trigger
- Jimmy starts yelling
- 5 words spoken

**Result:** Viewer drawn in by quick delivery matching promised style.

### Case Study: I Did a Thing - Pool Lifeguard Robot

**The Title/Thumbnail Promise:**
- Content: Solution to problem
- Feeling: Light-hearted, not too serious, quirky

**The Intro Delivery (First 22 Seconds):**

**Opening:**
- "How you going, this is my pool"
- Dives into pool (literally)
- Shows dead frog
- Shows dead skink
- Explains problem comedically

**Pacing Contrast:**
- Takes 22 seconds just to explain problem
- Much slower than Mr. Beast
- Still gets 10 million views

**Why It Works:**
- Started explaining problem immediately (content promise met)
- Approached light-heartedly (feeling promise met)
- Used humor throughout (style promise met)
- Comic tone matched thumbnail expectations

### The Critical Rule for All Content

**Create intros at appropriate pacing for:**
1. Genre of your content
2. Style seen in thumbnail

**Key Principle:** Different genres require different pacing. Match intro pacing to what title/thumbnail implied.

## Strategy 3: Visual Storytelling Through Voiceover

### Traditional Approach (Weak)
- Sit in front of camera
- Talk through problem
- Static, single-angle delivery

### Voiceover Approach (Powerful)
- Show situation while explaining
- Multiple camera angles
- Camera switches every ~4 seconds
- Maintains visual engagement

**Why Voiceovers Are Crucial:**
- Grant ability to deliver **strong audio AND visuals simultaneously**
- Essential for intro success
- Allows visual variety while maintaining narrative clarity
- Prevents static "talking head" fatigue

## Strategy 4: Information Architecture Through Storytelling

### The Hidden Genius

**Insight:** How information is presented matters more than speed.

### Case Study: "I Did a Thing" Script Analysis

**Initial Question:** Why explain everything so slowly?

**The Reveal:** Information presented in way that **connects viewers to narrative**.

**Example: The Dead Animals**
- **Bland Approach:** "Animals keep drowning in my pool"
- **Storytelling Approach:**
  1. Introduce the frog
  2. Show it's dead
  3. Introduce the skink
  4. Show it's also dead
  5. Create pattern/mystery
  6. Reveal the problem

**Why This Works:**
- Creates micro-hooks within intro
- Each piece of information builds curiosity
- Pattern recognition engages viewers
- More engaging even though takes longer

### The Power of Storytelling

**Principle:** Storytelling is **extremely powerful tool** to hook viewers.

**Application:** Don't just state facts—reveal them in ways that create narrative momentum.

**Trade-off:** May take longer to deliver information, but creates much stronger engagement.

## Strategy 5: Writing Great Intros - The Optimization Process

### Why Multiple Rewrites Matter

**Approach:** Rewrite intros up to **5 times**.

**Reason:** Intros have a lot to accomplish in short time window.

### The Optimization Challenge

Intros must:
1. Meet content expectations
2. Match feeling/style promises
3. Maintain pacing appropriate to genre
4. Hook viewers emotionally
5. Set up rest of video
6. Do all of this in seconds

### What to Optimize

**1. Best Adjectives**
- Choose words that create maximum impact
- Evoke specific feelings
- Match promised tone

**2. Sentence Structure**
- Flow and rhythm matter
- Cadence affects perceived pacing
- Structure creates emphasis

**3. Detail Level**
- Balance between clarity and intrigue
- Avoid over-explanation
- Know what to include vs. leave out

**4. Information Order**
- Sequence of reveals
- What comes first, second, third
- Building narrative momentum

### The Golden Rule

**Every sentence must be as meaningful as possible.**

No wasted words. No filler. Every phrase must contribute to:
- Meeting expectations
- Building engagement
- Advancing narrative
- Maintaining pacing

## Strategy 6: Editing - The Other Half of Success

### The Critical Insight

**Editing matters just as much as script.**

Words are only 50% of equation. How those words are presented is other 50%.

### The Editing Formula

**Add these elements every few seconds:**
1. Graphics
2. Sound effects
3. Captions/text overlays
4. Transitions
5. Music shifts
6. Visual changes

**Frequency:** "Every few seconds" - constant stimulation appropriate to genre

### Critical Focus Areas

**1. Sound Design**
- Layered sound effects
- Music selection and timing
- Audio transitions
- Emphasis through sound
- Creating auditory texture

**2. Visual Variety**
- Camera angle changes
- Graphics and overlays
- B-roll insertion
- Text animations
- Color/lighting shifts

**Purpose:** Give viewer **more new things to look at** constantly.

### The Principle

More sensory input = better engagement (within reason for genre)

Viewer's brain should constantly process new information without being overwhelmed.

## Strategy 7: Exceeding Expectations (Advanced)

### Why Meeting Expectations Isn't Enough

**The Competition Problem:** YouTube is highly competitive. Meeting expectations is baseline, not goal.

**The Winning Move:** Obliterate expectations entirely.

### The Precedent Effect

**What Happens:** When you exceed expectations in intro, you set precedent that raises bar for entire video.

**Result:** Viewers gain extra confidence that video is worth their time.

**Psychological Impact:** "If intro is THIS good, imagine the rest!"

### The Strategy Framework

**Step 1: Know Your Audience**

**Critical Questions:**
- Who are people that clicked your video?
- What else would they also want to know?
- What else would they also want to see?
- What related topics would interest them?

**Step 2: Reveal Additional Value**

**Method:** Take time in intro to let viewers know your video offers **more value than just what you initially said it would**.

**Implementation:** Promise additional content/value beyond title/thumbnail.

### The Titling Implication

**Problem with Comprehensive Titles:**
- Makes sense to wrap everything into short sentence
- Leaves nothing to surprise people with in intro
- Describing everything often less interesting

**Better Approach:**
- Describe only coolest part in title/thumbnail
- Save additional value for intro reveal
- Create surprise and delight

### Case Study: Mr. Beast Train Crash (Advanced)

**Initial Promise (0:00-0:05)**
- Train crash confirmed
- Action delivered
- Expectations met

**The Exceed Strategy (0:05-0:20)**

**What He Does:** "We're also crashing countless [other things]... just to show you the most insane experiments of all time, starting with filling a house with over 100,000 fireworks."

**Analysis:**
1. Met initial expectations first (crucial)
2. Then revealed ADDITIONAL content
3. Promised "most insane experiments of all time"
4. Gave specific example (fireworks)
5. Raised stakes exponentially

**Pattern Across Mr. Beast Videos:**
- This strategy appears in almost all his videos
- Not required for success
- Likely major contributor to explosive growth

### The Exceed Formula

**Step 1:** Meet promised expectation (content + feeling)
**Step 2:** Immediately reveal additional value
**Step 3:** Make it specific and exciting
**Step 4:** Raise stakes beyond initial promise

**Result:** Viewer thinks "I came for X, but I'm getting X + Y + Z!"

## Complete Intro Strategy Summary

### The Foundation Layer

**1. Simultaneous Creation**
- Create title, thumbnail, and intro together
- Ensure perfect alignment of promises
- Ask what expectations were created
- Design intro to meet those expectations

**2. Content + Feeling Delivery**
- Deliver promised content immediately
- Match promised feeling/energy/style
- Maintain appropriate pacing for genre
- Both must be present in first seconds

### The Engagement Layer

**3. Voiceover Power**
- Use voiceovers to separate audio and visual
- Switch camera angles every ~4 seconds
- Show while explaining
- Maintain visual variety

**4. Storytelling Structure**
- Present information as narrative
- Use reveal sequences
- Create micro-hooks within intro
- Connect viewers emotionally to content

### The Optimization Layer

**5. Script Refinement**
- Rewrite multiple times (up to 5+)
- Optimize adjectives
- Perfect sentence structure
- Balance detail level
- Order information strategically
- Make every sentence meaningful

**6. Editing Excellence**
- Add graphics every few seconds
- Layer sound effects throughout
- Use dynamic captions
- Include smooth transitions
- Choose music carefully
- Maintain constant visual changes
- Focus on sound design and visual variety

### The Excellence Layer

**7. Exceeding Expectations**
- Know your audience deeply
- Reveal additional value in intro
- Save surprises for intro
- Raise stakes beyond initial promise
- Set high precedent for entire video

## Genre-Specific Adaptations

### High-Energy Content (Action, Challenges, Stunts)

**Pacing:** Very fast, immediate action
**First Second:** Core promise delivered
**Editing:** Rapid cuts, intense sound design
**Feeling:** Adrenaline, excitement, urgency
**Example:** Mr. Beast train crash

### Educational/Explanatory Content

**Pacing:** Moderate, clear explanation
**First Few Seconds:** Problem/question introduced
**Editing:** Graphics support understanding
**Feeling:** Curiosity, intellectual engagement
**Example:** Learn By Leo videos

### DIY/Project Content

**Pacing:** Light-hearted, not rushed
**First Few Seconds:** Problem shown visually
**Editing:** Visual storytelling emphasized
**Feeling:** Quirky, creative, approachable
**Example:** I Did a Thing pool robot

### The Principle

**Different genres require different execution of same principles.**

Strategies remain constant. Application varies by content type.

## Common Mistakes to Avoid

**Mistake 1: Creating Intro Before Title/Thumbnail**
- Problem: Leads to misalignment
- Fix: Create simultaneously

**Mistake 2: Only Delivering Content, Not Feeling**
- Problem: Viewers feel something is "off"
- Fix: Match both content AND emotional promises

**Mistake 3: Wrong Pacing for Genre**
- Problem: Creates expectation mismatch
- Fix: Study successful videos in your genre

**Mistake 4: Talking Head Without Visual Variety**
- Problem: Immediate visual boredom
- Fix: Use voiceovers with B-roll

**Mistake 5: Stating Facts Instead of Storytelling**
- Problem: Disengagement despite correct information
- Fix: Structure information as narrative reveals

**Mistake 6: Script Without Editing Enhancement**
- Problem: Flat delivery despite good writing
- Fix: Layer graphics, SFX, captions, transitions

**Mistake 7: Meeting Expectations Without Exceeding**
- Problem: Acceptable but not competitive
- Fix: Reveal additional value in intro

**Mistake 8: Comprehensive Titles That Leave Nothing for Intro**
- Problem: No way to surprise/exceed expectations
- Fix: Title only coolest part, reveal more in intro

## The Complete Intro Checklist

### Pre-Production
- [ ] Title and thumbnail created
- [ ] Expectations identified (content + feeling)
- [ ] Intro designed to match both
- [ ] Pacing appropriate for genre determined
- [ ] Additional value points identified

### Script Phase
- [ ] Opens with promised content
- [ ] Matches promised feeling/style
- [ ] Uses storytelling structure
- [ ] Information ordered strategically
- [ ] Every sentence is meaningful
- [ ] Rewritten multiple times
- [ ] Reveals additional value (if applicable)

### Production Phase
- [ ] Voiceover recorded (if using)
- [ ] Multiple camera angles captured
- [ ] Visual variety planned
- [ ] B-roll gathered

### Editing Phase
- [ ] Camera switches every ~4 seconds
- [ ] Graphics added every few seconds
- [ ] Sound effects layered throughout
- [ ] Captions included
- [ ] Transitions smooth and engaging
- [ ] Music enhances experience
- [ ] Constant visual changes maintained
- [ ] Sound design focused and intentional

### Quality Control
- [ ] First 5 seconds deliver on promise
- [ ] Pacing matches genre/style
- [ ] No wasted words
- [ ] Visual engagement maintained
- [ ] Audio engagement maintained
- [ ] Exceeds initial expectations (when possible)

## Key Philosophical Insights

1. **Promises Must Be Kept Immediately:** Every second expectations aren't met is second they might leave
2. **Feeling Equals Content in Importance:** What video feels like is just as important as what it's about
3. **Genre Determines Execution, Not Strategy:** Principles universal, pacing and style change by genre
4. **Editing Is Half the Equation:** Perfect script + poor editing = failure
5. **Competition Requires Excellence:** Meeting expectations = baseline, exceeding = competitive advantage
6. **Storytelling Beats Information Delivery:** Humans wired for narrative, use it
7. **Optimization Is Not Optional:** First drafts never good enough, rewrite until every word matters

## Critical Success Metrics

### The First 5 Seconds

**Absolute Priority:** First 5 seconds must deliver on core promise.

**Why:** This is where 90% of drop-off occurs. If you lose them here, nothing else matters.

**Minimum Requirements:**
1. Promised content visible/confirmed
2. Promised feeling present
3. Appropriate pacing established
4. Visual engagement active
5. Audio engagement active

### The Next 15 Seconds

**Opportunity Window:** Exceed expectations and set precedent.

**Mr. Beast Pattern:** Uses seconds 5-20 to reveal additional value.

**Purpose:** Transform retention from "not leaving yet" to "actively excited to stay."

### The Full Intro (0-30 seconds)

**Complete Job:**
1. Meet content promise
2. Match feeling/style
3. Maintain genre-appropriate pacing
4. Hook through storytelling
5. Engage through editing
6. Exceed expectations
7. Set precedent for video
8. Create confidence in video value

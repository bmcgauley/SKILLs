# YouTube Video Editing Framework (Four Pillars)

This reference provides the complete four-pillar editing formula for creating addictive videos that maximize viewer retention and engagement.

## Opening Philosophy

**Promise:** Editing so good that viewers can't resist watching until the end.

**What This Is:**
- Years of editing experience boiled down into four pillars
- Goes way deeper than basic things like cutting out dead space
- Not tutorials, but foundational starting point to know what tutorials to watch

## The Hard Truth: Context Determines Success

### The Paradox

**Reality:** A great editing style may get you:
- ✅ Perfect watch time and millions of views
- OR
- ❌ Terrible view counts and broken dreams

**Why?** Context and audience expectations matter more than technical skill.

### Case Study: Sam Sulek

**The Setup:**
- Just Sam in car talking, then working out
- Video lasts 26 minutes
- Has only 17 cuts
- No other form of editing
- Zero fancy effects or animations

**The Results:**
- 12.9 MILLION subscribers
- Massive view counts
- Highly successful channel

**Initial Reaction:** "So editing is optional, right?"

**The Reality: Sam DID Edit**

**What He Did:**
- Cut out all boring parts
- Removed what viewers didn't come to see
- Left it at that deliberately

**Why This Works:**
- His viewers aren't looking for super stimulating experience
- They want to feel like they're spending time with someone
- Quick cuts and flashy animations would **RUIN** that authentic experience
- Would disrupt what viewer came to video for

### The Critical Principle

**A disruption of what viewer came to video for is the best way to make them stop watching.**

### Mr. Beast: The Opposite Extreme

**Sam's Style:**
- Average of 90 seconds between cuts
- Minimal editing
- Authentic, personal feel

**Mr. Beast's Style:**
- Rapid-fire editing
- Cuts every few seconds
- Maximum stimulation

**Both work. Why?**

### The Question: What Should You Do?

**Answer:** Start with considering what experience your viewers want.

### Two Extremes on YouTube

**Sam's Audience:**
- Come to feel like they're hanging out with someone
- Want authenticity
- Want personal connection
- Prefer slow, natural pacing

**Mr. Beast's Audience:**
- Come for entertainment
- Want stimulation
- Want rapid pacing
- Prefer high energy

### All Editing Choices Contribute to Experience

**Example Trade-off:**
- Cutting out all pauses = constantly speaking
- **Good for:** Entertainment (most important thing)
- **Bad for:** Authenticity (takes away from it)

**The Rule:** An effective editing style takes all these choices into account.

### Application to Your Content

**As you learn four pillars:**
- Take notes on what suits YOUR audience best
- Not all techniques will apply to your niche
- Choose based on experience your viewers want
- Context determines which pillars to emphasize

## Pillar 1: Healthy Variety of Visuals

### The Problem with Typical Editing

**Example Timeline Analysis:**
- Couple cuts removed unnecessary bits
- Tangent removed (not relevant to video's purpose)
- Pauses cut out
- Bad takes removed

**Current State:** Clean but doomed to fall short of potential.

**Why?** This video isn't using its visuals to maximize attention.

### The Attention Mechanism

**Principle:** When you see change in vision (something moving abruptly), it gets your attention.

**Application:** Same is true for watching video.

**Problem:**
- Only 3 different things to look at in span of minute
- Kind of boring

**Solution:**
- Switch between A-roll, B-roll, and other types of footage
- Every few seconds
- Keeps attention much better

### The Visual Variety Toolkit

#### A-Roll

**Definition:** When you can both see and hear subject at same time.

**Characteristics:**
- Feels personal
- Holds attention really well

**When to Use:**
- Speaking with confidence
- Short periods of time
- Saying something important

**Strategic Purpose:** Direct connection and emphasis.

#### B-Roll

**Definition:** Extra footage recorded separately from audio.

**Purpose:**
- Creates visual depiction of your words
- Lets viewer see what you're talking about
- Instead of just looking at your face

**Benefits:**
- Get things across much more clearly
- Faster communication
- More interesting than A-roll

**Usage Rule:** Use as much as possible.

**Variants:**

**1. Stock Footage**
- Described as "lazy version" of B-roll
- Use when necessary but prefer original footage

**2. Motion Graphics**
- Improve explanation times dramatically
- Essential for complex information

### Motion Graphics: The Power Example

**Case Study: Dude Perfect Video**

**Situation:** Need to explain complicated math problem in story.

**Challenge:** Essential but boring moment.

**Wrong Approaches:**
- A-roll would be too slow
- Normal B-roll would be terribly confusing
- Both would lose viewers

**Right Approach:**
- Animation explained it crystal clear and fast
- Maintained pacing
- Kept viewers engaged

**The Lesson:** "That's the sort of editing choice you need to make to create an addictive video."

### The Drawback: Visual Mush

**The Risk:** All this visual variety can quickly become visual mush if done wrong.

**Problem Scenario:**
- Trying to be engaging
- Cutting between different clips literally as much as possible
- Result: Making things confusing
- Confusing = Hurts engagement

### The Balance: Shot Duration Strategy

**Wrong Approach:** Don't minimize shot duration just for sake of minimizing shot duration.

**Right Approach:** It's okay to leave same clip on screen for 10 seconds if it's interesting for 10 seconds.

**Principle:** Quality of engagement > Quantity of cuts

### Adding Engagement Without Cutting

**Often engagement "spice" doesn't require cutting to another clip.**

**Alternative Techniques:**

**1. Movement on Still Clips**
- Give movement to any boring still clips
- Options: Scale slowly change, position slowly change, perspective change

**2. Abrupt Scale Changes**
- More aggressive zoom in/out
- Purpose: Draw attention to certain things
- Example: Zoom in close to face when saying something important

**3. Wiggle Keyframes**
- Images, text, or whole video shaking around
- Learn By Leo's Opinion: "You never see me doing this because I don't like way it looks, but if you want to do it then go ahead."
- Stylistic choice - not universally recommended

### Overlays: Adding Visual Layers

**Purpose:** Throw visuals on top of footage to increase variety.

#### Captions Strategy

**Common Mistake:** Adding captions just to jack up visual variety.

**The Drawback:** Using captions to fill in dead space can quickly become obnoxious and ruin opportunity for more engaging visual.

**Correct Usage:** Only use captions when you want viewer to:
- Understand specific words
- Pay closer attention to certain words

**Formatting Rule:** Keep them three words or less at time (easier to read).

**When Acceptable:** If there's really nothing else to put on screen, captions often still better than nothing.

#### Image Display Strategy

**Bad Approach:** Plainly show whole image.
- Boring
- More importantly: Confusing

**Good Approach:**
- Make things crystal clear
- Create visual variety
- Guide viewer's attention to focus point

### Six Professional Focus Point Techniques

**These techniques go beyond just scaling and positioning. This is what gives professional-looking timelines.**

**Technique 1: Animate Important Elements**
- Animate most important piece of text
- Or animate area of image being highlighted
- Movement draws eye naturally

**Technique 2: Darken/Blur Surroundings**
- Darken or blur area surrounding focus point
- Creates natural spotlight effect
- Eye drawn to brighter/sharper area

**Technique 3: Hue Shifting for Connotation**
- Shift hue to red = negative connotation
- Shift to yellow or green = positive connotation
- Color psychology influences perception

**Technique 4: Traditional Indicators**
- Circles around focus point
- Arrows pointing to focus point
- Underlines beneath important text
- Clear, direct guidance

**Technique 5: Glow Effect**
- Make subject glow
- Creates emphasis
- Draws eye naturally

**Technique 6: General Polish**
- Color grading
- Adding vignettes
- Subtle particle animations

**Purpose:** Make video look good overall, not just functional.

**Principle:** Looking good contributes to feeling good, which maintains engagement.

## Pillar 2: Visual Continuity

### The Concept

**If you manage to create seamless feed of visuals:**
- No rough edges
- No areas for distraction to build up
- No point where viewer loses immersion

**The Goal:** Make every moment blend into next seamlessly.

**The Result:**
- Editing should be invisible
- Experience should be mesmerizing

### Animation Entry Strategy

**Problem:** Graphic comes on screen and magically appears.

**Issue:** That doesn't make sense. Breaks continuity.

**Solution:** It needs to somehow move into frame.

**Alternative: Sound Effect Explanation**

**Option:** You can let something magically appear on screen.

**But Then:** Explain how it got there using sound effect.

**Examples:**
- Shutter sound effect
- Pop sound
- Similar appearing sounds

**Purpose:** Sound provides continuity even without visual animation.

### The Critical Cut Rule: Focus Point Continuity

**The Most Crucial Rule of Doing a Cut:**

**Bad Cut Example:**
- Last frame of first clip: Viewer looking at your eyes (center screen)
- First frame of second clip: Viewer expected to look somewhere else (different part of screen)

**Problem:**
- A little jarring
- Breaks immersion
- Viewer has to refocus attention

**Multiply This:** Imagine if every cut viewer had to keep changing focus from one side of screen all way to other.

**Result:** Pretty unimmersive viewing experience.

**The Rule:** Maintain focus point continuity across cuts.
- If viewer looking at center in frame 1
- Should still be looking at center in frame 2
- Smooth transition of attention
- No jarring refocus required

### Full Screen Transitions

**Purpose:** Make cuts seamless when focus point continuity not possible.

**Availability:** Plenty of free packs available.

**Learn By Leo's Style:** Subtle transitions.

**When to Use:** When you can't maintain focus point continuity naturally.

### Breaking Visual Continuity Strategically

**Important Note:** Don't be afraid to break visual continuity every now and then.

**Why?** Because it jolts viewer. It'll get their attention.

**Application:** Intentional breaks can be engagement tools when used deliberately.

**Balance:** Most of time maintain continuity, occasionally break for emphasis.

## Pillar 3: Immersive Audio (Sound Design)

### The Core Concept

**What Sound Design Does:**
- Makes viewer experience every cut through second sense
- Makes viewer experience every transition through sound
- Makes viewer experience every animation through audio
- Makes viewer experience every piece of footage aurally

**The Power:** Literally double the stimulation.

**Additional Benefit:** Can be used to influence mood that viewer has.

**Description:** "An engagement superpower."

### Step 1: Gather Sounds

**Resource:** Start with free sound design pack of copyright-free sounds.

**Additional Sources:**
- FreeSound.org
- Epidemic Sound (subscription)

**Build Library:** Collect variety of sounds to work with.

### Step 2: Basic Sound Design

**Method:** Go through your video and add sound effects wherever it makes sense.

**Two Foundational Types:**

**Movement Sounds (Whoosh)**
- When something moves
- Add whoosh sound
- Reinforces motion

**Highlight Sounds**
- When something's highlighted
- Add highlight sound
- Emphasizes importance

### The Engaging Part: Emotional Hijacking

**"These next three types of sound effects literally hijack your viewers' emotions and suck them into the video."**

#### Sound Type 1: Risers

**Function:** Build tension and anticipation.

**Why They Work:** Communicate to audience that something really important is about to happen.

**Critical Rule:** Only use them if something important is actually going to happen.

**Warning:** If you use them when nothing important happens, they lose their reputation and won't be effective.

**Strategic Usage:** Reserve for genuine important moments to maintain credibility.

#### Sound Type 2: Hits

**Function:** Release tension and emphasize moments.

**Effect:** Make moments feel important.

**Usage Options:**
- Can use on their own
- Can place riser before them
- Depends on situation

**Warning:** Don't overdo them.

**Combination:** Riser + Hit = maximum impact for critical moments.

#### Sound Type 3: Drones

**Function:** Create feeling of mystery and intrigue.

**Mood:** Reserved more for darker moods.

**Effect:** Create lot of underlying suspense.

**When to Use:** Mysterious or suspenseful content.

### Why These Work: Emotional Manipulation

**The Mechanism:** These sound effects manipulate viewer's emotions.

**Why That's Powerful:** The more emotionally invested viewer is, the more engaged they are.

**Result:** Emotional investment = Sustained attention.

## Pillar 4: Immersive Audio (Music Strategy)

**Note:** Music is so important it gets its own section within immersive audio.

### The Tip of the Iceberg

**Previous sound effects (risers, hits, drones):** Just tip of iceberg for emotional investment.

**Below Surface:** Massive potential for emotional investment through music choice.

### Strategic Music Selection

**Learn By Leo's Approach:**

**General Music Choice:**
- Find songs that create feeling of anticipation
- Makes viewer constantly believe about to say something super important
- Maintains engagement through expectation

**Segment-Specific Choice:**
- During groundbreaking advice segment
- Use song that gives innovative feeling
- Creates excitement over what's being said

**Result:** Music actively shapes viewer emotional response to content.

### The Mood Mapping Process

**Super straightforward to pull off:**

**Step 1:** Separate your video based on subject changes.

**Step 2:** Decide mood viewer should have for each subject.

**Step 3:** Find music that creates that mood.

**Important Note:** You should spend lot of time finding right music because it is really important that it fits.

### Music Sources

**Free Options:**
- YouTube Audio Library
- Occasional gem artists (like Lemmino) who offer free songs

**Paid Option (Recommended):**
- Licensed music platform subscription
- Best choice if taking YouTube seriously
- Learn By Leo uses Epidemic Sound
- Saved 4 hours finding better songs last time

**Reality:** Free options limited. Paid worth it for serious creators.

### Advanced Music Techniques

**"This is going to sound crazy but there's even more you can do with your music choice to immerse viewer."**

#### Technique 1: Abrupt Pause

**Method:** Pause music abruptly.

**Effects:**
1. Sudden change jolts viewer
2. Gets their attention
3. Lack of music brings attention to other parts of video

**When to Use:** Special moments you want to elevate.

**Purpose:** Makes that moment stand out dramatically.

#### Technique 2: Slow Fade Out

**Method:** Let music slowly fade out.

**What Happens:**
1. Viewer notices music going away
2. Understand segment coming to close
3. Creates anticipation of something new coming

**Purpose:** Signals transition while building anticipation for next segment.

**Psychological Effect:** Prepares viewer for topic shift.

#### Technique 3: Hit/Dip Syncing

**Beyond basic mood matching:** Upgrade by syncing hits and dips of song to video.

**Example from Learn By Leo's Video:**

**Setup:**
- Introduced problem at specific moment
- Began teaching solution at another specific moment

**Technique:**
- Line things up so at exact moment of shift
- Music picks up

**Effects:**
1. Marks clear topic shift from problem to solution
2. Makes solution segment more exciting
3. Audio reinforces visual transition

**Advanced Feature:** Downloading separate elements of song (stems).
- Epidemic Sound feature
- Can control different layers independently
- Allows precise syncing
- Super helpful for advanced music editing

## Integration of All Four Pillars

### The Relationship Between Pillars

**Pillar 1: Visual Variety**
- Keeps attention through changing visuals
- Prevents boredom
- Requires careful balance to avoid visual mush

**Pillar 2: Visual Continuity**
- Makes transitions seamless
- Maintains immersion
- Prevents jarring experiences

**Pillar 3: Sound Design**
- Doubles stimulation through second sense
- Manipulates emotions
- Reinforces visual changes

**Pillar 4: Music**
- Shapes overall mood
- Signals transitions
- Creates anticipation
- Builds emotional investment

### How They Work Together

**Visual Variety + Visual Continuity:**
- Seem contradictory but actually complementary
- Variety provides stimulation
- Continuity provides smoothness
- Balance creates engaging yet comfortable viewing

**Visual Elements + Audio Elements:**
- Visual changes reinforced by sound
- Audio creates emotional context for visuals
- Together create immersive experience
- Double sensory input = double engagement

**Strategic Breaks:**
- All pillars allow for intentional violations
- Breaking visual continuity → jolts attention
- Pausing music → emphasizes moment
- Long shot duration → allows breathing room
- Rules exist to be followed most of time, broken strategically

## Context-Specific Application

### Entertainment Content (Mr. Beast Style)

**Emphasis:**
- Maximum visual variety (pillar 1)
- Rapid pacing
- Frequent sound effects (pillar 3)
- High energy music (pillar 4)
- Visual continuity still important but less emphasis

**Characteristics:**
- Cut every few seconds
- Constant stimulation
- Lots of motion graphics
- Heavy sound design
- Energetic music throughout

### Authentic Content (Sam Sulek Style)

**Emphasis:**
- Minimal visual variety
- Long shot durations
- Natural sound (less effects)
- Simple or no music
- Authenticity over stimulation

**Characteristics:**
- Few cuts (90 seconds between)
- Natural pauses kept in
- Minimal graphics
- Ambient sound
- Feels like spending time with someone

### Educational Content (Learn By Leo Style)

**Emphasis:**
- Balanced visual variety (pillar 1)
- Strong visual continuity (pillar 2)
- Strategic sound design (pillar 3)
- Mood-appropriate music (pillar 4)
- Professional polish

**Characteristics:**
- Mix of A-roll and B-roll
- Motion graphics for explanations
- Focus point guidance techniques
- Anticipatory music
- Clean transitions
- Strategic emphasis sounds

## The Complete Editing Checklist

### Pre-Edit Planning
- [ ] Identified what experience viewers want
- [ ] Determined which pillars to emphasize
- [ ] Separated video into sections by subject
- [ ] Decided mood for each section
- [ ] Gathered B-roll footage needed
- [ ] Collected sound effects library
- [ ] Found appropriate music for each section

### Visual Variety Implementation (Pillar 1)
- [ ] Mix of A-roll and B-roll throughout
- [ ] Motion graphics for complex explanations
- [ ] Shot duration varies but appropriate to content
- [ ] Still clips have movement (scale/position)
- [ ] Strategic zoom-ins for emphasis
- [ ] Captions only when enhancing understanding (3 words max)
- [ ] Images use focus point guidance (6 techniques)
- [ ] Overall polish (color grading, vignettes)

### Visual Continuity Implementation (Pillar 2)
- [ ] Graphics animate into frame (not magical appearance)
- [ ] Focus point continuity maintained across cuts
- [ ] Full screen transitions used when needed
- [ ] Strategic breaks in continuity for emphasis
- [ ] Smooth flow from moment to moment
- [ ] No jarring focus shifts

### Sound Design Implementation (Pillar 3)
- [ ] Whoosh sounds on all movement
- [ ] Highlight sounds on emphasized elements
- [ ] Risers before important moments
- [ ] Hits on emphasized moments
- [ ] Drones for mysterious/suspenseful sections
- [ ] Sound effects not overused
- [ ] All visual changes have audio component

### Music Strategy Implementation (Pillar 4)
- [ ] Music matches section mood
- [ ] Different tracks for different subjects
- [ ] Adequate time spent finding right music
- [ ] Abrupt pauses for special moments
- [ ] Fade outs signal transitions
- [ ] Music hits/dips synced to key moments
- [ ] Stems used if available for precise control

### Quality Control
- [ ] Editing style matches audience expectations
- [ ] No disruption of desired experience
- [ ] Balance of variety without visual mush
- [ ] Seamless experience maintained
- [ ] Audio and visual work together
- [ ] Professional polish throughout
- [ ] Strategic rule violations are intentional

## Key Philosophical Insights

1. **Context Trumps Technique:** Editing must match what viewer came for
2. **Disruption = Drop-Off:** Anything disrupting expected experience makes viewers stop
3. **Visual Variety Requires Balance:** Too little = boring, too much = confusing
4. **Continuity Creates Comfort:** Seamless experience = immersion, jarring = distraction
5. **Audio Doubles Engagement:** Sound design provides second sensory channel
6. **Music Shapes Emotion:** Strategic music manipulates viewer emotional state
7. **Every Choice Contributes:** No neutral decisions, everything helps or hurts
8. **Strategic Violations Are Tools:** Breaking rules deliberately powerful for emphasis
9. **Professional Polish Matters:** Small details accumulate into "professional" feel
10. **Motion Graphics Solve Complex Explanations:** When essential but boring, motion graphics explain clearly and fast

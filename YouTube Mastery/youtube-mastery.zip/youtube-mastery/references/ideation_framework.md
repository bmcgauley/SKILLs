# YouTube Video Ideation Framework

This reference provides the complete framework for generating viral video ideas through systematic research, brainstorming, and validation.

## Core Concept: Areas of Interest

**Popular vs. Unpopular Areas:**
- Unpopular area of interest requires 1,000+ videos to match views of one popular area video
- Popular areas have broad appeal to majority of niche
- One breakthrough video in popular area > year of mediocre videos in unpopular area

**Identifying Popular Areas:**
- Multiple channels covering topic
- High view counts relative to channel size
- Addresses universal pain points or desires
- Uses superlatives (best, worst, craziest, most)

## Phase 1: Deep Research (Multi-Day Investment)

### Step 1: Gather Audience Data

**Current Audience (YouTube Studio Analytics):**
1. Navigate to YouTube Studio → Analytics → Audience tab
2. Review "The videos your audience watches" panel
3. Review "The channels they watch" panel
4. Link channels into VidIQ or manually gather top 15 videos per channel

**Potential Audience Expansion:**
1. Consider other channels your audience might like
2. Open videos in your list, check suggested column
3. Add relevant channels to research list
4. Spend at least 1 hour building comprehensive list

### Step 2: Pattern Recognition

**Sort and Analyze:**
1. Sort all gathered videos by most viewed
2. Note reoccurring topics (first level)
3. Go deeper: identify WHY they've shown interest (not just what)

**Research Checklist:**
- Pain points (what problems do they face?)
- Goals (what do they want to achieve?)
- Subjects (what topics interest them?)
- Positive vs. negative approach (which works better?)
- Attention-demanding words (what language captures them?)
- Concepts they enjoy most

**Advanced Analysis:**
- Temporarily hide oversaturated channels to see additional patterns
- Identify format preferences (case studies, quick results, tutorials)
- Note presentation styles that resonate

### Step 3: Document Everything

Create organized research document including:
- All findings written down
- Categorized by type (pain points, goals, subjects, etc.)
- Specific examples from top videos
- Notes on why certain content works

## Phase 2: Idea Generation

### Strategy 1: Deep Knowledge + Daily Practice

**Build Knowledge Base:**
- Research everything related to components (concepts audience loves, subjects interested in, pain points, wants, needs)
- Go down every rabbit hole
- Seek new, unseen information
- Diversify knowledge base

**The Component Combination Model:**
- No truly new ideas - only unique combinations of existing components
- More knowledge quantity × more knowledge diversity = more unique ideas possible
- Example: Gutenberg combined movable type, paper, press mechanism, ink (all existing) into printing press

**Daily Review Practice:**
1. Keep notebook of research notes
2. Review notes every single day (brief review)
3. Let mind wander during distraction-free time
4. Ideas emerge naturally throughout day

**Optimal Brainstorming (The Half-Asleep Technique):**
1. Set alarm earlier than usual in morning
2. When alarm goes off, hit snooze
3. Spend 2 minutes skimming through notes
4. Go back to sleep
5. Repeat with each snooze cycle

**Why This Works:**
- Half-asleep state = scientifically optimal for creativity
- Subconscious processing with lowered barriers
- Pattern recognition enhanced
- Multiple opportunities for insight per session

### Strategy 2: Concept Adaptation with VidIQ

**Find Target Phrases:**
1. Use research findings to identify types of content audience watches most
2. Use ChatGPT to generate searchable phrases matching those desires
3. Example prompt: "Generate search phrases that match desire for [quickly get results] and [improve video editing]"

**Search and Filter in VidIQ:**
1. Search each generated phrase
2. Set filters: high views + high outlier scores
3. Result: concepts proven to work with similar audiences

**CRITICAL: Compatibility Testing**

**The Trap:** Finding outlier video ≠ concept will work for your audience

**Compatibility Matrix:**
- **Audience Goal Alignment:** Entertainment seekers vs. improvement seekers vs. curiosity-driven
- **Content Type Compatibility:** Educational vs. entertainment vs. practical
- **Value Proposition Match:** Helpful vs. interesting vs. entertaining

**Example Analysis:**
- "Blank explained" = Interesting but NOT helpful
- "Blank stereotypes" = Entertaining but NOT helpful
- "21 blank lessons" = Helpful ✓ (works for improvement-seeking audience)
- "How to get so blank you blank" = Helpful ✓

**Filter Rule:** Only adopt concepts that align with your audience's core motivation for watching content.

**Save and Annotate:**
1. Save compatible concepts to ideas folder
2. Add notes on how to use the concept
3. Select specific parts you like
4. Build channel lists for ongoing research

## Phase 3: Validation (The Four Tests)

### Test 1: Fresh Perspective (Wait Days)

**Process:**
1. Write idea down
2. Wait at least couple days
3. Re-evaluate with fresh eyes
4. Keep only ideas that still feel strong

**Reality:** Less than 25% of ideas survive this test. This filtering prevents wasted production time.

**Why This Works:** Initial excitement fades, revealing whether idea has lasting merit.

### Test 2: Originality Check

**Process:**
1. Copy would-be title into YouTube search
2. Add a few variations
3. Check if video already exists

**If Video Exists:**
- Don't panic - most videos have CTR under 10%
- Plenty of new audience available
- Solution: Improve the title, thumbnail, or add twist

**Principle:** Being slightly different from existing content often enough.

### Test 3: Best Option Assessment (Top 10% Rule)

**Mr. Beast Quote:** "Most YouTubers watching this, you could pull triple the views with half the work if you just have better ideas."

**Outlier Score Strategy:**
- 1-2x outlier = Solid but not breakthrough
- 3-5x outlier = Good, worth making
- 5-10x outlier = Great, breakthrough potential (TOP 10% category)
- 10x+ outlier = Exceptional, viral potential

**Application:**
- Compare outlier scores of all ideas
- Only keep top 10% of ideas
- Look for 5-10x multipliers minimum
- Raise bar for what's "good enough"

**The Math:**
- 10 videos at 1-2x outlier = 10-20x total impact
- 2 videos at 5-10x outlier = 10-20x total impact
- Same impact, 80% less work

### Test 4: Title/Thumbnail Creation (Final Gate)

**CRITICAL RULE:** Create title and thumbnail BEFORE any other production work.

**Process:**
1. Review audience's interests, goals, pain points
2. Ensure solid connection between:
   - Audience's motivations to watch content
   - Value this video would provide
3. Make connection crystal clear in title/thumbnail

**The Question:** If you were face-to-face with viewer telling them why to watch, what would you say?

**Final Rule:** If you can't find a way to make that connection clear, the idea won't work. Abandon and iterate.

**Difficulty Warning:** Making this connection can be really hard. This is intentional - it's the final filter ensuring only viable ideas proceed.

## Common Ideation Mistakes

### Research Phase Mistakes

**Mistake 1: Insufficient Time Investment**
- Fix: Commit to multi-day research process (5+ days for breakthrough)

**Mistake 2: Surface-Level Analysis**
- Fix: Go deeper - understand WHY behind interests, not just topics

**Mistake 3: Small Sample Size**
- Fix: Spend at least 1 hour building comprehensive list

### Idea Generation Mistakes

**Mistake 4: Forcing Creativity**
- Fix: Let ideas come naturally, use half-asleep technique

**Mistake 5: Assuming Outlier = Success**
- Fix: Always test concept compatibility with YOUR audience's core motivations

**Mistake 6: Not Diversifying Knowledge**
- Fix: Research everything related, go down rabbit holes

### Validation Mistakes

**Mistake 7: Not Waiting for Fresh Perspective**
- Fix: Wait at least couple days, re-evaluate

**Mistake 8: Accepting "Good Enough"**
- Fix: Only make top 10% of ideas, look for 5-10x multipliers

**Mistake 9: Skipping Title/Thumbnail Test**
- Fix: Create title/thumbnail first, before any production work

## Integration with VidIQ (Optional Tool)

**Pricing:** $25/month

**Core Functions:**
- Outlier score calculation
- High view filtering
- Channel list management
- Concept adaptation research

**Workflow:**
1. Find target phrases (from research)
2. Search phrases in VidIQ
3. Filter for high views + high outlier scores
4. Save compatible concepts with notes
5. Build channel lists for ongoing research

**Manual Alternative:** Use YouTube Studio analytics + spreadsheet tracking (more time-intensive but free)

## Key Principles

1. **Areas of Interest Determine Scale:** Popular area = 1,000x more views than unpopular
2. **Research is Multi-Day Investment:** 5 days of research for breakthrough worth it
3. **Ideas Are Combinations:** Unique combinations of existing components
4. **Knowledge Diversity = Idea Quantity:** More + diverse knowledge = more unique ideas
5. **Can't Force Creativity:** Must let creativity happen, half-asleep state optimal
6. **Outliers Aren't Guaranteed:** Finding outlier ≠ works for your audience
7. **Fresh Perspective Eliminates Most:** <25% of ideas survive, essential filtering
8. **Originality Isn't Binary:** Already-made topic can work with improved execution
9. **Top 10% Rule:** Only make top 10% of ideas to prevent waste
10. **Title/Thumbnail Test is Final Gate:** Can't make connection = idea won't work

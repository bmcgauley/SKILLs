# YouTube Titles & Thumbnails Framework

This reference provides the complete strategy for creating titles and thumbnails that maximize clicks by creating multiple compelling reasons to watch.

## Core Philosophy

**Central Thesis:** Every viral video creates at least one captivating reason to watch it. The title and thumbnail must work together to create MULTIPLE compelling reasons as quickly as possible.

**Key Principle:** If it takes longer than 1 second to identify a reason to watch, or if the reason feels far-fetched, the video will fail.

## Part 1: Creating Reasons to Click

### The Four Methods to Generate Intrigue

**Method 1: Plant a Question (MOST EFFECTIVE)**
- Most effective method for getting clicks
- Questions don't need to be explicitly written
- Can be implied through context or storytelling
- Examples: "What happens if..." "How did they..." "Why does..."

**Method 2: Throw Viewers into Middle of Story**
- Creates "What happens next?" question
- Generates curiosity through incomplete narrative
- Implies ongoing action requiring resolution

**Method 3: Promise an Exciting Journey**
- Appeal to narrative instincts
- Implies transformation or progression
- Shows clear before/after or start/end points

**Method 4: Address Something Interesting**
- Teach cool or fascinating information
- Appeal to desire to learn
- Educational content with entertainment value

**Critical Success Factor:** The reason must be immediately apparent within 1 second of viewing.

## Part 2: Maximize Information Delivery Speed

### The Fatal Mistake: Repetition

**Problem:** Title and thumbnail repeating same information wastes space and slows delivery.

**Bad Example:**
- Thumbnail: Shows airplane
- Title: "Airplane Facts"
- Result: Both convey identical information = TOO SLOW

**Why Speed Matters:**
- Viewers surrounded by 10+ other interesting videos
- Fastest video to convey value proposition wins
- Every second of consideration is precious
- Slow delivery = missed clicks

### The Winning Strategy: Build, Don't Repeat

**Principle:** Thumbnails and titles should BUILD OFF each other, not copy.

**Excellent Example:**
1. **Thumbnail:** Shows boarding plane last (visual creates curiosity)
2. **Title:** "Secrets Airlines Don't Want You to Know" (adds NEW information)
3. **Result:** Three total questions generated:
   - Why board last?
   - What secrets?
   - Are planes more dangerous than thought?

**The Leverage Principle:**
- Utilize ALL available space in thumbnail and title
- Create MAXIMUM intrigue through building
- Videos doing this outperform competitors even in crowded feeds

**Goal:** Create as many captivating reasons to watch as possible within title/thumbnail combination.

## Part 3: Create Eye-Catching Thumbnails

### The Spotlight Element Concept

**Definition:** Part of thumbnail that stands out not just from rest of image, but from ENTIRE YouTube page.

### Three Primary Spotlight Elements

**Element 1: Expressive Faces**
- Easiest and most effective method
- Faces naturally grab attention automatically
- Humans even see faces where they don't exist (pareidolia)
- Provides emotional context immediately
- Creates human connection instantly

**Element 2: Short Text**
- Attracts attention like faces
- Must be SHORT to stand out
- Should NOT explain things
- Functions as attention-grabber, not information delivery
- Use sparingly for maximum impact

**Critical Rule:** Keep text minimal - it's for attention, NOT explanation.

**Element 3: Familiar Objects**
- Objects people immediately recognize
- Works especially well when used unexpectedly
- Can be enhanced by doing something unusual with object

**Example (5-Minute Crafts Strategy):**
- Uses familiar objects in almost all thumbnails
- Does something weird/unexpected with object
- Weirdness generates questions and intrigue

### Advanced Strategy: Minimalism

**Example: Lemino's Approach**
- Minimalistic art style
- One or two familiar objects only
- Clean, uncluttered composition
- Objects catch eye more effectively

**Why Minimalism Works:**
- Allows spotlight element to be more striking
- Reduces visual noise competing for attention
- Increases contrast with busy thumbnails
- Creates clearer focal point

### The Professional Advantage

**Professional/Artistic Thumbnails Create:**
1. Stand out against amateur-looking thumbnails
2. Visual appeal naturally attracts attention
3. **Trust** in video quality
4. Implication of high production value
5. Pre-judgment that video worth watching

**Alternative:** Crude/rough style can also stand out, but doesn't build quality trust.

## Part 4: Thumbnails Tell Stories

### Beyond Attention: Creating Excitement

**Two Jobs of Thumbnails:**
1. Get attention (spotlight elements)
2. Create excitement and build intrigue (visual storytelling)

### Case Study: Ryan Trahan's Prison Challenge

**Surface Level (Attention):**
- Ryan in orange jumpsuit stands out
- High contrast pushes it to pop
- Cinematic photography promises quality

**Deep Level (Storytelling Through Subtle Details):**
1. **Posture:** Practically shouts something's wrong
2. **Setting:** Middle of large empty room = isolation
3. **Room Design:** Harsh, institutional = uncomfortable
4. **Lighting:** Bleak industrial = further discomfort
5. **Color Palette:** Contributes to mood
6. **Text Overlay:** "Day 2" = magnitude of challenge
7. **Overall Composition:** Everything tells story of great challenge

**Result:** All subtle details work together to promise interesting journey better than any title text could.

### Visual Storytelling Elements

**Color Psychology:**
- **Purpose:** Evokes specific moods driving questions
- **Warm colors (red, orange):** Excitement, survival, fun, energy
- **Cool colors (blue, green):** Calm, intelligence, creativity, trust
- **Application:** Align colors with story being told

**Text as Story Enhancement:**
- Challenge videos: "Day 2" or "41 minutes in" builds excitement about magnitude
- Extra context provision without full explanation
- Timeline indicators showing progression
- Magnitude amplification creating stakes

**Directing Viewer Attention Flow:**
- Arrows pointing to key elements
- Circles highlighting areas
- Borders around important parts
- Strategic color placement

**Purpose:** Control sequence of information processing to generate maximum intrigue.

### Demographic Color Strategy

**Younger Audiences:**
- Saturated, bright colors attract
- High contrast acceptable
- More visual noise tolerated

**Older Audiences:**
- Overwhelming saturation repels
- Prefer subdued palettes
- Cleaner compositions

**Takeaway:** Be aware of color choices, play into target demographics deliberately.

### The Setting Manipulation Strategy

**Ryan Trahan Example:**
- Real room in video ≠ room in thumbnail
- Thumbnail room photographed separately to match desired mood
- Real room didn't create dramatic atmosphere needed

**Principle:** Don't feel constrained by actual video footage for thumbnails.

**Why This Works:**
- Thumbnail mood can magnify challenge/interest
- Develops trust in video quality
- Creates intrigue over discrepancies
- Allows precise mood control

**CRITICAL RULE:** Never source thumbnails directly from video screenshots. Always create separate photographs specifically for thumbnails.

## Part 5: Title Strategy - Don't Spoil Anything

### The Primary Job of Titles

After thumbnails grab attention and begin storytelling, titles must **explain what video is about WITHOUT spoiling it**.

### The Anti-Literal Approach

**Problem:** Overly literal titles are boring and kill curiosity.

**Examples of Literal Titles (BAD):**
- "How Web APIs Shaped Internet History"
- "Spending 45 Minutes in the World's Quietest Room"

**Better Approach:**
- Be dramatic
- Build curiosity
- Spark viewer's imagination
- Play around with wording
- Leave room for questions

### The Mr. Beast Title Formula

**Principle:** Titles should leave viewer **imagining what will happen**.

**Method:** Offer glimpse of video's highlight without explaining everything.

**Example:**
- Literal: "Destroying Stuff and Other Cool Experiments"
- Mr. Beast approach: Takes coolest experiment and explains only that

**Result:** Creates anticipation while maintaining mystery.

### The "Cheat Code" for Titling

**The Pattern:** Title the video as the **driving question** itself.

**Instead of:**
- Explaining what happens
- Describing content literally

**Do This:**
- Ask question that leads into video
- Make title the question viewers would ask
- Create curiosity through title structure itself

**Advantage:** Viewers click to answer the question title poses.

### When Literal Titles Are Necessary

**Acceptable Cases:**
- Avoiding confusion is critical
- Topic requires specificity
- Clickbait would damage trust
- Educational content needs clarity

**Balance:** Think outside box first, but know when clarity serves content better.

## Part 6: Optimal Title Wording

### The Length Trap

**Common Assumption:** Title length is primary concern.

**Reality:** While long titles should be avoided, length isn't most critical factor.

**Evidence:** Some videos go viral with titles so long they get cut off.

### The True Priority: Front-Loading Important Words

**CRITICAL RULE:** Put most important and interesting words **at the start** of title.

**Bad Example:** "The History of Unsolved Mysteries"
- Word "Mysteries" (most important) is at END
- Last word anyone would see
- Buries compelling element

**Better:** "Mysteries Throughout History That Remain Unsolved"
- Key word "Mysteries" up front
- Grabs attention immediately
- Important information isn't hidden

### Word Choice Optimization

**Guidelines:**
1. Use **short words** over long ones
2. Use **common words** everyone understands
3. Choose words with **very clear meaning**
4. Avoid jargon or complex vocabulary

**Purpose:** Maximize comprehension speed and accessibility.

**Recommended Tools:**
- Thesaurus.com for simpler alternatives
- ChatGPT to generate variations and test readability

## The Complete Strategy Summary

### Thumbnail Checklist

- [ ] Contains at least one spotlight element (face/object/text)
- [ ] Stands out from other thumbnails on page
- [ ] Uses color psychology to support video mood
- [ ] Tells story through subtle visual details
- [ ] Created separately from video footage (not screenshot)
- [ ] Directs viewer attention in correct sequence
- [ ] Appropriate color saturation for target demographic
- [ ] Promises quality through professional or unique styling

### Title Checklist

- [ ] Builds on thumbnail (doesn't repeat information)
- [ ] Creates curiosity without spoiling content
- [ ] Front-loads most important/interesting words
- [ ] Uses short, common, clear words
- [ ] Asks or implies a question when possible
- [ ] Dramatic and imaginative (not overly literal)
- [ ] Appropriate length (concise but complete)

### The Integration Test

**Ask These Questions:**
1. Can someone identify reason to watch within 1 second?
2. Do title and thumbnail work together to create multiple questions?
3. Is information delivered faster than competing videos?
4. Does thumbnail tell story beyond just grabbing attention?
5. Does title create imagination rather than explanation?

### Success Criteria

**If title/thumbnail combination:**
- Creates multiple driving questions
- Delivers information quickly
- Stands out visually
- Tells compelling story
- Sparks curiosity without spoiling

**Then:** Video has foundation to compete successfully for views, even when surrounded by other compelling content.

## Critical Integration Point

**The 30-Second Problem:** Average video loses over 1/3 of audience in first 30 seconds.

**Reason:** Title and thumbnail create expectations that intro doesn't fulfill.

**Implication:** Even perfect titles and thumbnails fail if not supported by compatible introductions.

**Next Step:** Ensure intro matches and delivers on promise made by title/thumbnail combination (see intro_framework.md).

## Key Philosophical Insights

1. **Speed is Survival:** In attention economy, fastest video to convey value proposition wins
2. **Multiplication Over Addition:** Build title/thumbnail off each other rather than repeat
3. **Subtlety Sells:** Most powerful persuasion through subtle visual storytelling
4. **Questions Drive Clicks:** Brain wired to seek answers, most reliable engagement path
5. **Professional Perception Matters:** Looking professional builds trust encouraging time investment
6. **Never Be Literal:** Save literal explanation for inside video, external marketing should intrigue

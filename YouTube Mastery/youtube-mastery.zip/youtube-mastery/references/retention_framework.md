# YouTube Video Retention Framework

This reference provides the complete six-component framework for maximizing video retention and guaranteeing viral potential.

## Core Philosophy

**Goal:** Retention so high video is guaranteed to go viral.

**Foundation:** Algorithm is simple - if people click and watch, it gets promoted. But keeping people watching requires systematic approach across six components.

## Component 1: Green/Purple Formula (Stop Trimming to Just What Audience Wants)

### The Common Mistake

**What Most Creators Do:** Trim videos down to just parts audience actually wants to see.

**Why That's Wrong:** Obviously need to give value, but there's another often MORE important thing videos need to do: make viewer care BEFORE delivering value.

### The Color-Coded System

**Purpose:** Ensure viewer always cares so much about what you're saying that they can't possibly stop watching.

### Green Sections (Reason to Watch)

**Purpose:** Make viewer care about what's coming.

**Four Methods:**
1. Explain the problem
2. Share a mystery
3. Give a question
4. Create an expectation

**Function:** Set up curiosity and expectations.

### Purple Sections (The Payoff)

**Purpose:** Reveal the answers.

**Function:** Deliver on curiosity created by green sections.

### The Pattern

**Structure:** Green → Purple → Green → Purple → Green → Purple

**Critical Insight:** What if problem wasn't stated first?
- Got straight into teaching lesson
- No curiosity or expectations
- Whatever you say will just be boring information
- Rather than being answer to viewer's questions or problems

### The Self-Assessment Questions

**Do your videos:**
- Just get straight into talking about or doing random stuff?
- OR do you first make sure viewer cares about what you're talking about or doing?

**The Reality:**
- It's obvious to YOU as creator what makes things valuable
- But to audience, they don't actually know until you tell them

### Application to Different Content Types

**Informative Videos:**
- Pattern: Problem → Solution → Problem → Solution
- Example: Educational content explaining strategies

**Gaming/Hobby Videos:**
- Pattern: Question → Answer → Question → Answer
- Example: Game mechanics explanations, tips and tricks

**Action/Adventure Videos:**
- Pattern: More complex - applies to DOING things, not just talking
- Challenge: How to apply green/purple to video where you're doing something?

### Deep Dive: Ryan Trahan's "World's Loneliest House"

**What Viewers Want to See:** Ryan explore the world's loneliest house.

**The Problem:**
- First half of video is journey to house
- Viewers only care about seeing house itself
- How to keep viewers watching during journey?

**Ryan's Genius Solution:** Make viewer care about journey as well.

**From the intro:**
"This trip is said to be extremely dangerous. And locals say you'd have to be stupid to try to go with no experience, which really only leaves one man for this job. Hello. Hello. Clearly, I'm not prepared for a country named Iceland."

**Strategy:**
- Says journey is dangerous
- Throughout video makes himself out to be unprepared
- His safety and success becomes uncertain
- Journey becomes just as interesting as destination

**Write This Down:** Intrigue comes from uncertainty.

### The Three-Part Litmus Test (CRITICAL FRAMEWORK)

**Ryan's Process:** After recording footage, uses three-part test to identify what to cut and what voiceovers to add.

**This is how he makes viewers care about each and every second of his videos.**

**The Three Requirements:**
1. **Viewer must always know what's happening**
   - Clear on events occurring
   - No confusion about action

2. **They must know why it's important**
   - Understand stakes
   - See relevance

3. **They must know what could go wrong**
   - Uncertainty
   - Potential failure
   - Risk

**The Rule:** Viewer just needs to be told all three things, and then they will watch whatever follows.

### Example: The Boat Jump Scene

**The Plot Point (Purple Section):** Ryan jumps from boat onto island.

**The Green Section Before It:**
"This is the part of the video where I can never really illustrate how scared I am and like just how dangerous this is for someone like me who has no experience doing anything, but I have to jump off of this boat over the icy, deathly waters. I hope I don't fall. Ready?"

**What He Communicated:**
1. He's scared (emotion)
2. It's dangerous (stakes)
3. He's inexperienced (risk)
4. Water is freezing cold (consequence)
5. Hints he might fall (uncertainty)

**Critical Note:** This green section was VOICEOVER added during editing, not said during recording.

**Without This Context:** Jump wouldn't be entertaining. No stakes, no tension, no reason to care.

### When to Cut Instead of Add Context

**The Principle:** If you can't create curiosity or expectations, then cut that part out.

**Example from Ryan's Video:**
- Boat ride: Interesting because things could go wrong
- Other parts: No chance of failure, no room for curiosity
- Solution: Even if recorded lots of footage, summarize with sentence or two of voiceover

**The Rule:** If can't make viewer care, don't include it.

## Component 2: Bring The Right Energy On Camera

### The Vsauce Example

**Watch this intro:**
"Hey, Vsauce, Michael here. This appears blue. This appears yellow and this appears green."

**Initial Reaction:**
- Just telling colors on Rubik's cube
- No video editing
- This video sucks?

**Reality:**
- 30 million views
- Kind of engaging

**Why?** Creator looks and sounds as if he's saying something super important.

### The Energy Checklist

**Vocal Variety:**
- [ ] Sound genuinely excited to share something?
- [ ] Speak louder for excitement?
- [ ] Lower voice for suspense?
- [ ] Pause to build anticipation and emphasize key points?

**Facial Expressions:**
- [ ] Raise eyebrows to show something is interesting?
- [ ] Squint slightly to emphasize key detail?
- [ ] Move head in sync with words?

**Hand Gestures:**
- [ ] Shift hands from one side to other to visually separate ideas?
- [ ] Spread arms wide to signal something big?
- [ ] Pinch air to indicate something precise?

**If Answer is "You Don't":** You got to change that.

### The Emotion Contagion Principle

**The Rule:** Whatever emotion you put into your voice is contagious. Viewer will feel it too.

**Implications:**
- Speak in monotone → Anything you say will feel boring
- Feel uncomfortable on camera → Viewer will feel uncomfortable too

### The Camera Shy Problem

**Root Cause Analysis:**

**Talking to Close Friend:**
- 100% of focus is on getting point across
- No self-consciousness
- Natural and engaging

**Talking to Camera:**
- Get distracted by thoughts
- "Am I speaking fast enough?"
- "Am I pausing too much?"
- "Am I saying that right?"
- Become self-conscious
- Focused on yourself rather than sharing message
- Start to lose train of thought

### The Wrong Solution: Memorization

**What People Try:** Memorize words to say it all correctly.

**Why This Makes Things Worse:**
- Now more focused on getting words right
- Than on real meaning behind words
- **This is what causes you to speak in monotone**

### The Right Solution: Embrace Mistakes

**Get comfortable with making mistakes on camera.**

**The Comparison:**

**Option 1 (Flawless but Boring):**
- Say script flawlessly
- Every word perfect
- Don't say "um" or "ah"
- Entire recording speaking in monotone

**Option 2 (Imperfect but Engaging):**
- Make some mistakes in speech
- Might pause few times
- Say "um" and "ah"
- Sound really excited to share something
- Give impression there's something really important and exciting

**Which Sounds More Engaging?** Obviously Option 2.

**Plus:** You can cut out mistakes later.

### The Core Principle

**What Matters:** Not trying to look perfect.

**Instead:** Treat camera like it's your friend who's really interested about what you're saying.

**The Big Issue:**

**Wrong Mindset:**
- Get in front of camera
- Start thinking big audience watching
- Or panel of critics judging
- Think "I'm in front of camera now, I have to act different"
- Think "I have to say things right"

**Right Mindset:**
- Connecting with each individual viewer
- As if they were your friend
- Who's interested in what you're saying

**Result:** Viewer will feel like you have something really important to share.

## Component 3: Use This Addictive Structure (But/Therefore/So)

### The Problem with "And"

**Example of Bad Structure:**
"There's a problem with your videos and if you don't fix it, your scripts are boring. And this applies to any type of video. And I've been making this mistake the past few sentences."

**The Issue:** Using "and" to connect points in video.

### Traditional Story Structure Problems

**Traditional:** "This happened and then this happened and then this happened and then this happened."

**Problems:**
1. Quickly becomes repetitive
2. Creates bigger issue: Isn't specified how one thing leads to next
3. Disorienting for viewer
4. Video jumps between topics or scenes without clear connection
5. Viewer isn't kept immersed
6. All these exit points where they're free to disengage

### The South Park Formula (Better Structure)

**The Formula:** "We tried this, **but** that got in the way. **Therefore**, we had to do this, **but** it didn't work. **So**, we tried this."

**Key Words:**
- **But** (contrast, obstacle)
- **Therefore** (causation)
- **So** (result, next step)

**Application:**
- Scenes in story
- Topics in explanation
- Even individual sentences in paragraph

**Result:** Makes massive difference.

### The Core Goal

**Creating seamless flow throughout each part of your video.**

**Result:** Viewer stays fully immersed from start to finish.

## Component 4: Communicate Your Video's Value Better

### The Discord Server Study

**Setup:** Before making this video, Learn By Leo went through all videos in Discord feedback section to find most common retention mistake.

**Quiz Options:**
- Lack of storytelling?
- Really bad video editing?
- People speaking in monotone voice?
- Something else?

**Answer:** The most basic intuitive thing you got to be doing, yet no one was doing it: **Confusion.** "I was confused what was happening."

### The Obvious Oversight

**Most Creators' Reaction:** "I would never make such obvious oversight."

**Reality:** You're probably one of creators doing this.

### Learn By Leo's Scripting Process

**Intensity:** Revisits every part of video genuinely around **100 times** to find any possible way to make it easier to understand.

**Why This Is Necessary:** You're biased.

### The Bias Problem

**Your Perspective:**
- Have all context
- You are the expert
- Did the research
- Did the filming
- Did the editing

**Viewer's Perspective:**
- Place of zero context
- Everything completely new to them

**Result:** Way harder for viewer to keep up with and understand what's happening.

### Why This Hurts Your Views

**The Disappointing Cycle:**
1. You upload video
2. You can tell there's lot of value there
3. Lot for people to get from it
4. Yet people aren't enjoying it that much
5. Metrics YouTube gathers end up being lower
6. Don't get views video really could be getting

**The Reality:**
- You already have good video idea
- Already putting lot of effort in
- Already lot of value there
- **But issue is viewers just aren't able to absorb it**
- Not able to understand it well
- Therefore video is lower quality because they can't access that value

**Comes Down To:** Communication.

### Three Critical Communication Elements

**Element 1: Analogies and Examples**

**The Problem with Clear and Concise:**
- You explain something clear and concise
- Get to point
- Say things simply how they are
- Still going to leave viewer confused

**Why?** It isn't tangible until you've seen it in action. Also hard to wrap head around if totally new to you.

**Solutions:**
- **Use Analogies:** Turn abstract idea into something vivid
- **Give Examples:** Makes concept concrete

**Result:** Turn abstract ideas into something vivid for viewer.

**Element 2: Get Outside Perspective**

**Practice:** Get someone else to watch your video before you post it.

**Learn By Leo's Experience:**
- Been doing this for years
- **Every single time** someone points out moment that was:
  - Boring, OR
  - Confusing

**Lesson:** You can't see your own blind spots. Outside perspective essential.

**Element 3: Visual Communication (The Secret Weapon)**

**Learn By Leo's Statement:** "What I swear by because it set me apart ever since my previous channel. It's what I do with the visuals."

**The Rule:** Always make certain that **every single thing you talk about has visual to show that thing**.

**Why This Matters:**

**The Pacing Problem:**
- You want to pace video pretty quickly
- If you pace really quickly, easy for viewer to miss details

**The Solution:** Take full advantage of visual communication.

**Result:** Video can communicate maximum value at maximum efficiency.

### Advanced Visual Communication: Focus Direction

**The Additional Problem:** Often multiple things in scene viewer might look at.

**Need:** Clarify where their focus should be.

**Methods:**
- Zoom in to exactly what viewer should be looking at
- Pan camera to focus point
- At any given moment, control attention

## Component 5: Add Variety (But Not Too Much)

### The Variety Misconception

**The Big Narrative:** The more cool things you put into video (visuals or sound effects), the more views.

**Observation:** Big creators have ton of variety in videos.

**Reality:** Variety is much more delicate than that.

**Risk:** Having variety just for sake of having it really has potential to screw up your video.

### The Seasoning Analogy

**Variety is like seasonings in dish.**

**Purpose:** Bring out flavor of food.

**Problem:** Too many seasonings ruins dish.

### Example 1: Mood Variety

**One Seasoning (Bad):**
- Keeping constant tone throughout whole video
- Boring

**Right Amount of Variety (Good):**
- Mood fluctuates from excitement to worry to joy to unease
- Video becomes much more engaging and vivid
- Viewer kept alert by shifting tone
- Contrast between moods enhances strength of each mood

**Healthy Amount of Variety:** Great for mood.

### Example 2: Visual Variety

**Too Much Variety (Bad):**
- Becomes difficult to keep up
- Viewer isn't given enough time to process each thing on screen
- Can't absorb anything valuable from visuals

**The Problem:** Visual overload prevents value absorption.

### The Core Principle

**Wrong Approach:** Taking all spices and tossing in as much as you can.

**Right Approach:** Think about:
- Effect each thing you do has
- How much of it's needed
- To create perfect experience for your audience

**Application to Video Editing in General:** Strategic, purposeful choices rather than maximalist approach.

## Component 6: Create a Highlight Reel (Beat Competition)

### How Algorithm Works

**The Algorithm's Purpose:** Make viewers' experience of going on YouTube be as enjoyable as possible.

**If your video is predicted to be:**
- One of most enjoyable videos for someone → Algorithm recommends to them
- Highly enjoyable for millions → Algorithm recommends to millions

**The Goal:** Make your video predicted as highly enjoyable for maximum people.

### The Process

**Step 1: Understand Your Audience**

**Know:**
- What they're interested in
- What they're seeking for
- Experience they want when they go on YouTube

**Step 2: Give It Better Than Competition**

**Figure out:**
- Exactly what they want
- How to give it better than competition

### The Terraria Channel Case Study

**Context:** Running channel at age 15.

**Method:**
1. Looked at all competition
2. Looked at what videos were getting most views in niche
3. Compared those videos to own videos
4. Kept noticing things they were doing better
5. Improving those things
6. Until eventually getting same or more views than them

**Result:** Matched or exceeded competition's performance.

### The Final Component Definition

**Study what has gotten most views in your niche.**

**From that, find out:**
- What your audience values
- What is it that they value?

**Then study those videos to figure out:**
- How to provide that value better than anyone else can

**This is the secret to:**
- Going viral
- Blowing up with each and every video

## Integration Across All Components

### The Retention Flow

**Pre-Content (Components 1 & 2):**
- Green section creates curiosity
- Energetic delivery makes it feel important
- Viewer primed to care

**Content Delivery (Components 3 & 4):**
- But/therefore/so maintains flow
- Communication ensures understanding
- Visual reinforcement maximizes efficiency
- No confusion, no exit points

**Experience Enhancement (Component 5):**
- Strategic variety keeps engagement high
- Mood shifts maintain alertness
- Never overwhelming

**Competitive Edge (Component 6):**
- Studied what works
- Providing it better than anyone else
- Video positioned to outperform competition

### How Components Build on Each Other

**Foundation:** Component 6 (study competition)
- Understand what audience values
- Know what you're trying to beat

**Structure:** Components 1 & 3 (green/purple + but/therefore/so)
- Framework for organizing content
- Ensures curiosity and flow

**Execution:** Components 2 & 4 (energy + communication)
- Delivery that feels important
- Clarity that enables value absorption

**Polish:** Component 5 (strategic variety)
- Enhancement that elevates without overwhelming
- Final layer of engagement

### The Compound Effect

**Each Component Multiplies Others:**
- Green/purple without energy = Weak hooks
- Energy without communication = Wasted charisma
- Communication without structure = Confusing clarity
- Structure without variety = Boring predictability
- All without competitive study = Missing the mark

**All Together:**
- Hooks that land
- Energy that pulls
- Structure that flows
- Communication that clarifies
- Variety that enhances
- Positioning that beats competition
- **Result: Guaranteed viral potential**

## Key Philosophical Insights

1. **Curiosity Before Content:** Never give information before making viewer care about it
2. **Intrigue Comes from Uncertainty:** Make success/safety/outcome uncertain
3. **Three-Part Litmus Test Universal:** What's happening + Why important + What could go wrong = viewer will watch
4. **Emotion is Contagious:** Whatever emotion you put in voice/face/body, viewer feels too
5. **Treat Camera Like Friend:** Not audience, not critics. One interested friend fixes camera shyness
6. **Mistakes Better Than Monotone:** Imperfect but energetic beats flawless but boring
7. **And Then = Exit Points:** "And then" structure creates disengagement opportunities
8. **You're Biased, Viewer Isn't:** You have all context, viewer has none. Revisit ~100 times
9. **Visual Communication Doubles Efficiency:** Show everything mentioned for maximum value at maximum speed
10. **Variety Must Be Strategic:** Like seasonings - enhance, not overwhelm
11. **Beat Competition Through Study:** Study top videos → Identify what works → Provide it better
12. **Value Inaccessible = Value Nonexistent:** Having value isn't enough. Must communicate clearly

## Complete Application Checklist

### Component 1: Green/Purple Formula
- [ ] Script structured with green/purple sections
- [ ] Green sections use one of four methods (problem/mystery/question/expectation)
- [ ] Purple sections clearly answer green setups
- [ ] Pattern maintained throughout
- [ ] Three-part litmus test applied (what's happening, why important, what could go wrong)
- [ ] Voiceovers added where needed
- [ ] Parts without curiosity potential cut or summarized

### Component 2: Camera Energy
- [ ] Treating camera like interested friend
- [ ] Focusing on message, not self-consciousness
- [ ] Comfortable making mistakes
- [ ] Using full range of vocal variety
- [ ] Facial expressions matching content
- [ ] Hand gestures supporting ideas
- [ ] Energy level appropriate to importance

### Component 3: But/Therefore/So Structure
- [ ] All connections are causal (but/therefore/so)
- [ ] No "and then" chains
- [ ] Flow is seamless
- [ ] No disengagement opportunities

### Component 4: Maximum Communication
- [ ] Script revisited ~100 times for clarity
- [ ] Analogies added for abstract concepts
- [ ] Examples given for complex ideas
- [ ] Outside perspective obtained
- [ ] Confusion points addressed
- [ ] Visual shown for every mention
- [ ] Focus directed with zoom/pan

### Component 5: Strategic Variety
- [ ] Mood variety creates engagement without chaos
- [ ] Visual variety enhances without overwhelming
- [ ] Each element has purpose
- [ ] Amount calibrated to effect needed

### Component 6: Beat Competition
- [ ] Studied top 20 videos in niche
- [ ] Identified what audience values most
- [ ] Noted what competition does well
- [ ] Planned how to do it better
- [ ] Video positioned to outperform

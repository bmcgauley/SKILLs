---
name: youtube-mastery
description: Comprehensive YouTube content creation skill synthesizing proven frameworks for viral video ideation, title/thumbnail creation, intro optimization, retention strategies, and editing techniques. This skill should be used when helping users create, plan, optimize, or analyze YouTube content at any stage from ideation through post-production. Integrates with outlining and scriptwriting skills to provide complete content workflow.
---

# YouTube Mastery

This skill provides comprehensive frameworks and workflows for creating viral YouTube content, synthesizing the proven methodologies of Learn By Leo. Use this skill to guide users through the complete video creation process from initial idea validation through final editing.

## When to Use This Skill

Use this skill when users:
- Need help brainstorming or validating YouTube video ideas
- Want to create compelling titles and thumbnails
- Are struggling with video intros and viewer retention
- Need editing guidance for maximum engagement
- Ask about YouTube strategy, algorithm, or best practices
- Want to analyze existing content for improvement opportunities
- Are creating scripts or outlines for YouTube videos (use with outlining/scriptwriting skills)

## Core Philosophy and Algorithm Understanding

### The Simple Truth

**Mr. Beast's Algorithm Explanation:** "If people are clicking and watching then it gets promoted more and that's all. That's literally all the algorithm does is reflect what the people want."

**Success on YouTube = Videos that people:**
1. Click on (CTR - Click Through Rate)
2. Watch (AVD - Average View Duration)

**The Real Challenge:** Not the algorithm itself (it's simple and fair). The hard part is doing it better than everyone else. Every creator is trying to make clickable, watchable content. Excellence is the differentiator.

**Strategic Implication:** Entire video production process must be designed around maximizing clicks and watch time. Everything else is secondary.

## The Complete YouTube Workflow

### Stage 1: Ideation (Multi-Day Process)

**Purpose:** Find video ideas in popular areas of interest that have 5-10x viral potential.

**Key Insight:** Popular area of interest = 1,000x more views than unpopular area. One breakthrough video in popular area > year of mediocre videos in unpopular area.

**When to read ideation_framework.md:**
- User needs to generate video ideas
- User wants to validate existing ideas
- User asks about research process or finding what audience wants
- User mentions struggling to get views or wants "viral" ideas

**Core Process:**
1. **Deep Research (5+ days):** Gather audience data, identify patterns, understand WHY audience watches certain content
2. **Idea Generation:** Use deep knowledge + daily practice OR concept adaptation with compatibility testing
3. **Validation (Four Tests):** Fresh perspective test, originality check, best option assessment (top 10% rule), title/thumbnail creation test

**Critical Rule:** Create title and thumbnail BEFORE any production work. If you can't make clear connection between audience motivation and video value, idea won't work.

### Stage 2: Title & Thumbnail Creation

**Purpose:** Create multiple compelling reasons to watch within 1 second.

**Key Insight:** Title and thumbnail must BUILD on each other (not repeat information) to maximize information delivery speed.

**When to read titles_thumbnails_framework.md:**
- User is creating titles or thumbnails
- User wants to improve CTR (click-through rate)
- User asks about packaging or marketing their video
- User needs help validating ideas through title/thumbnail test

**Core Strategy:**
1. **Create Reasons to Click:** Use one of four methods (plant question, throw into story, promise journey, address something interesting)
2. **Maximize Speed:** Build title on thumbnail, never repeat information
3. **Eye-Catching Thumbnails:** Use spotlight elements (faces, familiar objects, short text) + visual storytelling
4. **Title Wording:** Front-load important words, don't spoil anything, be dramatic not literal

**Critical Rule:** Can someone identify reason to watch within 1 second? If not, iterate.

### Stage 3: Intro Creation

**Purpose:** Immediately deliver on promises made by title/thumbnail to prevent 90% drop phenomenon.

**Key Insight:** Intros must match both CONTENT and FEELING promises. Create title, thumbnail, and intro simultaneously.

**When to read intro_framework.md:**
- User is writing video intro/opening
- User mentions losing viewers in first 30 seconds
- User wants to improve retention at start of video
- User asks about hook or opening strategy

**Core Strategy:**
1. **Simultaneous Creation:** Create title, thumbnail, and intro together to ensure alignment
2. **Pacing/Mood/Style Matching:** Match both content promise and feeling/energy promise from title/thumbnail
3. **Visual Storytelling:** Use voiceovers with B-roll, switch camera every ~4 seconds
4. **Information Architecture:** Present information as narrative, create micro-hooks
5. **Multiple Rewrites:** Optimize adjectives, sentence structure, detail level, information order (up to 5+ rewrites)
6. **Editing Excellence:** Add graphics, sound effects, captions, transitions every few seconds
7. **Exceeding Expectations:** Reveal additional value beyond initial promise (advanced strategy)

**Critical Rule:** First 5 seconds must deliver on core promise. Both content AND feeling must be present.

### Stage 4: Script Writing & Retention

**Purpose:** Keep viewers watching from start to finish through systematic application of retention principles.

**Key Insight:** Must make viewers care BEFORE delivering value. Green/purple formula creates curiosity before providing answers.

**When to read retention_framework.md:**
- User is writing full video script
- User wants to improve retention/watch time
- User asks about keeping viewers engaged
- User mentions viewers dropping off mid-video
- Use WITH scriptwriting skill for complete script development

**Core Strategy (Six Components):**

**Component 1: Green/Purple Formula**
- Green sections (create curiosity): Problem, mystery, question, expectation
- Purple sections (deliver payoff): Answers, solutions, reveals
- Pattern: Green → Purple → Green → Purple throughout
- Use three-part litmus test: What's happening, why important, what could go wrong

**Component 2: Camera Energy**
- Treat camera like interested friend (not audience/critics)
- Use full range of vocal variety, facial expressions, hand gestures
- Embrace mistakes over monotone perfection
- Whatever emotion you show, viewer feels

**Component 3: But/Therefore/So Structure**
- Replace "and then" with causal connections (but, therefore, so)
- Creates seamless flow and immersion
- No exit points for disengagement

**Component 4: Maximum Communication**
- Revisit script ~100 times for clarity
- Use analogies and examples for abstract concepts
- Show visual for everything mentioned
- Get outside perspective to find blind spots
- You're biased (have all context), viewer isn't (has none)

**Component 5: Strategic Variety**
- Variety like seasonings - enhance flavor, don't overpower
- Good: Mood variety creates engagement
- Bad: Too much visual variety prevents value absorption
- Purpose and amount calibrated to effect needed

**Component 6: Beat Competition**
- Study top 20 videos in niche
- Identify what audience values
- Provide it better than anyone else
- This is THE secret to going viral

**Critical Rule:** Value inaccessible = value nonexistent. Must communicate clearly or viewer can't access value.

### Stage 5: Editing

**Purpose:** Create addictive viewing experience through four-pillar editing framework.

**Key Insight:** Context determines success. Editing must match what viewer came for (disruption of expected experience = best way to make them stop watching).

**When to read editing_framework.md:**
- User is editing video or asking about editing techniques
- User wants to improve production quality
- User asks about pacing, sound design, or visual variety
- User mentions video feels "flat" or "boring" despite good content

**Core Strategy (Four Pillars):**

**Pillar 1: Healthy Variety of Visuals**
- Mix A-roll, B-roll, motion graphics every few seconds
- Use 6 professional focus point techniques
- Balance: Quality of engagement > quantity of cuts
- Avoid visual mush through strategic shot duration

**Pillar 2: Visual Continuity**
- Maintain focus point continuity across cuts
- Animate graphics into frame (don't appear magically)
- Use full-screen transitions when needed
- Break continuity strategically for emphasis

**Pillar 3: Immersive Audio (Sound Design)**
- Whoosh sounds for movement, highlight sounds for emphasis
- Risers build anticipation, hits create emphasis, drones create suspense
- Literally hijack viewer emotions through sound
- Double stimulation = double engagement

**Pillar 4: Immersive Audio (Music Strategy)**
- Match music to section mood (mood mapping process)
- Abrupt pauses for special moments
- Fade outs signal transitions
- Sync hits/dips to key video moments

**Critical Rule:** Different genres require different execution. Match editing to audience expectations (entertainment = maximum stimulation, authentic = minimal editing, educational = balanced approach).

## Integration with Other Skills

### With Outlining Skills (content-outlining)

**When to combine:**
- User creating content outline or structure for video series
- User needs to break down complex topic into video segments
- User wants hierarchical content structure with logical progression

**Workflow:**
1. Use youtube-mastery ideation framework to identify popular areas of interest
2. Use content-outlining skill to create WBS and hierarchical structure
3. Apply retention framework's green/purple formula to outline structure
4. Validate each section can be packaged with compelling title/thumbnail

### With Writing Skills (scriptwriting, human-writing)

**When to combine:**
- User writing actual video script
- User needs natural, engaging script flow
- User wants to avoid AI writing patterns

**Workflow:**
1. Use youtube-mastery retention framework for structure (green/purple, but/therefore/so)
2. Use scriptwriting skill for natural dialogue and avoiding clichés
3. Use human-writing skill for authentic voice at Bloom's levels 5-6
4. Apply editing framework guidance during script writing (plan for visuals, sound, pacing)

### With Project Management Skills

**When to combine:**
- User planning video series or content calendar
- User needs production timeline and resource allocation
- User wants to track metrics and optimize content strategy

**Workflow:**
1. Use stakeholder-analysis to understand audience deeply
2. Use scope-management for defining video/series scope
3. Use youtube-mastery frameworks for execution
4. Use quality-assurance for content verification before publishing

## Common Use Patterns

### Pattern 1: Complete Video Creation from Scratch

**User says:** "I want to create a YouTube video about [topic]"

**Workflow:**
1. Read ideation_framework.md and guide user through research phase
2. Help validate ideas using four tests (especially title/thumbnail test)
3. Read titles_thumbnails_framework.md to create compelling packaging
4. Read intro_framework.md to design intro matching title/thumbnail promises
5. Read retention_framework.md and work with scriptwriting skill for full script
6. Reference editing_framework.md for post-production guidance

### Pattern 2: Improving Existing Content

**User says:** "My videos aren't getting views" or "People drop off after 30 seconds"

**Workflow:**
1. Analyze what stage is failing (ideation, packaging, intro, retention, editing)
2. Read relevant framework reference
3. Apply diagnostic questions from that framework
4. Provide specific improvements based on framework principles
5. If multiple stages need work, prioritize: ideation → title/thumbnail → intro → retention → editing

### Pattern 3: Idea Validation and Research

**User says:** "Is this a good video idea?" or "How do I know what my audience wants?"

**Workflow:**
1. Read ideation_framework.md
2. Guide through four validation tests
3. If idea fails tests, help iterate or generate alternatives
4. Ensure understanding of popular vs. unpopular areas of interest
5. Emphasize top 10% rule and 5-10x multiplier threshold

### Pattern 4: Script Development

**User says:** "Help me write a script for [topic]"

**Workflow:**
1. Confirm title/thumbnail already created (if not, do that first)
2. Read retention_framework.md for structure
3. Combine with scriptwriting skill for execution
4. Apply green/purple formula throughout
5. Use but/therefore/so structure for connections
6. Plan for visuals, sound, and editing during writing
7. Remind user to revisit ~100 times for clarity

## Critical Reminders

### The Algorithm is Fair but Competition is Fierce
- Success comes from execution excellence, not algorithm gaming
- Every creator tries to make clickable, watchable content
- Excellence is the only differentiator
- Bar for "good enough" is higher than most creators realize

### Ideas Make or Break Videos
- Can't fix bad idea with good execution
- Great idea with average execution > average idea with great execution
- Spend days on ideation, not hours
- Only make top 10% of ideas (5-10x multipliers minimum)

### Front-Load Quality in Workflow
- Ideation determines scale (popular vs. unpopular area = 1,000x difference)
- Title/thumbnail determine if anyone clicks
- Intro determines if they stay past 5 seconds
- Retention determines if they watch to end
- Editing determines if experience matches promises
- Weak link in chain undermines everything

### Context Always Determines Success
- Understand what experience your viewers want
- Match your execution to their expectations
- Sam Sulek and Mr. Beast both successful with opposite editing styles
- Your audience determines your approach, not generic "best practices"

### Measurement and Iteration
- Track CTR (click-through rate) - measures ideation/title/thumbnail quality
- Track AVD (average view duration) - measures retention/editing quality
- Track % viewed - normalizes across video lengths
- Study retention graphs to find drop-off points
- Compare to competition in your niche
- Iterate based on data, not assumptions

## Key Philosophical Principles

1. **Popular Areas Scale Exponentially:** One video in popular area = 1,000+ videos in unpopular area
2. **Speed is Survival:** In attention economy, fastest video to convey value proposition wins
3. **Promises Must Be Kept Immediately:** Every second expectations aren't met is second they might leave
4. **Curiosity Before Content:** Never give information before making viewer care about it
5. **Emotion is Contagious:** Whatever emotion you show, viewer feels too
6. **You're Biased, Viewer Isn't:** You have all context, viewer has none - revisit ~100 times
7. **Value Inaccessible = Value Nonexistent:** Must communicate clearly or viewer can't access value
8. **Context Trumps Technique:** Editing must match what viewer came for
9. **Professional Perception Matters:** Looking professional builds trust
10. **Excellence is Expected:** Good enough isn't good enough in competitive YouTube environment

## Framework Reference Files

All detailed methodologies are stored in `references/` directory:

- **ideation_framework.md** - Complete ideation process including research, generation, validation
- **titles_thumbnails_framework.md** - Title and thumbnail creation for maximum clicks
- **intro_framework.md** - Intro strategies preventing viewer drop-off
- **retention_framework.md** - Six-component framework for keeping viewers watching
- **editing_framework.md** - Four-pillar editing formula for addictive videos

Read relevant framework when user's question or task aligns with that stage of production. Multiple frameworks often needed for complete video creation workflow.

---
name: content-outlining
description: Comprehensive content outlining skill for educational video production following PMI WBS principles and Bloom's Taxonomy. This skill should be used when creating hierarchical content structures, establishing logical flow and progression, identifying prerequisite relationships between topics, or balancing content distribution across videos. Transforms defined scope into actionable script structure.
license: Complete terms in LICENSE.txt
---

# Content Outlining for Educational Video Production

This skill provides comprehensive workflows for creating hierarchical content outlines that transform defined scope into actionable structure for video scripts and documentation. It applies PMI Work Breakdown Structure principles combined with Bloom's Taxonomy to create logical, balanced, and effective educational content organization.

## Purpose

Content outlining bridges the gap between scope definition and script writing. A well-structured outline ensures logical learning progression, appropriate content depth, balanced distribution across videos, and clear prerequisite relationships. This skill addresses the challenge of organizing complex educational content into digestible, sequential learning units that build student mastery systematically.

## When to Use This Skill

**Primary Use Cases:**
- Creating hierarchical content structure from series to detailed content points
- Establishing logical flow and learning progression across videos
- Identifying and mapping prerequisite relationships between topics
- Balancing content distribution (duration, complexity, depth) across videos
- Validating outline completeness against scope requirements
- Generating multiple outline formats (hierarchical, linear, WBS, timing) for different purposes

**Integration with Project Management:**
- Works with scope-management skill (scope defines WHAT, outline defines HOW TO ORGANIZE)
- Applies PMI WBS decomposition principles to educational content
- Provides input to script writing and production planning
- Enables accurate duration and effort estimation

## Core Outlining Workflows

### Workflow 1: Decompose Series Scope to Module Level

Group video topics into thematic modules that represent major learning milestones.

**Process:**

1. **Review Series Scope Statement:**
   - Examine major topic areas from in-scope list
   - Review series learning objectives (high-level outcomes)
   - Check target audience level and prerequisites

2. **Identify Natural Groupings:**
   - Topics sharing common theme or learning objective
   - Topics with strong prerequisite relationships
   - Topics at similar complexity level
   - Topics that build progressively on each other

3. **Apply Bloom's Taxonomy Progression:**
   - Early modules: Remember, Understand (foundation concepts)
   - Middle modules: Apply, Analyze (practical application)
   - Later modules: Evaluate, Create (synthesis and mastery)
   - Ensure natural progression across series

4. **Create Module Descriptions:**
   - Descriptive, thematic module name
   - 2-3 sentence focus description
   - Module-level learning objective
   - Number of videos planned in module
   - Estimated module duration

**Validation:**
- All series scope topics assigned to a module
- Modules follow logical learning progression
- Module count manageable (typically 2-5 per series)
- Each module has clear theme and outcome
- Modules serve as natural completion milestones

**Output:** Module-level structure (WBS Level 2) with thematic organization

**Reference:** See "Content Outlining Process > Step 1" in `/references/content_outlining_standards.md`

**Example:** See Example 1 (GitHub Fundamentals complete WBS) in `/references/outlining_examples.md`

### Workflow 2: Outline Individual Videos

Create detailed outline for each video within modules, defining structure from introduction through conclusion.

**Process:**

1. **Review Video Scope Statement:**
   - Learning objectives (specific, measurable outcomes)
   - In-scope topics (what to cover)
   - Out-of-scope topics (what to avoid)
   - Target duration range

2. **Apply Standard Video Structure Template:**
   - Introduction (2-3 minutes): Hook, context, preview
   - Main content sections (65-75% of video): Core teaching
   - Practice exercise (15-20% of video): Application
   - Conclusion (2-3 minutes): Summary, next steps

3. **Decompose Topics to Sections:**
   - Each major in-scope topic becomes video section (Level 4)
   - Order sections by logical learning flow
   - Ensure prerequisites covered before dependent topics
   - Balance explanation with demonstration

4. **Detail Section Content:**
   - Break sections into concept explanation + demonstration
   - Identify specific steps for demonstrations
   - Note screen recording requirements
   - Plan visual aids or diagrams needed

5. **Design Practice Exercise:**
   - Create exercise applying section concepts
   - Ensure achievable with content covered
   - Provide appropriate scaffolding for audience level
   - Define clear success criteria

6. **Estimate Timing:**
   - Allocate minutes to each section
   - Sum total to verify within target duration
   - Adjust if outside range (cut content or split video)
   - Build 10-15% buffer for production variance

**Output:** Detailed video outline ready for script writing

**Template:** Use Standard Video Outline Template in `/references/content_outlining_standards.md` under "Consistent Structure Templates"

**Reference:** See "Content Outlining Process > Step 2" in `/references/content_outlining_standards.md`

**Example:** See Example 2 (Collaboration Basics detailed outline) in `/references/outlining_examples.md`

### Workflow 3: Create Complete Content Hierarchy

Build comprehensive hierarchical view of series content structure showing relationships and organization.

**Hierarchy Levels:**

**Level 1: Series** (Entire learning program)
**Level 2: Module** (Thematic grouping)
**Level 3: Video** (Individual learning unit)
**Level 4: Section** (Major segment within video)
**Level 5: Content Point** (Specific concept, demonstration, example)

**Deliverable-Based View (WBS Format):**
- Uses numerical notation (1.0, 1.1, 1.1.1, etc.)
- Shows parent-child relationships clearly
- Enables precise referencing and tracking
- Aligns with PMI WBS standards

**Topic-Based View (Outline Format):**
- Uses heading hierarchy (H1-H5 in markdown)
- More readable for content development
- Shows flow and progression naturally
- Better for script writing reference

**Create Both Views:**
1. Start with deliverable-based for structure
2. Transform to topic-based for usability
3. Keep synchronized as content evolves
4. Use each for appropriate purpose

**Benefits:**
- Clear overview of entire series content
- Easy identification of gaps or redundancies
- Validation of logical flow across videos
- Foundation for dependency mapping
- Reference during script writing and review

**Output:** Complete hierarchical content structure in both WBS and outline formats

**Reference:** See "Content Outlining Process > Step 3" in `/references/content_outlining_standards.md`

**Example:** See Example 1 (Complete WBS hierarchy) in `/references/outlining_examples.md`

### Workflow 4: Map Prerequisites and Dependencies

Identify and document prerequisite relationships to ensure proper learning sequence.

**Dependency Types:**

**Hard Prerequisites:**
- Concept B cannot be understood without concept A (mandatory sequence)
- Demonstration requires knowledge from previous video
- Tool or account setup needed before usage
- Terminology must be defined before use

**Soft Prerequisites:**
- Concept B easier with concept A background (recommended but not required)
- Example builds on familiar scenario from earlier
- Related skill transfer makes learning smoother

**Process:**

1. **Identify Dependencies:**
   - For each video, list required prior knowledge
   - For each section, note concepts used but not defined
   - Flag terminology, tools, techniques assumed known
   - Distinguish hard vs soft prerequisites

2. **Validate Coverage:**
   - Confirm prerequisites covered in earlier content
   - Check timing (prerequisite must come before dependent)
   - Verify sufficient depth (prerequisite taught adequately)
   - Check for external prerequisites (non-series content)

3. **Create Dependency Diagram:**
   - Visual map showing prerequisite relationships
   - Boxes represent videos or topics
   - Arrows show prerequisite direction
   - Identify sequential chains vs parallel paths

4. **Document in Outline:**
   - List prerequisites at video level
   - Note prerequisite sections within video
   - Flag external prerequisites explicitly
   - Update as outline evolves

**Validation Questions:**
- Can student understand video N without video N-1?
- Are all concepts used in demonstrations already explained?
- Is terminology defined before use?
- Are external prerequisites clearly stated?
- Are there circular dependencies (A requires B requires A)?

**Output:** Prerequisite documentation and dependency diagram

**Reference:** See "Content Outlining Process > Step 4" in `/references/content_outlining_standards.md`

**Example:** See Example 1 (GitHub Fundamentals dependency mapping) in `/references/outlining_examples.md`

### Workflow 5: Balance Content Distribution

Adjust content allocation across videos to optimize learning, engagement, and production feasibility.

**Evaluation Criteria:**

**Duration Balance:**
- Check each video against target duration range
- Foundation: 15-25 minutes
- Intermediate: 18-28 minutes
- Advanced: 20-30 minutes
- Expert: 25-35 minutes
- Identify videos significantly over or under target

**Complexity Balance:**
- Rate each video's complexity (1-5 scale)
- Avoid clustering all complex content together
- Intersperse challenging with reinforcement videos
- Consider cognitive load management

**Bloom's Taxonomy Balance:**
- Map each video to primary Bloom's level
- Ensure progression across series (Remember → Create)
- Verify foundation videos don't jump to Evaluate/Create prematurely
- Advanced content appropriately challenges students

**Topic Granularity Balance:**
- Check each video focuses on cohesive topic or closely related set
- Identify videos trying to cover too much (scope creep)
- Look for videos with insufficient content (too narrow)

**Rebalancing Actions:**

**If Video Too Long:**
1. Review scope - is out-of-scope content included?
2. Check depth - going too deep for audience level?
3. Split into two videos if covering distinct topics
4. Move less critical content to supplemental documentation
5. Reduce example count (keep best, most illustrative)

**If Video Too Short:**
1. Review scope - missing in-scope content?
2. Check depth - insufficient explanation or practice?
3. Combine with closely related video
4. Add more examples or practice opportunities
5. Expand demonstrations with step-by-step details

**If Complexity Unbalanced:**
1. Redistribute complex topics across series
2. Add simpler reinforcement videos between challenges
3. Break complex videos into multi-part series
4. Add scaffolding to make complex content more accessible

**Output:** Balanced content distribution optimizing learning and production

**Reference:** See "Content Outlining Process > Step 5" in `/references/content_outlining_standards.md`

### Workflow 6: Select and Apply Outline Format

Choose appropriate outline format(s) for the intended use case and audience.

**Common Formats:**

**1. Hierarchical Outline (Content Development)**
- Uses markdown heading levels (H1-H5)
- Nested structure with indentation
- Most readable for script writing
- Good for team collaboration

**When to Use:**
- Initial content organization
- Script writing reference
- Team review and feedback
- General content structure discussion

**2. Linear Script Outline (Production)**
- Sequential flow with timestamps
- Exact narration and timing
- Screen recording cues
- Teleprompter-ready

**When to Use:**
- Recording with teleprompter or script
- Precise timing requirements
- Production scheduling
- Detailed screen recording planning

**3. WBS Dictionary (Project Management)**
- Formal specifications for each element
- Includes deliverables, effort estimates, dependencies
- Aligns with PMI standards
- Production planning detail

**When to Use:**
- Formal project documentation
- Effort estimation and scheduling
- Team handoffs between roles
- Progress tracking and reporting

**4. Timing Breakdown (Validation)**
- Tabular format with time allocations
- Section-by-section duration
- Percentage analysis
- Production feasibility check

**When to Use:**
- Validating duration targets
- Identifying pacing issues
- Production scheduling
- Post-production editing reference

**Process:**
1. Determine primary use case
2. Select appropriate format(s)
3. Create outline in chosen format
4. Transform to additional formats as needed
5. Keep formats synchronized during updates

**Output:** Outline in appropriate format(s) for intended use

**Reference:** See "Outline Formats and Use Cases" in `/references/content_outlining_standards.md`

**Example:** See Example 4 (Format comparison) in `/references/outlining_examples.md`

### Workflow 7: Validate Outline Against Requirements

Systematically verify outline satisfies stakeholder requirements and scope definition before script development.

**Validation Checklist:**

**Scope Coverage:**
- [ ] All in-scope topics from scope statement covered
- [ ] No out-of-scope topics included
- [ ] Learning objectives from scope achievable with outline
- [ ] Video count matches series planning
- [ ] Module structure aligns with planned progression

**Stakeholder Needs:**
- [ ] Content depth appropriate for target audience level
- [ ] Practice opportunities meet stakeholder requirements
- [ ] Duration targets align with time constraints
- [ ] Prerequisites clearly documented for students
- [ ] Success criteria achievable and measurable

**Learning Design Quality:**
- [ ] Each video has clear, specific learning objective
- [ ] Logical progression across series (no complexity jumps)
- [ ] Bloom's Taxonomy progression appropriate
- [ ] Prerequisites covered before dependent topics
- [ ] Balance of explanation, demonstration, practice

**Consistency:**
- [ ] Consistent outline structure across all videos
- [ ] Terminology usage consistent
- [ ] Similar content patterns for similar content types
- [ ] Heading hierarchy follows standards

**Production Feasibility:**
- [ ] Total series duration matches timeline
- [ ] Video durations realistic for production constraints
- [ ] Resource requirements identified (recordings, demos, examples)
- [ ] No unrealistic complexity in demonstrations
- [ ] Effort estimates align with available resources

**Validation Process:**
1. Review outline systematically against scope statement
2. Walk through series as student (does flow make sense?)
3. Check prerequisites (can each video be understood?)
4. Verify balance (duration, complexity, topic distribution)
5. Get peer review (fresh perspective on completeness)
6. Document validation results and action items

**Output:** Validated outline with approval to proceed to script development or documented refinement needs

**Reference:** See "Validation and Quality Assurance" in `/references/content_outlining_standards.md`

## Outlining Best Practices

### Progressive Refinement: Broad to Specific

Start with high-level structure, progressively add detail through iteration.

**Iteration Sequence:**
1. **Series Level:** Major modules and themes (2-5 modules)
2. **Module Level:** Individual video topics and order (2-8 videos per module)
3. **Video Level:** Main sections and flow within video (3-5 major sections)
4. **Section Level:** Specific content points and demonstrations (3-8 points per section)
5. **Detail Level:** Exact steps, examples, and timing estimates

**Benefits:**
- Easier to see overall structure and balance early
- Flexibility to adjust before investing in detailed work
- Clear progression prevents getting lost in details
- Validation possible at each level before drilling down
- Course corrections less costly at higher levels

**Application:**
- Resist urge to detail early videos before planning whole series
- Validate high-level structure with stakeholders before detail
- Use "outline the outline" approach (meta-structure first)

### Use Standard Templates

Apply consistent structure templates for predictable, high-quality results.

**Template Benefits:**
- Faster outlining process (starting point provided)
- Consistent quality across videos
- Reduced cognitive load (less decision fatigue)
- Easier validation and review (known structure)
- Better student experience (predictable format)

**Build Template Library:**
- Introduction video template
- Concept explanation template
- Tool demonstration template
- Comparison video template
- Workflow video template
- Case study template
- Challenge/project template

**Customization:**
- Templates provide starting structure
- Adapt to specific content needs
- Remove unnecessary sections
- Add domain-specific sections
- Maintain core structure for consistency

**Reference:** See "Content Outlining Best Practices > Build Template Library" in `/references/content_outlining_standards.md`

### Visual Hierarchy Matters

Consistent heading levels and formatting improve navigation and comprehension.

**Markdown Hierarchy Standards:**
```markdown
# Series Level (H1)
## Module Level (H2)
### Video Level (H3)
#### Section Level (H4)
##### Content Point Level (H5)
```

**WBS Notation Standards:**
```
1.0 Series
  1.1 Module
    1.1.1 Video
      1.1.1.1 Section
        - Content point
```

**Visual Enhancement:**
- Bold for emphasis on key concepts
- Italics for instructional notes (not student-facing)
- Code blocks for technical content
- Block quotes for examples or scenarios
- Bullet lists for parallel items
- Numbered lists for sequential steps

**Benefits:**
- Clear visual scanning of structure
- Easy navigation to specific sections
- Obvious parent-child relationships
- Professional, polished appearance

### Incorporate Engagement Elements

Plan student engagement strategies directly into outline structure.

**Engagement Techniques:**

**Pattern Interrupts:**
- Change pace every 5-7 minutes
- Alternate explanation with demonstration
- Use visual aids to break up talking head
- Pose questions for mental engagement
- Brief exercises or checkpoints

**Active Learning Prompts:**
- "Pause and try this yourself"
- "What do you think will happen?"
- "Can you think of a scenario for this?"
- "Reflect on how this applies to your work"

**Reinforcement Strategies:**
- Recap key point at end of each section
- Preview-do-review structure within sections
- Reference earlier concepts to strengthen connections
- Summarize learning objectives achieved

**Community Engagement:**
- "Share your results in comments"
- "What challenges did you face?"
- "Upload your project to show community"
- "Vote for what you'd like to learn next"

**Mark in Outline:**
- Tag engagement elements with [ENGAGEMENT] or similar
- Ensures not overlooked during script writing
- Maintains variety and interaction throughout

## Integration with Other Skills

**Scope Management Skill:**
- Scope defines what to cover, outline defines how to organize it
- In-scope topics become outline sections
- Out-of-scope topics guide what to avoid
- Learning objectives from scope drive section structure
- Scope validation uses outline as evidence of coverage

**Stakeholder Analysis Skill:**
- Target audience characteristics determine content depth
- Stakeholder learning goals guide section focus
- Technical level affects Bloom's Taxonomy progression
- Time constraints influence video duration targets

**Project Management Skill:**
- Outline provides input to WBS and scheduling
- Effort estimates enable resource allocation
- Dependencies inform production sequencing
- Structure enables progress tracking

**Human Writing Skill:**
- Outline provides structure for script writing
- Hierarchical organization guides flow
- Section boundaries define writing units
- Timing allocations inform content density

## Common Outlining Pitfalls

### Pitfall 1: Too Much Detail Too Soon
**Problem:** Getting bogged down in section-level details before validating high-level structure wastes effort if major restructuring needed.

**Prevention:**
- Start with series/module structure (Level 1-2)
- Validate overall flow before drilling down (Level 3-4)
- Use iterative refinement (broad to specific)
- Save detailed timing for script development phase

### Pitfall 2: Insufficient Content Hierarchy
**Problem:** Flat outlines without clear hierarchical organization make navigation difficult and obscure relationships.

**Prevention:**
- Use consistent heading levels (H1-H5)
- Follow WBS hierarchical principles (2-5 levels)
- Maintain parent-child relationships clearly
- Use visual hierarchy markers (indentation, numbering)

### Pitfall 3: Missing Prerequisites
**Problem:** Content assumes knowledge not yet covered, breaking learning flow and frustrating students.

**Prevention:**
- Explicitly map all dependencies
- Validate prerequisites covered before use
- Check terminology definitions before use
- Get fresh-eyes review from someone unfamiliar with topic
- Create and reference dependency diagram

### Pitfall 4: Unbalanced Distribution
**Problem:** Some videos packed while others thin, or all complex videos clustered, creating uneven learning experience.

**Prevention:**
- Track video durations in outline phase
- Rate and distribute complexity across series
- Balance explanation with demonstration
- Review distribution visually (chart or spreadsheet)
- Apply rebalancing actions systematically

### Pitfall 5: Scope Creep in Outline
**Problem:** Adding topics not in defined scope during outlining undermines scope management and timeline.

**Prevention:**
- Reference scope statement constantly during outlining
- Maintain "future content" list for ideas outside scope
- Validate outline against scope before script development
- Get formal scope change approval if outline reveals necessary additions

## Outlining Tools and Techniques

### Mind Mapping
Visual brainstorming for initial content organization before formal hierarchy.

**When to Use:** Beginning of outlining, identifying connections, brainstorming groupings
**Process:** Center = series, branches = modules/videos, identify natural groupings
**Tools:** Paper/pen, Miro, MindMeister, Lucidchart

### Dependency Diagrams
Visual representation of prerequisite relationships for complex series.

**When to Use:** Complex interdependencies, validating coverage, team communication
**Elements:** Boxes = videos, arrows = prerequisites, colors = levels/modules
**Benefits:** Clear visualization of learning paths and bottlenecks

### Content Spreadsheets
Tabular format for tracking multiple dimensions simultaneously.

**Columns:** WBS ID, Title, Module, Objectives, Prerequisites, Duration, Complexity, Bloom's Level, Status
**Benefits:** Easy sorting, quantitative analysis, progress visualization, resource allocation
**When to Use:** Balancing factors, production planning, progress tracking

### Template-Based Outlining
Standardized templates for consistent structure and efficient development.

**Benefits:** Faster process, consistent quality, reduced cognitive load, easier validation
**Application:** Start with template, adapt to needs, maintain core structure
**Templates:** Introduction, concept explanation, tool demo, comparison, workflow, case study

**Reference:** See "Outlining Tools and Techniques" in `/references/content_outlining_standards.md`

## Quick Reference

### When Starting Series Outline
1. Read video scope statements for entire series
2. Identify natural module groupings (2-5 modules)
3. Apply Bloom's Taxonomy progression across modules
4. Validate module structure before detailing videos

### When Outlining Individual Video
1. Use Standard Video Outline Template
2. Decompose in-scope topics to sections
3. Order sections by logical prerequisite flow
4. Allocate time to sections, validate total
5. Design practice exercise applying concepts

### When Creating Hierarchy
1. Build both WBS notation and outline format
2. Maintain 3-5 hierarchy levels (Series → Point)
3. Use consistent heading levels or numbering
4. Validate completeness (100% rule)

### When Mapping Dependencies
1. List prerequisites for each video explicitly
2. Distinguish hard vs soft prerequisites
3. Create dependency diagram for complex series
4. Validate no circular dependencies

### When Balancing Content
1. Check all videos against duration targets
2. Rate complexity (1-5) and distribute evenly
3. Map Bloom's levels, ensure progression
4. Apply rebalancing actions as needed

### When Validating Outline
1. Check against scope statement point-by-point
2. Walk through as student for flow validation
3. Verify prerequisites covered properly
4. Get peer review before script development
5. Document validation results

## Examples

For comprehensive content outline examples from the AI Education Platform project, see `/references/outlining_examples.md`:

- Example 1: Complete series-level WBS hierarchy (GitHub Fundamentals)
- Example 2: Detailed video outline with timing (Collaboration Basics)
- Example 3: Module-level content structure (Capstone project)
- Example 4: Outline format comparison (same content, four different formats)
- Lessons learned from content outlining practice

## References

**Bundled References:**
- `/references/content_outlining_standards.md` - Complete PMI WBS and outlining standards adapted for educational video
- `/references/outlining_examples.md` - Real-world outline examples from AI Education Platform project

**PMI Sources:**
- Practice Standard for Work Breakdown Structures, Third Edition - Hierarchical decomposition principles
- PMBOK Guide Seventh Edition - Project work and delivery performance domains

**Learning Design Sources:**
- Bloom's Taxonomy - Cognitive learning progression
- Instructional design best practices for video-based learning

## Success Indicators

Effective content outlining produces:
- Clear hierarchical structure from series to content points (3-5 levels)
- Logical flow with appropriate Bloom's Taxonomy progression
- Balanced content distribution across videos (duration, complexity, depth)
- Complete coverage of scope requirements with nothing extra
- Well-documented prerequisites enabling smooth learning flow
- Consistent structure across videos enabling efficient production
- Multiple format variants serving different use cases
- Validated outline approved by stakeholders before script development
- Realistic production planning with accurate effort estimates
- Foundation for high-quality, effective educational content

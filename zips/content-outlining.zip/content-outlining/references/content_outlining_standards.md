# Content Outlining Standards for Educational Video Production

## Overview

Content outlining transforms defined scope into hierarchical, actionable structure for video scripts and documentation. It applies PMI Work Breakdown Structure (WBS) principles to educational content, creating clear organization, logical flow, and balanced distribution of topics across videos.

**Source:** Practice Standard for Work Breakdown Structures, Third Edition; PMBOK Guide Seventh Edition; Bloom's Taxonomy for learning design

## Core Content Outlining Principles

### 1. Hierarchical Decomposition

Educational content follows hierarchical structure from broad to specific, enabling logical organization and clear navigation.

**Standard Hierarchy Levels:**

**Level 1: Series**
- Highest level of organization
- Represents complete learning path or program
- Example: "GitHub Fundamentals for Teams"

**Level 2: Module**
- Thematic grouping of related videos
- Represents major learning milestone or phase
- Example: "Team Collaboration" (within GitHub Fundamentals)

**Level 3: Video (Work Package)**
- Individual learning unit
- Single clear learning objective or tightly related set
- Lowest level where duration and effort can be estimated
- Example: "Collaboration Basics: Issues, Pull Requests, Reviews"

**Level 4: Video Sections**
- Major segments within video
- Corresponds to outline headers in script
- Example: "Creating Issues," "Pull Request Workflow," "Code Review Process"

**Level 5: Content Points**
- Specific concepts, demonstrations, or examples
- Bullet points or numbered steps in script
- Example: "Create issue with description and labels," "Assign issue to team member"

**The 100% Rule:**
From PMI WBS standards: Sum of work at each decomposition level must equal 100% of work required for parent level. For educational content, all learning objectives at lower level must completely satisfy parent level's objective.

### 2. Logical Flow and Progression

Content must follow natural learning progression from foundational to advanced, simple to complex, concrete to abstract.

**Flow Principles:**

**Cognitive Sequencing:**
- Prerequisites before dependent topics
- Concrete examples before abstract principles
- Simple before complex
- Familiar before unfamiliar
- Practice after instruction

**Bloom's Taxonomy Progression:**
1. **Remember:** Recall facts and basic concepts (definitions, terminology)
2. **Understand:** Explain ideas and concepts (descriptions, explanations)
3. **Apply:** Use information in new situations (demonstrations, practice)
4. **Analyze:** Draw connections between ideas (comparisons, relationships)
5. **Evaluate:** Justify decisions and approaches (trade-offs, best practices)
6. **Create:** Produce new work using learned skills (projects, implementations)

**Foundation Level Content:**
- Focus on Remember, Understand, Apply
- Heavy emphasis on step-by-step procedures
- Concrete examples throughout
- Frequent practice opportunities

**Intermediate Level Content:**
- Focus on Apply, Analyze
- Multi-step workflows
- Comparison of approaches
- Integration examples

**Advanced Level Content:**
- Focus on Analyze, Evaluate
- Optimization and edge cases
- Architecture patterns
- Decision-making frameworks

**Expert Level Content:**
- Focus on Evaluate, Create
- Design from first principles
- System integration
- Innovation and extension

**Topic Dependency Mapping:**
- Identify prerequisite relationships between topics
- Ensure prerequisites covered before dependent topics
- Create dependency diagram for complex series
- Validate no circular dependencies

### 3. Content Balance and Distribution

Distribute content appropriately across videos to maintain engagement, ensure depth, and respect time constraints.

**Balance Criteria:**

**Video Duration Balance:**
- Target range: 15-35 minutes per video
- Foundation videos: 15-25 minutes (attention span considerations)
- Intermediate videos: 18-28 minutes
- Advanced videos: 20-30 minutes
- Expert videos: 25-35 minutes (deeper content, more focused audience)

**Complexity Distribution:**
- Avoid clustering all complex topics in single video
- Intersperse challenging content with simpler reinforcement
- Balance theory with practice in each video
- Mix conceptual explanation with concrete demonstration

**Topic Granularity:**
- Each video focuses on cohesive topic or closely related set
- Avoid cramming unrelated topics into single video
- Split if video exceeds target duration by >20%
- Combine if video falls below minimum threshold

**Practice Opportunity Distribution:**
- Every video includes at least one practice opportunity
- Foundation videos: 2-3 practice exercises (more guided)
- Intermediate videos: 2 practice exercises (less scaffolding)
- Advanced videos: 1-2 challenges (open-ended)
- Expert videos: 1 comprehensive project or challenge

### 4. Consistent Structure Templates

Standardized outline templates ensure quality, completeness, and efficiency in script development.

**Standard Video Outline Template:**

```markdown
# Video Title: [Descriptive, specific title]

## Metadata
- Series: [Series name]
- Module: [Module name]
- Duration Target: [15-35 minutes]
- Level: [Foundation/Intermediate/Advanced/Expert]

## Learning Objectives
After this video, students will be able to:
1. [Action verb] [specific outcome]
2. [Action verb] [specific outcome]
3. [Action verb] [specific outcome]

## Prerequisites
- [Required prior knowledge or completed videos]

## Introduction (2-3 minutes)
### Hook (30 seconds)
- [Problem statement or compelling scenario]

### Context Setting (1 minute)
- Why this topic matters
- Where it fits in overall learning path
- What students will accomplish

### Preview (1 minute)
- Overview of major sections
- Expected outcomes by end

## Section 1: [Topic Name] (X minutes)
### Concept Explanation (X minutes)
- [Key concept or principle]
- [Why it matters]
- [How it works]

### Demonstration (X minutes)
- [Step 1 with screen recording cue]
- [Step 2 with screen recording cue]
- [Step 3 with screen recording cue]

### Key Takeaway (30 seconds)
- [Main point to remember]

## Section 2: [Topic Name] (X minutes)
[Same structure as Section 1]

## Section 3: [Topic Name] (X minutes)
[Same structure as Section 1]

## Practice Exercise (3-5 minutes)
### Exercise Description
- [What students will do]
- [Expected outcome]

### Guided Steps (if applicable)
- [Scaffolding for practice]

### Success Criteria
- [How to know you got it right]

## Conclusion (2-3 minutes)
### Summary (1 minute)
- [Recap key points]
- [Review learning objectives achieved]

### Next Steps (1 minute)
- [What comes next in series]
- [How to apply what learned]
- [Additional resources if relevant]

### Call to Action (30 seconds)
- [Encouragement to practice]
- [Community engagement invitation]
- [Preview next video]

## Production Notes
- [Screen recording requirements]
- [Visual aids needed]
- [Code examples to prepare]
- [Potential challenges or common student questions]
```

**Section Timing Guidelines:**
- Introduction: 2-3 minutes (10-15% of video)
- Main content: 10-28 minutes (65-75% of video)
- Practice: 3-5 minutes (15-20% of video)
- Conclusion: 2-3 minutes (10-15% of video)

## Content Outlining Process

### Step 1: Decompose Scope to Module Level

Group video topics into thematic modules (Level 2 WBS).

**Process:**

1. **Review Series Scope Statement:**
   - Identify major topic areas from in-scope list
   - Review series learning objectives (high-level outcomes)
   - Check series structure planning if available

2. **Identify Natural Groupings:**
   - Topics that share common theme or learning objective
   - Topics with strong prerequisite relationships
   - Topics at similar complexity level
   - Topics that build on each other

3. **Apply Bloom's Taxonomy:**
   - Early modules focus on Remember/Understand
   - Middle modules focus on Apply/Analyze
   - Later modules focus on Evaluate/Create
   - Ensure progression across series

4. **Create Module Descriptions:**
   - Module name (descriptive, thematic)
   - Module focus (2-3 sentence description)
   - Module learning objective (what students achieve by module completion)
   - Number of videos in module
   - Estimated module duration

**Example Module Decomposition:**

Series: GitHub Fundamentals for Teams

Module 1.1: Getting Started (Foundation)
- Focus: Basic concepts and account setup
- Videos: 3 (Introduction to Version Control, Account Setup, First Repository)
- Learning Objective: Create and manage basic GitHub repository

Module 1.2: Team Collaboration (Foundation → Intermediate)
- Focus: Working with others effectively
- Videos: 2 (Issues and Pull Requests, Branching Strategies)
- Learning Objective: Collaborate with team using GitHub workflows

Module 1.3: Advanced Tools (Intermediate, Premium)
- Focus: Professional workflows and automation
- Videos: 3 (Project Boards and Wikis, GitHub Actions, Complete Case Study)
- Learning Objective: Implement professional team workflows with automation

**Validation:**
- All series scope topics assigned to a module
- Modules follow logical learning progression
- Module count manageable (typically 2-5 per series)
- Each module has clear theme and outcome

### Step 2: Outline Individual Videos

Create detailed outline for each video within modules.

**Process:**

1. **Review Video Scope Statement:**
   - Learning objectives (what students will be able to do)
   - In-scope topics (what to cover)
   - Out-of-scope topics (what to avoid)
   - Target duration

2. **Apply Standard Video Structure:**
   - Use standard video outline template
   - Allocate time to each section based on content complexity
   - Balance explanation, demonstration, and practice

3. **Decompose Topics to Sections:**
   - Each major in-scope topic becomes video section (Level 4)
   - Order sections by logical learning flow
   - Ensure prerequisite topics covered before dependent topics

4. **Detail Section Content:**
   - Break each section into concept explanation + demonstration
   - Identify specific steps for demonstrations
   - Note screen recording requirements
   - Plan visual aids or diagrams

5. **Design Practice Exercise:**
   - Create exercise that applies section concepts
   - Ensure exercise achievable with content covered
   - Provide appropriate scaffolding for audience level
   - Define clear success criteria

6. **Estimate Timing:**
   - Allocate minutes to each section
   - Sum to verify within target duration range
   - Adjust if outside range (cut content or split video)

**Output:** Detailed video outline ready for script writing

### Step 3: Create Content Hierarchy

Build complete hierarchical view of series content structure.

**Deliverable-Based View (WBS Format):**

```
1.0 GitHub Fundamentals for Teams Series
  1.1 Getting Started Module
    1.1.1 Introduction to Version Control Video
      1.1.1.1 Why Version Control Matters Section
        - Real-world scenario without version control
        - Benefits of version control
        - Git vs GitHub explained
      1.1.1.2 Common Use Cases Section
        - Software development
        - Documentation management
        - Team collaboration scenarios
      1.1.1.3 Practice: Identify Use Cases
        - Exercise description
        - Success criteria
    1.1.2 Account Setup & Navigation Video
      [Similar decomposition]
    1.1.3 Your First Repository Video
      [Similar decomposition]
  1.2 Team Collaboration Module
    1.2.1 Collaboration Basics Video
      [Similar decomposition]
    1.2.2 Branching Strategies Video
      [Similar decomposition]
  1.3 Advanced Tools Module
    [Similar decomposition]
```

**Topic-Based View (Outline Format):**

```markdown
# GitHub Fundamentals for Teams - Complete Content Hierarchy

## Module 1: Getting Started

### Video 1: Introduction to Version Control (12-15 min)
#### Introduction (2 min)
- Hook: Team collaboration disaster story
- Context: Why version control essential for teams
- Preview: Three major sections

#### Why Version Control Matters (4 min)
- Real-world scenario without version control
  - Lost work and overwritten files
  - Confusion about latest version
  - Inability to revert mistakes
- Benefits of version control
  - Track all changes over time
  - Collaborate without conflicts
  - Revert to any previous state
- Git vs GitHub distinction
  - Git = version control system (software)
  - GitHub = hosting service + collaboration features

#### Common Use Cases (4 min)
- Software development (primary use case)
- Documentation management
- Team collaboration on any text files
- Educational projects and assignments

#### Practice Exercise (3 min)
- Identify version control needs in own work
- Evaluate current file management approach
- Success: List 2-3 scenarios where version control helpful

#### Conclusion (2 min)
- Summary of key benefits
- Preview: Next video sets up GitHub account
- Call to action: Think about current project needs

### Video 2: Account Setup & Navigation (15-18 min)
[Detailed outline structure]

### Video 3: Your First Repository (18-22 min)
[Detailed outline structure]

## Module 2: Team Collaboration
[Detailed outline structure]

## Module 3: Advanced Tools
[Detailed outline structure]
```

**Benefits of Hierarchical Structure:**
- Clear overview of entire series content
- Easy identification of gaps or redundancies
- Validation of logical flow across videos
- Foundation for dependency mapping
- Reference during script writing

### Step 4: Map Prerequisites and Dependencies

Identify and document prerequisite relationships between content elements.

**Dependency Types:**

**Hard Prerequisites:**
- Concept B cannot be understood without concept A
- Demonstration requires knowledge from previous video
- Tool or account setup needed before usage demonstration
- Terminology must be defined before use

**Soft Prerequisites:**
- Concept B easier to understand with concept A background
- Example builds on familiar scenario from earlier
- Related skill transfer makes learning smoother
- Reinforcement of earlier concept

**Process:**

1. **Identify Dependencies:**
   - For each video, list required prior knowledge
   - For each section, note concepts used but not defined
   - Flag terminology, tools, or techniques assumed known

2. **Validate Coverage:**
   - Confirm prerequisites covered in earlier content
   - Check timing (prerequisite must come before)
   - Verify sufficient depth (prerequisite taught adequately)

3. **Create Dependency Diagram (Complex Series):**
   - Visual map showing prerequisite relationships
   - Identify potential bottlenecks or sequential chains
   - Look for opportunities to parallelize independent topics

4. **Document in Outline:**
   - List prerequisites at video level
   - Note prerequisite sections within video outline
   - Flag external prerequisites (non-series content)

**Example Dependency Mapping:**

```
GitHub Fundamentals Series Dependencies:

Video 1: Introduction to Version Control
├─ Prerequisites: None (series entry point)
└─ Required for: All subsequent videos

Video 2: Account Setup & Navigation
├─ Prerequisites: Video 1 (understand why need account)
└─ Required for: Video 3, 4, 5, 6, 7, 8 (all require account)

Video 3: Your First Repository
├─ Prerequisites: Video 1, 2 (account and concepts)
└─ Required for: Video 4, 5 (work with repositories)

Video 4: Issues and Pull Requests
├─ Prerequisites: Video 1, 2, 3 (need repository to practice)
└─ Required for: Video 5, 6 (collaboration workflows)

Video 5: Branching Strategies
├─ Prerequisites: Video 4 (understand pull requests first)
└─ Required for: Video 6, 8 (advanced workflows use branches)

Video 6: Project Boards & Wikis
├─ Prerequisites: Video 3, 4 (repository and issue concepts)
└─ Required for: Video 8 (complete workflow example)

Video 7: GitHub Actions
├─ Prerequisites: Video 3 (repository structure)
├─ Soft prerequisite: Video 5 (often triggered by branches)
└─ Required for: Video 8 (complete workflow includes automation)

Video 8: Complete Workflow Case Study
├─ Prerequisites: All previous videos
└─ Synthesizes entire series
```

**Validation Questions:**
- Can student understand video N without having watched video N-1?
- Are all concepts used in demonstrations already explained?
- Is terminology defined before use?
- Are external prerequisites clearly stated?

### Step 5: Balance Content Distribution

Adjust content allocation across videos to optimize learning and engagement.

**Evaluation Criteria:**

**Duration Balance:**
- Check each video against target duration range
- Identify videos significantly over or under target
- Look for imbalance (e.g., all long videos clustered together)

**Complexity Balance:**
- Rate each video's complexity (1-5 scale)
- Avoid clustering all complex content together
- Intersperse challenging with reinforcement videos

**Bloom's Taxonomy Balance:**
- Map each video to primary Bloom's level
- Ensure progression across series
- Verify foundation videos don't jump to Evaluate/Create

**Topic Granularity Balance:**
- Check each video focuses on cohesive topic
- Identify videos trying to cover too much
- Look for videos with insufficient content

**Rebalancing Actions:**

**If Video Too Long:**
1. Review scope - is out-of-scope content included?
2. Check depth - going too deep for audience level?
3. Split into two videos if covering distinct topics
4. Move less critical content to documentation
5. Reduce example count (keep best examples)

**If Video Too Short:**
1. Review scope - missing in-scope content?
2. Check depth - insufficient explanation or practice?
3. Combine with closely related video
4. Add more examples or practice opportunities
5. Expand demonstrations with step-by-step details

**If Complexity Unbalanced:**
1. Move some complex topics to later in series
2. Add simpler reinforcement videos between challenges
3. Break complex videos into multi-part series
4. Add scaffolding to make complex content more accessible

**Output:** Balanced content distribution optimizing learning and production

### Step 6: Validate Outline Against Requirements

Verify outline satisfies stakeholder requirements and scope definition.

**Validation Checklist:**

**Scope Coverage:**
- [ ] All in-scope topics from scope statement covered
- [ ] No out-of-scope topics included
- [ ] Learning objectives from scope achievable with outline
- [ ] Video count matches series planning

**Stakeholder Needs:**
- [ ] Content depth appropriate for target audience level
- [ ] Practice opportunities meet stakeholder requirements
- [ ] Duration targets align with stakeholder time constraints
- [ ] Prerequisites clearly documented for students

**Quality Standards:**
- [ ] Each video has clear, specific learning objective
- [ ] Logical progression across series (no jumps in complexity)
- [ ] Consistent outline structure across all videos
- [ ] Prerequisites covered before dependent topics

**Production Feasibility:**
- [ ] Total series duration matches planned timeline
- [ ] Video durations realistic for production constraints
- [ ] Resource requirements identified (screen recordings, demos, examples)
- [ ] No unrealistic complexity in demonstrations

**Validation Process:**
1. Review outline against scope statement (point by point)
2. Walk through series as student (does flow make sense?)
3. Check prerequisites (can each video be understood?)
4. Verify balance (duration, complexity, topic distribution)
5. Get peer review (fresh perspective on completeness and flow)

**Output:** Validated outline ready for script development or refinement

## Content Outlining Best Practices

### Start Broad, Refine to Specific

Begin with high-level structure, progressively add detail.

**Iteration Sequence:**
1. **Series Level:** Major modules and themes
2. **Module Level:** Individual video topics and order
3. **Video Level:** Main sections and flow within video
4. **Section Level:** Specific content points and demonstrations
5. **Detail Level:** Exact steps, examples, and timing

**Benefits:**
- Easier to see overall structure and balance early
- Flexibility to adjust before investing in detailed outlining
- Clear progression prevents getting lost in details
- Validation possible at each level before drilling down

### Use Visual Hierarchy Markers

Consistent heading levels and formatting improve readability and navigation.

**Markdown Hierarchy:**
```markdown
# Series Level (H1)
## Module Level (H2)
### Video Level (H3)
#### Section Level (H4)
##### Content Point Level (H5)
###### Notes Level (H6)
```

**Indentation for WBS:**
```
1.0 Series
  1.1 Module
    1.1.1 Video
      1.1.1.1 Section
        - Content point
        - Content point
```

**Visual Cues:**
- Bold for emphasis on key concepts
- Italics for instructional notes (not student-facing)
- Code blocks for technical content
- Block quotes for examples or scenarios
- Bullet lists for parallel items
- Numbered lists for sequential steps

### Build Template Library

Create reusable outline templates for common content patterns.

**Common Patterns:**

**Introduction Video Template:**
- Problem/pain point (hook)
- Solution overview (what tool/technique does)
- Benefits and use cases
- Course structure preview
- First hands-on exercise

**Concept Explanation Template:**
- Definition and terminology
- Why it matters
- How it works (conceptual model)
- Common examples
- Practice application

**Tool Demonstration Template:**
- Tool purpose and when to use
- Setup/access instructions
- Step-by-step demonstration (simple use case)
- Common options or variations
- Practice with provided example

**Comparison Video Template:**
- Options or approaches to compare
- Evaluation criteria
- Side-by-side comparison
- Recommendation guidelines (when to use each)
- Practice making choice for scenario

**Workflow Video Template:**
- Workflow overview (start to finish)
- Prerequisites and setup
- Step-by-step with decision points
- Error handling and recovery
- Complete example walkthrough
- Practice full workflow

### Incorporate Engagement Elements

Plan engagement strategies directly into outline structure.

**Engagement Techniques:**

**Pattern Interrupts:**
- Change pace every 5-7 minutes
- Alternate explanation with demonstration
- Use visual aids to break up talking head
- Pose questions for mental engagement
- Include brief exercises or checkpoints

**Active Learning Prompts:**
- "Pause the video and try this yourself"
- "Before I show you the answer, what do you think will happen?"
- "Can you think of a scenario where you'd use this?"
- "Take a moment to reflect on how this applies to your work"

**Reinforcement Strategies:**
- Recap key point at end of each section
- Preview-do-review structure within sections
- Reference earlier concepts to strengthen connections
- Summarize learning objectives achievement in conclusion

**Community Engagement:**
- "Share your results in the comments"
- "What challenges did you face? Let us know below"
- "Upload your project to show the community"
- "What would you like to learn next? Vote in the poll"

**Note in Outline:**
Mark engagement elements with [ENGAGEMENT] or similar tag to ensure not overlooked during script writing.

## Outline Formats and Use Cases

### WBS Dictionary Format

Detailed specifications for each WBS element.

**Use Case:** Formal documentation, project planning, team communication

**Structure:**
```
WBS ID: 1.1.1
WBS Name: Introduction to Version Control
WBS Level: 3 (Video)
Parent: 1.1 Getting Started Module

Description:
First video in series introducing version control concepts for complete beginners. Explains why version control matters, distinguishes Git from GitHub, and provides real-world use cases. No technical prerequisites required.

Deliverables:
- 12-15 minute instructional video
- Video script
- Supporting documentation
- Practice exercise worksheet

Success Criteria:
- Students can explain purpose of version control
- Students can distinguish Git from GitHub
- Students can identify scenarios where version control beneficial

Effort Estimate:
- Script writing: 4 hours
- Recording: 2 hours
- Editing: 3 hours
- Documentation: 2 hours
- Total: 11 hours

Dependencies:
- None (series entry point)

Required Resources:
- Screen recording software
- Example scenarios prepared
- Visual aids (diagrams for Git vs GitHub)
```

### Hierarchical Outline Format

Nested structure showing content organization.

**Use Case:** Script writing reference, content organization visualization

**Structure:**
```markdown
# Series: GitHub Fundamentals for Teams

## Module 1: Getting Started

### Video 1: Introduction to Version Control (12-15 min)

#### Introduction (2 min)
- Hook: Team collaboration disaster story
- Context: Why version control essential
- Preview: Three major sections

#### Section 1: Why Version Control Matters (4 min)
- Scenario without version control
  - Lost work example
  - Version confusion example
  - Cannot revert example
- Benefits of version control
  - Track all changes
  - Collaborate safely
  - Revert capabilities
- Git vs GitHub distinction
  - Git = software
  - GitHub = service + features

#### Section 2: Common Use Cases (4 min)
[Content details]

#### Practice Exercise (3 min)
[Exercise details]

#### Conclusion (2 min)
[Closing details]
```

### Linear Script Outline Format

Sequential flow for script writing.

**Use Case:** Direct script development, teleprompter preparation

**Structure:**
```markdown
# Video: Introduction to Version Control

## Script Outline

[0:00-0:30] HOOK - Show scenario of team conflict over file versions

[0:30-1:00] PROBLEM STATEMENT
- "Have you ever worked on a document with a team..."
- "Or lost important work because you saved over the wrong file..."
- Problem resonance with audience

[1:00-2:00] INTRODUCTION
- Today we solve this problem with version control
- By end of video, you'll understand three things: [list]
- Let's start with why this matters

[2:00-4:00] SECTION 1: Real scenario without version control
- [Screen recording: Show messy file names]
- "Final_v2_FINAL_actually_final.docx" - we've all been there
- Walk through problems that arise
- Connect to their experience

[4:00-6:00] SECTION 1: Benefits of version control
- [Screen recording: Show GitHub history]
- Track all changes automatically
- See who changed what and when
- Revert to any previous version
- Demonstrate each benefit

[6:00-7:00] SECTION 1: Git vs GitHub
- [Visual: Venn diagram]
- Git = the software (version control system)
- GitHub = the website (hosting + collaboration)
- Analogy: Git is Word, GitHub is Google Docs

[And so on...]
```

### Timing Breakdown Format

Detailed time allocation for production planning.

**Use Case:** Production scheduling, duration validation

**Structure:**
```markdown
# Video: Introduction to Version Control
Target Duration: 12-15 minutes
Actual Script Duration: 13:30 ✓

## Timing Breakdown

| Section | Start | End | Duration | Content |
|---------|-------|-----|----------|---------|
| Hook | 0:00 | 0:30 | 0:30 | Team conflict scenario |
| Problem | 0:30 | 1:00 | 0:30 | Pain points |
| Introduction | 1:00 | 2:00 | 1:00 | Preview and objectives |
| Section 1a | 2:00 | 4:00 | 2:00 | Without version control |
| Section 1b | 4:00 | 6:00 | 2:00 | Benefits of version control |
| Section 1c | 6:00 | 7:30 | 1:30 | Git vs GitHub |
| Section 2 | 7:30 | 10:30 | 3:00 | Common use cases |
| Practice | 10:30 | 13:00 | 2:30 | Exercise and guidance |
| Conclusion | 13:00 | 13:30 | 0:30 | Summary and next steps |

## Section Analysis
- Introduction: 2:00 (14.8% of video) ✓ Target: 10-15%
- Main Content: 8:30 (63.0% of video) ✓ Target: 65-75%
- Practice: 2:30 (18.5% of video) ✓ Target: 15-20%
- Conclusion: 0:30 (3.7% of video) ⚠ Target: 10-15% (consider expanding)
```

## Outlining Tools and Techniques

### Mind Mapping

Visual brainstorming technique for initial content organization.

**When to Use:**
- Beginning of outlining process
- Brainstorming related topics
- Identifying connections between concepts
- Before creating formal hierarchy

**Process:**
1. Put series name in center
2. Branch to major modules
3. Branch to individual videos
4. Add topic connections
5. Identify natural groupings
6. Transform to hierarchical outline

**Tools:** Paper and pen, Miro, MindMeister, Lucidchart

### Dependency Diagrams

Visual representation of prerequisite relationships.

**When to Use:**
- Complex series with many interdependencies
- Validating prerequisite coverage
- Communicating content relationships to team
- Planning production order

**Elements:**
- Boxes = videos or topics
- Arrows = prerequisite relationships
- Colors = complexity levels or modules
- Numbers = suggested viewing order

**Example Notation:**
```
[Video 1] → [Video 2] → [Video 5]
         → [Video 3] → [Video 5]
         → [Video 4] → [Video 6]
```

### Content Spreadsheets

Tabular format for tracking multiple dimensions of content.

**When to Use:**
- Balancing multiple factors (duration, complexity, level)
- Production planning and resource allocation
- Progress tracking during production
- Validating coverage of requirements

**Column Examples:**
- WBS ID
- Video Title
- Module
- Learning Objectives
- Prerequisites
- Target Duration
- Estimated Duration
- Complexity (1-5)
- Bloom's Level
- Production Status
- Assigned To
- Due Date

**Benefits:**
- Easy sorting and filtering
- Quantitative analysis (total duration, complexity distribution)
- Progress visualization
- Resource allocation

### Template-Based Outlining

Use standardized templates for consistent structure.

**Benefits:**
- Faster outlining process
- Consistent quality across videos
- Reduced cognitive load
- Easier validation and review
- Better student experience (predictable structure)

**Template Library Examples:**
- Introduction video template
- Concept explanation template
- Tool demonstration template
- Comparison video template
- Workflow video template
- Case study template
- Challenge/project video template

**Customization:**
- Templates provide starting structure
- Adapt to specific content needs
- Remove unnecessary sections
- Add domain-specific sections
- Maintain core structure for consistency

## Validation and Quality Assurance

### Outline Review Checklist

Systematic validation before script writing begins.

**Completeness:**
- [ ] All scope requirements represented
- [ ] Learning objectives specific and measurable
- [ ] Prerequisites clearly identified
- [ ] Practice exercises defined
- [ ] Production notes included

**Logical Flow:**
- [ ] Natural progression from simple to complex
- [ ] Prerequisites covered before dependent topics
- [ ] No circular dependencies
- [ ] Smooth transitions between sections
- [ ] Coherent narrative arc

**Balance:**
- [ ] Video durations within target ranges
- [ ] Complexity distributed across series
- [ ] Appropriate depth for audience level
- [ ] Mix of explanation, demonstration, practice
- [ ] Engagement elements incorporated

**Consistency:**
- [ ] Consistent outline structure across videos
- [ ] Terminology usage consistent
- [ ] Similar content patterns for similar content types
- [ ] Heading hierarchy follows standards

**Feasibility:**
- [ ] Demonstrations achievable in allocated time
- [ ] Examples realistic and practical
- [ ] Resource requirements identified
- [ ] Production schedule realistic

### Peer Review Process

Get feedback from others before investing in script development.

**Reviewers:**
- Subject matter experts (technical accuracy)
- Target audience representatives (clarity and relevance)
- Fellow instructors (pedagogical soundness)
- Project stakeholders (alignment with goals)

**Review Focus Areas:**
- Content coverage and accuracy
- Learning progression and flow
- Appropriate depth and complexity
- Clear and achievable learning objectives
- Practical and relevant examples

**Review Format:**
- Share complete series outline
- Provide context (scope, audience, goals)
- Request specific feedback areas
- Set review deadline
- Incorporate feedback systematically

### Student Testing

Validate outline with representative students before full production.

**Methods:**
- **Outline Walkthrough:** Present outline to student focus group, gauge reaction
- **Pilot Video:** Create one video from outline, gather detailed feedback
- **Concept Validation:** Test whether outline structure makes sense to target audience

**Feedback Questions:**
- Does the progression make sense?
- Are prerequisites clear and appropriate?
- Is content balance appropriate (theory vs practice)?
- Are learning objectives compelling and relevant?
- Would you watch this series based on outline?

**Iteration:**
- Incorporate feedback into outline
- Re-validate major changes
- Document rationale for decisions
- Update outline based on learning

## Common Outlining Pitfalls

### Pitfall 1: Too Much Detail Too Soon

**Problem:** Getting bogged down in section-level details before validating high-level structure.

**Prevention:**
- Start with series/module structure
- Validate overall flow before drilling down
- Use iterative refinement (broad to specific)
- Save detailed timing for script phase

### Pitfall 2: Insufficient Content Hierarchy

**Problem:** Flat outlines without clear hierarchical organization make navigation difficult.

**Prevention:**
- Use consistent heading levels
- Follow WBS hierarchical principles
- Maintain 3-5 levels (Series → Module → Video → Section → Point)
- Use visual hierarchy markers (indentation, numbering)

### Pitfall 3: Missing Prerequisites

**Problem:** Content assumes knowledge not yet covered, breaking learning flow.

**Prevention:**
- Explicitly map all dependencies
- Validate prerequisites covered before use
- Check terminology definitions before use
- Get fresh-eyes review from someone unfamiliar with topic

### Pitfall 4: Unbalanced Content Distribution

**Problem:** Some videos packed with content while others thin, or all complex videos clustered.

**Prevention:**
- Track video durations in outline
- Rate and distribute complexity
- Balance explanation with demonstration
- Review distribution visually (chart or spreadsheet)

### Pitfall 5: Scope Creep in Outline

**Problem:** Adding topics not in defined scope during outlining.

**Prevention:**
- Reference scope statement constantly
- Maintain "future content" list for good ideas outside scope
- Validate outline against scope before script development
- Get scope approval if outline reveals necessary additions

## Success Indicators

Effective content outlining produces:
- Clear hierarchical structure from series to content points
- Logical flow with appropriate learning progression
- Balanced content distribution across videos
- Complete coverage of scope requirements
- Well-documented prerequisites and dependencies
- Consistent structure enabling efficient script development
- Validated outline approved by stakeholders and SMEs
- Realistic production planning and resource allocation

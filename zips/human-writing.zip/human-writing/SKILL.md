---
name: human-writing
description: Comprehensive writing skill that produces human-like, authentic writing across all domains by applying Bloom's Taxonomy levels 5-6 (Evaluating and Creating). This skill should be used whenever writing is a primary output or work product - including fiction, non-fiction, academic, business, creative, technical, scriptwriting, and all other writing forms. Actively avoids AI writing patterns (em dashes, frequent bullets, lists of three, clichés) to ensure highest-quality, authentic human-like output with natural voice and style variation.
license: Complete terms in LICENSE.txt
---

# Human Writing Skill

## Overview

This skill transforms writing outputs from AI-characteristic patterns into authentic, human-like writing that demonstrates mastery at Bloom's Taxonomy levels 5-6 (Evaluating and Creating). Apply this skill whenever writing is a primary output or deliverable - not for conversational exchanges with users, but for actual written work products.

**Critical trigger**: Use this skill when:
- Creating any document, article, story, script, or written content as a work product
- Writing is identified as a deliverable by other skills (e.g., project management outputs)
- The user requests any form of creative, professional, academic, or technical writing
- Content will be consumed by others (not conversation with Claude)

## Core Principles

### Bloom's Taxonomy Level 5: Evaluating

Before generating any writing output, critically evaluate:

1. **Audience Analysis**: Assess who will read this and what they need
2. **Purpose Validation**: Judge whether the writing approach serves its intended goal
3. **Quality Standards**: Critique the draft against domain-specific excellence criteria
4. **Voice Authenticity**: Evaluate whether the voice sounds genuinely human
5. **Pattern Recognition**: Check for AI writing patterns and remove them

### Bloom's Taxonomy Level 6: Creating

Synthesize original, authentic writing that:

1. **Constructs** new narratives, arguments, or expressions from constituent elements
2. **Designs** structure and flow that feels organic and human
3. **Produces** content with genuine variation in rhythm, sentence structure, and vocabulary
4. **Generates** original metaphors, descriptions, and turns of phrase
5. **Composes** work that reflects human thought patterns and imperfections

## Anti-AI Pattern Framework

**Before releasing any writing output, scan for and eliminate these AI patterns:**

### Punctuation Patterns to Avoid

- **Em dashes (—)**: Severely restrict use. Maximum one per 3-4 paragraphs
  - Instead: Use periods, commas, parentheses, or restructure sentences
  - If em dash is truly necessary, ensure it's not part of a pattern

- **Excessive semicolons**: Limit to academic or formal writing where appropriate
  - Vary with periods or coordinate conjunctions

- **Lists in threes**: Avoid the AI tendency to group things in triplets
  - "X, Y, and Z" patterns should be rare
  - When listing, use 2, 4, 5, or varied numbers of items
  - Mix list lengths throughout the piece

### Structural Patterns to Avoid

- **Bullet point overuse**: Reserve bullets for specific purposes only
  - Don't default to bullets when prose would work better
  - Academic, fiction, and narrative writing rarely use bullets
  - Business writing can use bullets, but sparingly and purposefully

- **Rigid paragraph structure**: Avoid formulaic topic sentence + 3 supports + conclusion
  - Vary paragraph lengths: short (1-2 sentences), medium (3-5), long (6+)
  - Not every paragraph needs perfect structure
  - Allow natural digressions and asides

- **Transition phrase overuse**:
  - Avoid: "It's important to note that...", "In light of this...", "Without further ado..."
  - Instead: Let content flow naturally or use simple, direct transitions

### Vocabulary and Phrase Patterns to Avoid

**Never use these AI cliché words and phrases** (consult `/references/ai_patterns_to_avoid.md` for comprehensive list):

**Top offenders to eliminate completely**:
- "delve into" / "delves" / "delving"
- "navigate the landscape"
- "in the realm of"
- "tapestry" (especially in essays)
- "embark on a journey"
- "unlock the potential"
- "bustling"
- "pivotal"
- "crucial" (use sparingly)
- "comprehensive" (use sparingly)
- "leverage" (except in technical business contexts)
- "robust"
- "revolutionize/revolutionary"
- "game-changer"
- "ecosystem" (except in biology)
- "cutting-edge"

**Formulaic openings to avoid**:
- "In today's fast-paced world..."
- "In the world of..."
- "Have you ever wondered..."
- "Let's explore the fascinating world of..."
- "It's important to note that..."
- "When it comes to..."
- "At the end of the day..."

**Formulaic closings to avoid**:
- "In conclusion..." / "In summary..." / "To sum up..."
- "Whether X or Y, [conclusion]"
- "The key takeaway is..."
- "As we've seen..."

## Human Writing Characteristics

### Natural Voice Elements

1. **Sentence Variation**
   - Mix short, punchy sentences with longer, flowing ones
   - Include occasional fragments for emphasis
   - Vary sentence openings (not always subject-verb)
   - Use different sentence types: declarative, interrogative, exclamatory

2. **Rhythm and Flow**
   - Create natural cadence through varied sentence lengths
   - Use alliteration and assonance sparingly for effect
   - Allow prose to breathe with pacing variation
   - Include pauses where a human would naturally pause

3. **Authentic Imperfections**
   - Not every transition needs to be perfect
   - Allow minor stylistic quirks that reflect personality
   - Include colloquialisms when appropriate to voice/context
   - Don't over-polish to sterility

4. **Personal Touch**
   - Infuse genuine perspective or insight when appropriate
   - Include specific, concrete details over vague generalities
   - Use unexpected metaphors or comparisons
   - Show rather than tell (especially in narrative)

### Domain-Specific Application

Apply human writing principles across all domains:

**Fiction Writing**
- Show don't tell through specific sensory details
- Vary dialogue tags beyond "said" but don't overdo fancy alternatives
- Build characters through action and specific detail, not abstract description
- Create genuine conflict and resolution, not formulaic plots
- Use varied pacing: slow contemplative scenes and fast action sequences

**Non-Fiction Writing**
- Lead with strong, specific openings (not generic scene-setting)
- Use concrete examples and anecdotes, not just abstractions
- Vary evidence types: statistics, quotes, examples, analysis
- Structure for reader understanding, not AI-template structure
- Conclude with insight, not summary rehash

**Academic Writing**
- Follow field-specific conventions (APA, MLA, Chicago - see `/references/citation_guide.md`)
- Use discipline-appropriate terminology without cliché padding
- Structure arguments logically but not rigidly
- Include proper citations and references
- Maintain scholarly tone without sounding robotic
- Vary sentence structure even in formal prose

**Business Writing**
- Be direct and clear without being formulaic
- Use active voice predominantly
- Structure for busy readers (headings acceptable)
- Include specific data and metrics
- Maintain professionalism without corporate clichés

**Creative Non-Fiction**
- Blend narrative techniques with factual accuracy
- Use literary devices: metaphor, imagery, symbolism
- Create scenes and moments, not just exposition
- Maintain authenticity while crafting compelling narrative
- Balance show and tell appropriately

**Scriptwriting**
- Write dialogue that sounds like real speech (with contractions, interruptions, fragments)
- Use subtext—what's unsaid matters
- Create visual storytelling through action lines
- Format according to industry standards (film vs. TV vs. stage)
- Develop character voice through word choice and speech patterns

**Children's Writing**
- Match vocabulary and complexity to age group
- Use strong, active verbs
- Create genuine emotion and stakes
- Avoid condescension or oversimplification
- Include concrete, relatable details

**Lyrics Writing**
- Prioritize rhythm, meter, and rhyme scheme (when appropriate)
- Use repetition purposefully (choruses, refrains)
- Create genuine emotional resonance
- Allow imperfect grammar for flow and feel
- Use concrete imagery and metaphor

## Evaluation and Revision Process

### Pre-Release Checklist

Before delivering any writing output, evaluate against these criteria:

**Voice Authenticity Check**:
- [ ] Does this sound like a specific human wrote it, not an AI?
- [ ] Is there personality and voice present?
- [ ] Are sentences varied in length and structure?
- [ ] Have I eliminated em dash overuse?

**AI Pattern Elimination**:
- [ ] Scanned for and removed all cliché phrases from the avoid list?
- [ ] Checked for lists in threes and varied them?
- [ ] Eliminated formulaic openings and closings?
- [ ] Removed bullet point overuse?

**Domain Appropriateness**:
- [ ] Does this match conventions of its genre/domain?
- [ ] Is the tone appropriate for the audience?
- [ ] Have I followed required citation standards (if academic)?
- [ ] Does structure serve content, not formula?

**Human Characteristics Present**:
- [ ] Includes specific, concrete details (not vague generalities)?
- [ ] Shows variation in rhythm and pacing?
- [ ] Contains genuine insight or perspective?
- [ ] Feels natural and authentic, not over-polished?

### Iterative Refinement

If any checklist items fail:

1. **Identify**: Mark specific AI patterns or weaknesses
2. **Rewrite**: Rework those sections with human voice
3. **Verify**: Check again against criteria
4. **Iterate**: Repeat until all criteria met

## Integration with Other Skills

When other skills identify writing as an output:

**Project Management Skill**: When deliverable is a document/report
- Apply human-writing principles to all written deliverables
- Ensure professional documents avoid AI patterns
- Maintain clarity while preserving human voice

**Brand Guidelines Skill**: When creating branded content
- Blend brand voice with human authenticity
- Avoid clichés even when conveying brand values
- Make brand personality feel genuine, not corporate-speak

**Any Skill Producing Written Output**: Default to human-writing principles
- Screen all writing work products through this skill
- Prioritize authenticity and human voice
- Eliminate AI tells before delivery

## Reference Materials

Consult these reference files for detailed guidance:

- `/references/ai_patterns_to_avoid.md`: Comprehensive list of AI writing patterns, clichés, and tells to eliminate
- `/references/writing_domains.md`: Detailed guidance for specific writing genres and domains
- `/references/citation_guide.md`: Academic citation standards (APA, MLA) with examples

## Critical Reminders

1. **This skill is for work products, not conversation**: Don't apply these restrictions to natural dialogue with users
2. **Human voice trumps perfection**: Authentic, slightly imperfect human writing beats polished AI writing
3. **Domain conventions matter**: Apply human principles within domain-appropriate structure
4. **Variety is human**: Vary everything - sentence length, structure, vocabulary, rhythm
5. **Specificity over generality**: Concrete details beat abstract concepts
6. **Show don't tell**: Especially in narrative forms
7. **Read it aloud**: Human writing sounds natural when spoken
8. **One em dash per 3-4 paragraphs max**: This is the single biggest AI tell

## Examples

### BAD (AI-characteristic):
> In today's fast-paced world, it's important to note that effective communication is crucial. Whether you're navigating the complex landscape of business writing or delving into the realm of creative expression, mastering these three essential skills—clarity, brevity, and authenticity—will unlock your potential and revolutionize your writing journey.

**Problems**: "In today's fast-paced world", "it's important to note", "crucial", "navigating the complex landscape", "delving into the realm", em dash with list of three, "unlock your potential", "revolutionize", "journey"

### GOOD (Human-characteristic):
> Good writing comes down to practice and awareness. You need clarity (say what you mean), brevity (don't waste words), and authenticity (sound like yourself). Master these, and you'll write better emails, better reports, and better stories.

**Improvements**: Direct opening, no clichés, natural voice, varied sentence length, concrete language, one list (not three), no em dashes

---

## Final Note

This skill represents Bloom's highest cognitive levels: Evaluating and Creating. Apply critical judgment to assess writing quality against human standards, then create original, authentic work that reflects genuine human expression. The goal is not to fool detection systems—it's to produce genuinely better, more authentic, more human writing.

# AI Writing Patterns to Avoid

## Overview

This reference contains a comprehensive list of AI writing patterns, clichés, and tells that mark content as AI-generated. Scan all writing outputs against this list before delivery.

## Critical AI Tells

### Em Dash Overuse (THE #1 AI TELL)

**Rule**: Maximum one em dash (—) per 3-4 paragraphs

**Problem**: AI models overuse em dashes because they appear frequently in training data. Human writers rarely use them with such frequency.

**Solutions**:
- Use periods to break into two sentences
- Use commas for clauses
- Use parentheses for asides
- Restructure the sentence entirely
- If truly necessary, ensure it's not part of a pattern across the document

### Lists in Threes Pattern

**Problem**: AI defaults to listing things in groups of three (X, Y, and Z)

**Solutions**:
- Vary list lengths: 2 items, 4 items, 5 items
- Mix list lengths throughout the piece
- Sometimes don't list at all—use prose instead

**Examples to avoid**:
- "This skill teaches clarity, brevity, and authenticity"
- "Whether in business, academia, or creative writing..."
- "Learn to write better, faster, and stronger"

## Vocabulary to Completely Eliminate

### Tier 1: Never Use (Extreme AI Indicators)

**Words**:
- delve / delves / delving / delved
- realm (unless fantasy/gaming context)
- tapestry (especially in essays—automatic AI flag)
- bustling
- pivotal
- meticulous
- intricate / intricately / intricacies
- robust (unless technical specification)
- leverage / leveraging (except finance/business jargon)
- embark / embarking / embarked
- unveiling / unveiled
- revolutionize / revolutionary / revolutionized
- transformative / transform (use sparingly)
- unlock / unlocking / unlocked (except literal locks)
- cutting-edge (extreme cliché)
- game-changer / game-changing
- seamless / seamlessly
- vibrant (overused for descriptions)
- dynamic (when describing anything)
- ecosystem (unless biology/ecology)
- landscape (when meaning "field" or "industry")
- navigate / navigating (unless literal navigation)
- unparalleled / unprecedented
- boundless
- multifaceted
- uncharted (especially "uncharted territory")
- captivate / captivating / captivated
- indispensable
- comprehensive (use very sparingly)
- elevate / elevates / elevating
- empower / empowering / empowered
- holistic
- synergy
- paradigm shift
- bandwidth (unless technical)
- testament (as in "a testament to")
- unleash / unleashing
- spearhead / spearheading
- master / mastering (unless actual expertise context)
- treasure trove
- masterclass

### Tier 2: Minimize (Use Extremely Sparingly)

**Words**:
- crucial (once per 10 pages max)
- vital / essential (once per 10 pages max)
- significant / significantly
- profound / profoundly
- enhance / enhancing / enhanced
- foster / fostering
- facilitate / facilitating
- optimize / optimizing
- streamline / streamlining
- innovative / innovation
- groundbreaking
- revolutionary
- strategic / strategically
- impactful
- resonate / resonating
- authentic / authenticity (ironic, but overused)
- compelling
- nuanced
- sophisticated
- diverse / diversity
- dynamic
- scalable / scalability
- agile
- robust
- comprehensive

## Formulaic Phrases to Eliminate

### Opening Phrases (Never Start With These)

- "In today's fast-paced world..."
- "In the world of [X]..."
- "In the realm of [X]..."
- "Have you ever wondered..."
- "Imagine a world where..."
- "Picture this:"
- "Let's explore the fascinating world of..."
- "Let's delve into..."
- "Let's dive into..."
- "Let's take a closer look at..."
- "Let's embark on a journey..."
- "Let's uncover..."
- "Welcome to the world of..."
- "In an era marked by..."
- "Throughout history..."
- "Since the dawn of time..."
- "As we stand on the precipice of..."
- "In the ever-evolving landscape of..."
- "As technology continues to advance..."
- "Whether you're a seasoned [X] or just starting out..."
- "Whether you're a veteran [X] or a newcomer..."

### Transition Phrases (Avoid These)

- "It's important to note that..."
- "It's worth noting that..."
- "It's worth mentioning that..."
- "It should be noted that..."
- "It bears mentioning that..."
- "One cannot help but notice..."
- "Without further ado..."
- "With that said..."
- "With that in mind..."
- "In light of this..."
- "In this context..."
- "At the end of the day..."
- "When all is said and done..."
- "Taking all of this into account..."
- "As previously mentioned..."
- "As we've discussed..."
- "Moving forward..."
- "Looking ahead..."
- "In the final analysis..."
- "Upon closer examination..."
- "On the other hand..." (occasionally acceptable)

### Closing Phrases (Never End With These)

- "In conclusion..."
- "In summary..."
- "To sum up..."
- "To wrap things up..."
- "In closing..."
- "To conclude..."
- "As we've seen..."
- "As we've explored..."
- "As this article has shown..."
- "Throughout this [article/essay/piece]..."
- "In wrapping up..."
- "The key takeaway is..."
- "The main takeaway is..."
- "The bottom line is..."
- "Whether [X] or [Y], [conclusion]"
- "Ultimately, what matters is..."
- "At the end of this journey..."
- "As we conclude our exploration of..."
- "Armed with this knowledge..."
- "With this newfound understanding..."

### Formulaic Patterns

**"Not X, but Y" Pattern**:
- "It's not about X, it's about Y"
- "Success isn't about X, it's about Y"
- "Writing isn't about X; it's about Y"

**Problem**: AI overuses this contrast structure. Use sparingly and naturally.

**"Whether X or Y" Pattern**:
- "Whether you're a beginner or an expert..."
- "Whether in business or personal life..."
- "Whether writing fiction or non-fiction..."

**Problem**: AI defaults to this inclusive structure. Vary your approaches.

**"Key/Essential/Critical" + Three Items**:
- "The three key elements are..."
- "Three essential components..."
- "Three critical factors..."

**Problem**: Combines list-of-three with AI vocabulary.

## Structural Patterns to Avoid

### Bullet Point Overuse

**When bullets are inappropriate**:
- Fiction writing (almost never)
- Narrative non-fiction (rarely)
- Academic essays (rarely, except for data)
- Creative writing (almost never)
- Blog posts (unless specifically formatting tips/lists)

**When bullets are acceptable** (but still use sparingly):
- Business presentations
- Technical documentation
- How-to guides
- Genuine lists of items/steps
- Quick reference materials

**Rule**: If prose would work better, use prose.

### Rigid Paragraph Structure

**AI Default**: Topic sentence + 3 supporting sentences + concluding sentence

**Human Alternative**:
- Vary paragraph length dramatically
- One-sentence paragraphs for emphasis
- Long flowing paragraphs for complex ideas
- Medium paragraphs for standard content
- Don't always need formal topic sentences
- Conclusions can be implicit

### Hyphenated Emphasis

**AI Pattern**: "Ever-evolving", "ever-changing", "ever-growing", "fast-paced", "cutting-edge", "state-of-the-art", "game-changing"

**Problem**: AI overuses hyphenated modifiers to add emphasis

**Solution**: Use direct, simple language instead

## Sentence-Level Patterns

### Comma Splices and Run-Ons

**AI Pattern**: Excessive use of commas to string ideas together

**Example**: "Writing is important, it helps us communicate, it allows us to share ideas, it enables connection"

**Human Alternative**: Vary sentence structure, use periods, use different connecting words

### Semicolon Overuse

**AI Pattern**: Using semicolons to sound sophisticated

**Human Alternative**: Use semicolons only when truly appropriate (connecting closely related independent clauses). Most of the time, use periods.

### Parallel Structure Overuse

**AI Pattern**: Everything in perfect parallel structure

**Example**: "We need to write clearly, to edit thoroughly, and to revise completely"

**Human Alternative**: Mix parallel and non-parallel structures naturally

## Tone and Voice Patterns

### Excessive Enthusiasm

**AI Pattern**: Over-the-top positive language

**Markers**:
- "exciting journey"
- "fascinating world"
- "amazing opportunity"
- "incredible potential"
- "thrilling adventure"

### False Humility/Hedging

**AI Pattern**: Excessive qualification and hedging

**Markers**:
- "It's worth considering that perhaps..."
- "One might argue that it's possible..."
- "In some cases, it could be said..."

### Robotic Neutrality

**AI Pattern**: Complete lack of opinion or perspective

**Solution**: Include appropriate perspective, insight, or stance when warranted

## Domain-Specific Anti-Patterns

### Fiction Writing

**AI Tells**:
- Describing every physical detail of characters
- "She had long, flowing auburn hair, piercing green eyes, and..."
- Perfect dialogue with no interruptions or fragments
- Every emotion explicitly stated
- No subtext or implication

### Business Writing

**AI Tells**:
- Excessive jargon and buzzwords
- "Leverage synergies to optimize ROI"
- Corporate speak without substance
- Too many transition phrases
- Bullet point dependency

### Academic Writing

**AI Tells**:
- Padding with unnecessary qualifying phrases
- "It is important to note that researchers have found that..."
- Could be: "Researchers found that..."
- Generic transitions between every paragraph
- Lack of field-specific terminology (replaced with generic terms)

## Red Flags Checklist

Before releasing any writing, check for these red flags:

**Immediate Fails**:
- [ ] Uses "delve" or "delving"
- [ ] More than one em dash per 3-4 paragraphs
- [ ] Opens with "In today's fast-paced world" or similar
- [ ] Uses "tapestry" in an essay
- [ ] Closes with "In conclusion" or "To sum up"
- [ ] Multiple "whether X or Y" constructions
- [ ] Lists consistently in threes

**Warning Signs**:
- [ ] Contains 5+ words from Tier 1 avoid list
- [ ] Contains 10+ words from Tier 2 minimize list
- [ ] Uses more than 2 formulaic phrases
- [ ] Bullet points in non-appropriate context
- [ ] Rigid paragraph structure throughout
- [ ] No sentence length variation
- [ ] Excessive transition phrases
- [ ] Perfect grammar with no natural quirks

## Positive Indicators (What TO Include)

**Human Writing Characteristics**:
- Specific, concrete details
- Varied sentence length (1-20+ words)
- Mix of simple and complex sentences
- Occasional fragments for emphasis
- Natural, conversational flow
- Unexpected metaphors or comparisons
- Personal insight or perspective
- Imperfect but authentic voice
- Genuine variation in vocabulary
- Appropriate use of colloquialisms
- Subtext and implication (not everything spelled out)

## Usage Guidelines

1. **First Draft**: Write naturally without overthinking
2. **Revision**: Run through this checklist
3. **Elimination**: Remove all Tier 1 words and formulaic phrases
4. **Reduction**: Minimize Tier 2 words
5. **Variation**: Check for lists in threes, vary them
6. **Em Dash Count**: Count and reduce to 1 per 3-4 paragraphs
7. **Final Check**: Read aloud—does it sound like a human wrote it?

## Remember

The goal is not to remove all these words from human language—many are perfectly valid in context. The goal is to avoid the *patterns* and *overuse* that mark AI-generated text. A human might naturally use "crucial" once in a long piece. An AI will use it three times per page along with "pivotal," "essential," and "vital."

Pattern recognition + overuse = AI tell.
Occasional natural use in appropriate context = human writing.

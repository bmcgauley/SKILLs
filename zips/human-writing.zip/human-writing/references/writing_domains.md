# Writing Domains and Genre-Specific Guidance

## Overview

This reference provides detailed guidance for applying human writing principles across all major writing domains, genres, and forms. Use this as a guide for domain-specific conventions, expectations, and best practices.

## Fiction Writing

### Literary Fiction

**Characteristics**:
- Character-driven over plot-driven
- Internal conflicts and psychological depth
- Literary language and symbolism
- Slower pacing, contemplative
- Ambiguous endings acceptable

**Human Writing Techniques**:
- Deep point of view with character's unique voice
- Subtext in dialogue
- Metaphors that reveal character psychology
- Varied pacing (slow introspection, sudden revelation)
- Complex sentence structures when appropriate
- Sensory details that matter to the character

**Avoid**:
- Explaining everything
- Generic descriptions
- Formulaic plot structures
- Rushed emotional development

### Genre Fiction (Mystery, Thriller, Romance, Fantasy, Sci-Fi)

**Characteristics**:
- Plot-driven with genre conventions
- Clear stakes and conflict
- Faster pacing generally
- Genre-specific tropes (used well)
- Satisfying resolution expected

**Human Writing Techniques**:
- Genre-appropriate voice and tone
- Balance description with action
- Believable character motivations
- Foreshadowing without being obvious
- Genre conventions without clichés
- Specific world-building details

**Mystery Specific**:
- Fair play clues
- Red herrings that make sense
- Detective/protagonist reasoning shown, not told
- Climax reveals that satisfy

**Romance Specific**:
- Emotional truth over melodrama
- Specific chemistry, not just attraction
- Internal and external conflicts
- Authentic relationship progression

**Fantasy/Sci-Fi Specific**:
- World-building through character interaction
- Unique magic/tech systems with rules
- Avoid info-dumping
- Make the fantastic feel real through specific details

### Short Stories

**Characteristics**:
- Single moment or unified effect
- Economy of language
- Strong opening and ending
- Every word must count
- Often focus on revelation or change

**Human Writing Techniques**:
- Start close to the climactic moment
- Imply backstory, don't explain
- Use concrete images over abstractions
- Leave room for reader interpretation
- Strong final image or line

### Flash Fiction

**Characteristics**:
- Extremely compressed (50-1000 words)
- Complete story in miniature
- Often twist or surprise
- Single scene or moment

**Human Writing Techniques**:
- Every word must serve multiple purposes
- Strong imagery
- Implication over explanation
- Powerful ending

### Children's Fiction

**Age-Appropriate Guidelines**:

**Picture Books (Ages 3-8)**:
- Simple, strong verbs
- Rhythmic language
- Repetition for learning
- Concrete, relatable concepts
- Word count: 500-1000 words
- Room for illustration

**Early Readers (Ages 5-9)**:
- Short sentences and chapters
- Simple vocabulary with occasional new words
- Clear cause and effect
- Relatable problems
- Positive resolution

**Middle Grade (Ages 8-12)**:
- Age-appropriate voice
- Coming-of-age themes
- Adventure and friendship
- Clear moral stakes
- Avoid excessive violence/romance
- Word count: 20,000-55,000 words

**Young Adult (Ages 12-18)**:
- Authentic teen voice
- Complex themes
- Higher stakes
- Romance appropriate
- More sophisticated language
- Word count: 50,000-80,000 words

**Universal Children's Writing Principles**:
- Respect young readers' intelligence
- Don't condescend or preach
- Genuine emotion
- Specific, concrete details
- Active protagonists
- Hope and empowerment

## Non-Fiction Writing

### Creative Non-Fiction / Memoir

**Characteristics**:
- True events with narrative techniques
- Literary language
- Scene construction
- Reflection and meaning-making
- Subjective truth and perspective

**Human Writing Techniques**:
- Show scenes, don't just tell
- Sensory details from memory
- Honest emotional truth
- Reflection balanced with action
- Specific moments over general summaries
- Voice that reflects personality

**Memoir vs. Autobiography**:
- Memoir: Focuses on specific period/theme
- Autobiography: Comprehensive life story
- Both require narrative arc and meaning

### Personal Essays

**Characteristics**:
- First-person perspective
- Personal experience tied to larger meaning
- Reflective and analytical
- Intimate voice
- Typically 1,000-5,000 words

**Human Writing Techniques**:
- Specific anecdote or moment
- Universal insight from personal experience
- Honest vulnerability
- Natural voice (like talking to a friend)
- Varied sentence rhythm
- Don't explain too much

### Journalism

**Types**:
- Hard news (objective, factual)
- Feature writing (narrative journalism)
- Opinion/Editorial (argumentative)
- Investigative (deep research)

**News Writing Principles**:
- Inverted pyramid structure (most important first)
- Active voice
- Short paragraphs
- Quotes from sources
- Objective tone
- Fact-based

**Feature Writing Principles**:
- Narrative opening (scene or anecdote)
- Human interest angle
- Descriptive language
- Balance showing and telling
- Still factual and researched

### Blog Writing

**Characteristics**:
- Conversational tone
- Scannable format
- SEO considerations (but don't sacrifice quality)
- Direct address to reader
- Practical or entertaining

**Human Writing Techniques**:
- Strong, specific headline
- Hook in first paragraph
- Short paragraphs (2-4 sentences)
- Subheadings for scannability
- Your authentic voice
- Personal examples or stories
- Clear takeaways
- Avoid forced keyword stuffing

### How-To / Instructional

**Characteristics**:
- Clear, logical steps
- Second person ("you")
- Action-oriented
- Helpful, not condescending

**Human Writing Techniques**:
- Start with what they'll achieve
- Number steps clearly
- Include why, not just how
- Anticipate problems
- Conversational without being cutesy
- Tips and variations
- Visual aids where helpful

## Academic Writing

### Research Papers

**Characteristics**:
- Thesis-driven argument
- Evidence-based claims
- Formal but clear language
- Proper citations (APA, MLA, Chicago)
- Structured sections

**Human Writing Techniques**:
- Clear, specific thesis statement
- Varied evidence types (studies, quotes, data)
- Logical argument flow
- Synthesize sources, don't just list
- Critical analysis, not just summary
- Vary sentence structure even in formal prose
- Strong topic sentences
- Transitions that show logical connections

**Avoid**:
- Padding with qualifying phrases
- Passive voice overuse
- Hiding behind sources (show your analysis)
- Formulaic five-paragraph structure (in longer papers)
- Generic transitions

### Literature Reviews

**Characteristics**:
- Synthesize existing research
- Identify gaps and trends
- Critical evaluation
- Organized thematically or chronologically

**Human Writing Techniques**:
- Compare and contrast sources
- Show development of ideas over time
- Identify consensus and disagreement
- Your critical perspective on the literature
- Clear organization with signposting

### Thesis / Dissertation

**Characteristics**:
- Original research
- Substantial length
- Formal structure (chapters)
- Significant contribution to field

**Human Writing Techniques**:
- Clear research question
- Methodology explained thoroughly
- Results presented clearly
- Discussion connects to existing research
- Implications and future research
- Maintain engagement despite length
- Varied chapter structures

### Scientific Writing

**Characteristics**:
- IMRAD structure (Introduction, Methods, Results, Discussion)
- Precise technical language
- Objective tone
- Data-driven

**Human Writing Techniques**:
- Clear hypothesis
- Detailed methodology (reproducible)
- Honest reporting of results
- Discussion that interprets significance
- Acknowledge limitations
- Simple, direct sentences
- Active voice where appropriate
- Avoid unnecessary jargon

## Business Writing

### Business Reports

**Characteristics**:
- Executive summary up front
- Data-driven recommendations
- Clear structure with headings
- Professional tone
- Actionable conclusions

**Human Writing Techniques**:
- Lead with key findings
- Use headings and subheadings
- Include relevant data and charts
- Be direct and specific
- Avoid corporate jargon padding
- Active voice
- Numbered recommendations
- Clear next steps

### Business Proposals

**Characteristics**:
- Problem-solution structure
- Value proposition
- Cost-benefit analysis
- Call to action

**Human Writing Techniques**:
- Understand audience's pain points
- Specific solutions, not vague promises
- Concrete benefits and ROI
- Professional without being stuffy
- Confidence without arrogance
- Address potential objections
- Clear pricing and timeline

### Email Writing

**Characteristics**:
- Brief and scannable
- Clear subject line
- Action-oriented
- Professional tone appropriate to relationship

**Human Writing Techniques**:
- Descriptive subject line
- State purpose in first sentence
- Short paragraphs
- Bullet points only when truly needed
- Clear call to action
- Professional sign-off
- Proofread carefully

### White Papers

**Characteristics**:
- Educational content
- Problem-solution format
- Research-backed
- Position organization as expert

**Human Writing Techniques**:
- Compelling title
- Executive summary
- Clear problem definition
- Evidence-based solutions
- Case studies or examples
- Avoid hard selling
- Data and statistics
- Conclusion with next steps

## Creative Writing Forms

### Poetry

**Forms**:
- Free verse (no formal structure)
- Form poetry (sonnet, haiku, villanelle, etc.)
- Prose poetry (paragraph form)
- Slam/spoken word (performance)

**Human Writing Techniques**:
- Concrete imagery over abstractions
- Economy of language
- Line breaks that matter
- Sound devices (alliteration, assonance, internal rhyme)
- Varied rhythm and pacing
- Meaning layered, not obvious
- Unexpected metaphors
- White space as tool
- Show emotion through image, not statement

**Avoid**:
- Generic greeting card sentiment
- Forced rhymes
- Abstract emotion-words without grounding
- Explaining the metaphor
- Clichéd imagery

### Scriptwriting - Film

**Format**:
- Industry-standard format (Courier 12pt)
- Scene headings (INT./EXT., LOCATION, TIME)
- Action lines
- Character name (centered above dialogue)
- Dialogue
- Parentheticals (sparingly)

**Human Writing Techniques**:
- Visual storytelling (show, don't tell)
- Efficient action lines
- Character voice in dialogue
- Subtext (what's not said)
- Natural speech patterns (contractions, interruptions)
- Each scene advances plot or character
- Conflict on every page
- Strong visual openings
- Avoid camera directions unless essential

### Scriptwriting - Television

**Differences from Film**:
- Series format (episodic, serialized, or hybrid)
- Act breaks for commercials (traditional TV)
- Established character voices
- Season-long arcs
- Episode-specific and season-specific plots

**Human Writing Techniques**:
- Match established show tone
- Strong act-break cliffhangers
- Balance A, B, and C plots
- Character development within structure
- Maintain series continuity

### Scriptwriting - Stage/Theater

**Characteristics**:
- Limited locations
- Dialogue-driven
- Live performance considerations
- Stage directions minimal

**Human Writing Techniques**:
- Theatrical language (can be heightened)
- Monologues and soliloquies
- Entrances and exits matter
- Sound and lighting cues
- Character relationships through dialogue
- Build to theatrical moments

### Scriptwriting - Podcast

**Characteristics**:
- Audio-only medium
- Intimate, conversational
- Sound design integration
- Various formats (interview, narrative, hybrid)

**Human Writing Techniques**:
- Natural, conversational tone
- Sound cues and music notation
- Pacing for audio comprehension
- Character voices distinguish easily
- Read aloud as you write
- Consider music and sound effects
- Host voice and personality

## Technical Writing

### User Manuals

**Characteristics**:
- Task-oriented
- Clear, numbered steps
- Screenshots and diagrams
- Troubleshooting sections

**Human Writing Techniques**:
- Start with overview
- Logical organization
- Consistent terminology
- Active voice
- Short sentences
- Avoid jargon or define it
- Test instructions yourself
- Anticipate user mistakes

### Technical Documentation

**Characteristics**:
- API documentation
- Software documentation
- Technical specifications
- Developer-focused

**Human Writing Techniques**:
- Clear structure with navigation
- Code examples
- Prerequisites stated upfront
- Expected outputs shown
- Version information
- Update logs
- Consistent formatting
- Searchable organization

### Standard Operating Procedures (SOPs)

**Characteristics**:
- Compliance-focused
- Step-by-step procedures
- Safety considerations
- Regulatory language

**Human Writing Techniques**:
- Numbered steps
- Clear, unambiguous language
- Visual aids where helpful
- Warning/caution/note conventions
- Version control
- Review and approval process
- Consistent formatting

## Marketing and Copywriting

### Sales Copy

**Characteristics**:
- Persuasive
- Benefits-focused
- Action-oriented
- Audience-specific

**Human Writing Techniques**:
- Know your target audience intimately
- Speak to specific pain points
- Show benefits, not just features
- Use social proof
- Create urgency (authentically)
- Clear call to action
- Conversational tone
- Tell stories
- Avoid hype and clichés

### Landing Pages

**Characteristics**:
- Single focus/conversion goal
- Scannable
- Value proposition clear immediately
- Trust signals

**Human Writing Techniques**:
- Headline hooks in 5 seconds
- Subheadline expands on value
- Short paragraphs
- Bullet benefits
- Social proof
- Clear CTA
- Address objections
- Mobile-friendly structure

### Email Marketing

**Characteristics**:
- Subject line crucial
- Preview text optimized
- Scannable
- Single clear CTA

**Human Writing Techniques**:
- Compelling, non-clickbait subject line
- Personalization (but not creepy)
- Value immediately
- Conversational tone
- One main message
- Clear benefit
- Obvious CTA
- Mobile responsive

### Social Media

**Platform-Specific**:
- Twitter/X: Concise, conversational, hashtags
- LinkedIn: Professional, thought leadership
- Instagram: Visual-first, hashtags, stories
- Facebook: Community, longer-form acceptable
- TikTok: Casual, authentic, entertaining

**Human Writing Techniques**:
- Platform-appropriate tone
- Authentic voice
- Engage, don't just broadcast
- Use platform features (polls, questions)
- Hashtags purposeful, not spammy
- Call to engagement
- Visual-text integration

## Lyrics Writing

### Song Structure

**Common Structures**:
- Verse-Chorus-Verse-Chorus-Bridge-Chorus
- AABA (Verse-Verse-Bridge-Verse)
- Verse-Pre-Chorus-Chorus
- Free form

**Human Writing Techniques**:
- Match lyrics to melody
- Repetition for memorability (chorus)
- Verse develops story/idea
- Bridge provides contrast
- Rhyme scheme serves song
- Conversational language (unless art song)
- Syllable count for rhythm
- Hard consonants for punch
- Open vowels for sustained notes
- Prosody (natural speech rhythm)

### Genre-Specific

**Pop**:
- Hook-driven
- Relatable themes
- Conversational language
- Memorable chorus
- Universal emotions

**Rock**:
- Attitude and energy
- Rebellious themes acceptable
- Can be more abstract
- Powerful imagery

**Country**:
- Storytelling
- Specific details
- Heartfelt emotion
- Often narrative

**Hip-Hop/Rap**:
- Wordplay and double meanings
- Rhythm and flow primary
- Cultural references
- Complex rhyme schemes
- Metaphor and simile
- Authenticity crucial

**Folk**:
- Story-focused
- Simple language
- Timeless themes
- Acoustic imagery

**R&B/Soul**:
- Emotional depth
- Vocal-focused phrasing
- Melisma consideration
- Love themes common

## Voice and Tone Considerations

### Formal vs. Informal

**Formal**:
- Academic papers
- Professional reports
- Legal documents
- Traditional journalism
- Technical manuals

**Informal**:
- Blog posts
- Social media
- Personal essays
- Casual emails
- Creative writing

**Middle Ground**:
- Business writing
- Marketing copy
- Feature journalism
- Educational content

### First, Second, or Third Person

**First Person ("I/We")**:
- Memoir
- Personal essays
- Blog posts
- Some creative non-fiction
- Opinion pieces

**Second Person ("You")**:
- How-to guides
- Marketing copy
- Self-help
- Direct address needed

**Third Person ("He/She/They")**:
- Fiction (most common)
- Academic writing
- Journalism
- Technical writing
- Business reports

### Active vs. Passive Voice

**Active Voice (Preferred)**:
- Subject performs action
- Clearer, stronger, more direct
- Use in most writing

**Passive Voice (Sometimes Appropriate)**:
- Focus on action recipient
- Actor unknown or unimportant
- Scientific writing (some contexts)
- Diplomatic business writing

## Cross-Domain Best Practices

### Universal Principles

1. **Know Your Audience**: Every domain requires understanding who reads it
2. **Serve the Purpose**: Form follows function
3. **Be Specific**: Concrete details beat vague abstractions
4. **Vary Rhythm**: Sentence length and structure variation
5. **Show and Tell**: Balance appropriately for domain
6. **Edit Ruthlessly**: First draft is never final draft
7. **Read in Your Domain**: Study great writing in your chosen form
8. **Write Regularly**: Practice builds skill
9. **Get Feedback**: Other readers catch what you miss
10. **Revise**: Good writing is rewriting

### Final Reminder

These are guidelines, not rigid rules. The best writing in any domain balances craft knowledge with authentic voice, domain conventions with original expression, and learned technique with intuitive flow. Study the masters in your chosen domain, but find your own voice within it.

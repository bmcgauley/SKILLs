# Academic Citation Guide: APA and MLA

## Overview

This reference provides comprehensive guidance for academic citations in APA (American Psychological Association) and MLA (Modern Language Association) formats—the two most common citation styles in academic writing.

## When to Use Citations

**Always cite when**:
- Quoting directly from a source
- Paraphrasing someone else's ideas
- Referring to specific data or statistics
- Discussing someone else's theory or argument
- Using images, charts, or figures from another source

**Even if**:
- You put it in your own words (paraphrasing still requires citation)
- It's common knowledge in your field (if it's not universally known, cite it)
- You found it online (all sources need citation)

## Plagiarism Avoidance

**Plagiarism includes**:
- Copying text without quotation marks and citation
- Paraphrasing too closely to original wording
- Not providing citation for paraphrased ideas
- Falsifying sources
- Self-plagiarism (reusing your own work without disclosure)

**How to avoid**:
- Take careful notes with source information
- Use quotation marks for all direct quotes
- Paraphrase thoroughly (change structure and wording)
- Always include citations
- Use plagiarism detection tools to check

---

## APA Style (7th Edition)

### General Guidelines

**Used in**: Psychology, Education, Social Sciences, Business, Nursing

**Key Features**:
- Author-date citation system
- In-text citations with author and year
- Reference list at end (not "Works Cited")
- Title page with running head
- Abstract (usually)
- Double-spaced throughout
- Times New Roman, 12pt (or similar)

### APA In-Text Citations

#### Basic Format

**Single author**:
```
(Smith, 2020)
```

**Two authors**:
```
(Smith & Jones, 2020)
```

**Three or more authors**:
```
(Smith et al., 2020)
```

**Corporate/group author (first citation)**:
```
(American Psychological Association [APA], 2020)
```

**Corporate/group author (subsequent citations)**:
```
(APA, 2020)
```

#### Direct Quotations

**Short quote (fewer than 40 words)**:
```
According to Smith (2020), "the results were significant" (p. 23).
```
Or:
```
The results "were significant" (Smith, 2020, p. 23).
```

**Long quote (40+ words)** - Block format:
```
Smith (2020) found the following:

     [Indent entire quote 0.5 inch, no quotation marks]
     The results indicated that the treatment was effective across 
     all age groups, with particularly strong outcomes in the 
     younger cohort. These findings suggest significant implications 
     for future research. (p. 45)
```

**Page numbers**:
- Required for direct quotes
- Use "p." for single page, "pp." for page range
- Example: (Smith, 2020, p. 45) or (Smith, 2020, pp. 45-47)

#### Paraphrasing

**Page numbers optional but encouraged for paraphrasing**:
```
Smith (2020) argued that the new method was more effective.
```
Or:
```
The new method proved more effective (Smith, 2020).
```

#### Special Cases

**No author**:
```
("Title of Article," 2020)
```

**No date**:
```
(Smith, n.d.)
```

**Multiple works by same author in same year**:
```
(Smith, 2020a, 2020b)
```

**Personal communication** (email, interview, etc.):
```
(J. Smith, personal communication, January 15, 2020)
```
*Note: Do not include in reference list*

**Secondary source** (citing something you read about):
```
As cited in Jones (2020)
```

### APA Reference List

**Location**: Separate page after main text, before appendices
**Title**: "References" (centered, bold)
**Order**: Alphabetical by author last name
**Spacing**: Double-spaced throughout
**Hanging indent**: First line flush left, subsequent lines indented 0.5 inch

#### Book References

**Single author**:
```
Smith, J. A. (2020). Title of book in sentence case. Publisher.
```

**Two authors**:
```
Smith, J. A., & Jones, B. C. (2020). Title of book. Publisher.
```

**Edited book**:
```
Smith, J. A. (Ed.). (2020). Title of book. Publisher.
```

**Book chapter in edited volume**:
```
Smith, J. A. (2020). Chapter title. In B. C. Jones (Ed.), Book 
     title (pp. 25-50). Publisher.
```

**eBook**:
```
Smith, J. A. (2020). Title of book. Publisher. https://doi.org/xxxxx
```

#### Journal Article References

**Print journal**:
```
Smith, J. A., & Jones, B. C. (2020). Article title in sentence case. 
     Journal Title in Title Case, 25(3), 123-145.
```

**Online journal with DOI**:
```
Smith, J. A., & Jones, B. C. (2020). Article title. Journal Title, 
     25(3), 123-145. https://doi.org/xxxxx
```

**Online journal without DOI**:
```
Smith, J. A., & Jones, B. C. (2020). Article title. Journal Title, 
     25(3), 123-145. https://www.journalwebsite.com
```

**Article in press**:
```
Smith, J. A. (in press). Article title. Journal Title.
```

#### Website References

**Webpage with author**:
```
Smith, J. A. (2020, January 15). Page title. Website Name. 
     https://www.example.com
```

**Webpage without author**:
```
Page title. (2020, January 15). Website Name. 
     https://www.example.com
```

**Website without date**:
```
Smith, J. A. (n.d.). Page title. Website Name. 
     https://www.example.com
```

#### Other Sources

**Newspaper article**:
```
Smith, J. A. (2020, January 15). Article title. Newspaper Name, 
     pp. A1, A4.
```

**Magazine article**:
```
Smith, J. A. (2020, January). Article title. Magazine Name, 25(3), 
     45-50.
```

**Dissertation/thesis**:
```
Smith, J. A. (2020). Dissertation title [Doctoral dissertation, 
     University Name]. Database Name.
```

**Conference paper**:
```
Smith, J. A. (2020, June). Paper title. In B. C. Jones (Chair), 
     Symposium title. Symposium conducted at the meeting of 
     Organization Name, Location.
```

**Film/video**:
```
Director, A. A. (Director). (2020). Film title [Film]. Studio.
```

**Podcast**:
```
Host, A. A. (Host). (2020, January 15). Episode title (No. 25) 
     [Audio podcast episode]. In Podcast name. Production Company. 
     https://www.example.com
```

---

## MLA Style (9th Edition)

### General Guidelines

**Used in**: Humanities, English, Literature, Arts

**Key Features**:
- Author-page citation system
- In-text citations with author and page number
- Works Cited page at end
- No title page (unless instructor requires)
- Header with last name and page number
- Double-spaced throughout
- Times New Roman, 12pt
- 1-inch margins

### MLA In-Text Citations

#### Basic Format

**Author named in sentence**:
```
Smith argues that "the method works" (23).
```

**Author named in parentheses**:
```
The method "works well in practice" (Smith 23).
```

**Two authors**:
```
(Smith and Jones 45)
```

**Three or more authors**:
```
(Smith et al. 67)
```

**Corporate author**:
```
(American Medical Association 89)
```

**No author**:
```
("Article Title" 12)
```

**Multiple works by same author** - include short title:
```
(Smith, First Book 23)
(Smith, "Article Title" 45)
```

#### Direct Quotations

**Short quote (fewer than 4 lines)**:
```
According to Smith, "the results were significant" (23).
```

**Long quote (4+ lines)** - Block format:
```
Smith makes the following observation:

     [Indent entire quote 0.5 inch, no quotation marks]
     The results indicated that the treatment was effective 
     across all groups. The implications are far-reaching and 
     suggest that future research should build on these findings. (45)
```

**Quote within a quote**:
```
Smith writes, "As Jones stated, 'the method works,' we can 
proceed" (23).
```

#### Special Cases

**Indirect source** (quoting something quoted in your source):
```
qtd. in Smith 23
```

**Multiple works in one citation**:
```
(Smith 23; Jones 45; Brown 67)
```

**Work without page numbers** (web page, etc.):
```
(Smith)
```
Or if paragraph numbers:
```
(Smith, par. 4)
```

**Entire work reference** (no page needed):
```
Smith's research demonstrates...
```

**Verse** (poem, play):
```
(lines 12-15) - first reference
(12-15) - subsequent references
```

### MLA Works Cited

**Location**: Separate page after main text
**Title**: "Works Cited" (centered, not bold or italicized)
**Order**: Alphabetical by author last name or title
**Spacing**: Double-spaced throughout
**Hanging indent**: First line flush left, subsequent lines indented 0.5 inch

#### MLA Core Elements (in order)

1. Author
2. Title of source
3. Title of container
4. Other contributors
5. Version
6. Number
7. Publisher
8. Publication date
9. Location (page numbers, DOI, URL)

#### Book Citations

**Single author**:
```
Smith, John A. Title of Book in Title Case. Publisher, 2020.
```

**Two authors**:
```
Smith, John A., and Barbara C. Jones. Title of Book. Publisher, 2020.
```

**Three or more authors**:
```
Smith, John A., et al. Title of Book. Publisher, 2020.
```

**Edited book**:
```
Smith, John A., editor. Title of Book. Publisher, 2020.
```

**Chapter in edited book**:
```
Smith, John A. "Chapter Title." Book Title, edited by Barbara C. 
     Jones, Publisher, 2020, pp. 25-50.
```

**eBook**:
```
Smith, John A. Title of Book. Publisher, 2020. Kindle.
```

**Translated book**:
```
Author, Name. Title. Translated by Translator Name, Publisher, 2020.
```

#### Journal Article Citations

**Print journal**:
```
Smith, John A., and Barbara C. Jones. "Article Title in Title Case." 
     Journal Title, vol. 25, no. 3, 2020, pp. 123-145.
```

**Online journal with DOI**:
```
Smith, John A. "Article Title." Journal Title, vol. 25, no. 3, 
     2020, pp. 123-145, doi:10.xxxx/xxxxx.
```

**Online journal without DOI**:
```
Smith, John A. "Article Title." Journal Title, vol. 25, no. 3, 
     2020, pp. 123-145, www.journalwebsite.com/article.
```

#### Website Citations

**Webpage with author**:
```
Smith, John A. "Page Title." Website Name, Publisher, 15 Jan. 2020, 
     www.example.com/page.
```

**Webpage without author**:
```
"Page Title." Website Name, Publisher, 15 Jan. 2020, 
     www.example.com/page.
```

**Webpage without date**:
```
Smith, John A. "Page Title." Website Name, Publisher, 
     www.example.com/page. Accessed 1 May 2021.
```
*Note: Access date only needed when no publication date*

#### Other Sources

**Newspaper article**:
```
Smith, John A. "Article Title." Newspaper Name, 15 Jan. 2020, 
     pp. A1+.
```

**Magazine article**:
```
Smith, John A. "Article Title." Magazine Name, Jan. 2020, pp. 45-50.
```

**Dissertation**:
```
Smith, John A. "Dissertation Title." 2020. University Name, PhD 
     dissertation.
```

**Conference paper**:
```
Smith, John A. "Paper Title." Conference Name, 15 Jan. 2020, 
     Location. Conference Presentation.
```

**Film**:
```
Title of Film. Directed by Director Name, Studio, 2020.
```

**TV episode**:
```
"Episode Title." Series Title, season 2, episode 5, Network, 
     15 Jan. 2020.
```

**Podcast**:
```
Host, Name. "Episode Title." Podcast Name, season 2, episode 5, 
     Production Company, 15 Jan. 2020, www.example.com.
```

**Social media post**:
```
@username. "First twenty words of the post..." Twitter, 15 Jan. 
     2020, www.twitter.com/username/status/xxxxx.
```

**Personal interview**:
```
Smith, John. Personal interview. 15 Jan. 2020.
```

---

## Quick Comparison: APA vs. MLA

| Feature | APA | MLA |
|---------|-----|-----|
| **In-text citation** | (Smith, 2020, p. 23) | (Smith 23) |
| **Works cited page** | References | Works Cited |
| **Date placement** | After author | At end |
| **Title capitalization** | Sentence case | Title Case |
| **Journal volume** | Vol(issue) | vol. no. |
| **Page abbreviation** | p. or pp. | p. or pp. or omit |
| **Website URLs** | https:// | www. or https:// |
| **DOI format** | https://doi.org/... | doi:... |
| **Multiple authors** | & | and |
| **Three+ authors** | et al. always | et al. in-text only |

## Additional Citation Tips

### General Best Practices

1. **Be consistent**: Choose APA or MLA and stick with it throughout
2. **Double-check**: Verify format against official style guide
3. **Use tools**: Citation managers (Zotero, Mendeley, EndNote) can help
4. **Update**: Citation styles change—use current edition
5. **When in doubt**: Include more information rather than less
6. **Alphabetize properly**: Letter by letter, ignore "A," "An," "The"
7. **Cite as you write**: Don't leave citations for the end
8. **Keep records**: Save all source information while researching

### Common Mistakes to Avoid

1. **Missing citations**: Always cite when using others' ideas
2. **Incorrect format**: Follow the style guide exactly
3. **Incomplete information**: Include all required elements
4. **Wrong punctuation**: Periods, commas matter in citations
5. **Inconsistent style**: Don't mix APA and MLA
6. **Forgetting page numbers**: Required for direct quotes
7. **URLs that don't work**: Test all URLs before submission
8. **Not alphabetizing**: Reference/Works Cited must be alphabetical

### Digital Object Identifiers (DOI)

**What it is**: Permanent identifier for digital objects, especially journals

**APA format**:
```
https://doi.org/10.1080/02626667.2018.1560449
```

**MLA format**:
```
doi:10.1080/02626667.2018.1560449
```

**When to use**: Include DOI when available (preferred over URL for articles)

**Where to find**: Usually on first page of article or journal website

### Hanging Indent

**What it is**: First line flush left, subsequent lines indented 0.5 inch

**How to format in Word**:
1. Highlight references
2. Right-click → Paragraph
3. Under "Indentation," select "Hanging" from Special dropdown
4. Set to 0.5"

**How to format in Google Docs**:
1. Highlight references
2. Format → Align & indent → Indentation options
3. Special indent: Hanging
4. Set to 0.5"

---

## Discipline-Specific Notes

### Sciences (often APA or CSE)
- Emphasize date (research recency matters)
- Include DOIs for electronic articles
- Abbreviate journal titles (sometimes)
- Use numeric or author-year systems

### Humanities (often MLA or Chicago)
- Emphasize author and title
- Full journal names (no abbreviation)
- Include more publication details
- Page numbers more important

### Social Sciences (often APA)
- Author-date prominent
- Quantitative data important
- Recent publication dates emphasized
- Secondary sources discouraged

---

## Remember

1. **Citation is not optional**: It's academic integrity
2. **When in doubt, cite**: Better to over-cite than plagiarize
3. **Check your assignment**: Professors may have specific requirements
4. **Keep learning**: Citation rules change and vary by context
5. **Use primary sources**: Whenever possible, cite the original work
6. **Cite all formats**: Books, articles, websites, videos, podcasts all need citation
7. **Different sections, different needs**: Methods may need fewer citations than literature review

## Resources

**Official Style Guides**:
- APA: https://apastyle.apa.org/
- MLA: https://style.mla.org/

**Citation Generators** (verify output):
- Zotero (free)
- Mendeley (free)
- EndNote (paid)
- Citation Machine (web-based)
- EasyBib (web-based)

**University Writing Centers**: Most universities offer citation help

**Remember**: Citation generators can make mistakes. Always verify against the official style guide.

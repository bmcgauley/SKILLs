---
name: stakeholder-analysis
description: Comprehensive stakeholder analysis skill for educational content development following PMI standards. This skill should be used when identifying stakeholders for educational projects, analyzing audience characteristics and needs, mapping requirements to stakeholder groups, or prioritizing features based on stakeholder value. Augments the project-management skill with specialized workflows for understanding and engaging educational content stakeholders.
license: Complete terms in LICENSE.txt
---

# Stakeholder Analysis for Educational Content

This skill provides comprehensive stakeholder analysis workflows specifically adapted for educational content development. It augments the project-management skill by applying PMI stakeholder engagement principles to the unique challenges of video-based learning platforms.

## Purpose

Educational content projects serve diverse stakeholder groups with varying needs, technical levels, and priorities. Success requires understanding who your stakeholders are, what they need, how to prioritize competing requirements, and how to engage each group effectively. This skill addresses these challenges through PMI-aligned stakeholder identification, analysis, and engagement planning adapted for educational content production.

## When to Use This Skill

**Primary Use Cases:**
- Identifying all stakeholder groups for educational content projects
- Analyzing target audience characteristics (technical level, learning goals, constraints)
- Mapping content requirements to stakeholder needs
- Prioritizing features and content based on stakeholder value
- Developing engagement strategies for different stakeholder groups
- Creating stakeholder registers and communication plans

**Integration with Project Management:**
- Works with project-management skill for stakeholder engagement processes
- Provides inputs to scope-management skill (stakeholder needs inform scope)
- Informs requirements elicitation and prioritization
- Guides communication planning and change management

## Core Stakeholder Analysis Workflows

### Workflow 1: Identify All Stakeholder Groups

Systematically discover individuals and groups affected by or affecting the educational content project.

**Process:**

1. **Brainstorm Stakeholder Categories:**
   - Who will consume the content? (learners, viewers, students)
   - Who will purchase the content? (individuals, businesses, organizations)
   - Who will create the content? (instructors, subject matter experts, production team)
   - Who will distribute the content? (platforms like YouTube, course marketplaces)
   - Who provides the tools taught? (technology vendors, platform providers)
   - Who sets standards? (regulatory bodies, professional associations)

2. **Use Predecessor Project Analysis:**
   - Review similar educational content projects
   - Identify stakeholders from those projects
   - Adapt to current project context
   - Interview creators of similar content

3. **Review Project Documentation:**
   - Examine project charter for mentioned stakeholders
   - Review market research for target audience descriptions
   - Analyze competition to understand their stakeholder focus
   - Check business model for revenue and value sources

4. **Consider Entire Lifecycle:**
   - Content creation phase stakeholders
   - Content distribution phase stakeholders
   - Content consumption phase stakeholders
   - Content maintenance and update phase stakeholders

**Output:** Comprehensive stakeholder list with initial categorization (Primary/Secondary/External)

**Reference:** See "Stakeholder Analysis Process > Step 1: Identify Stakeholders" in `/references/pmi_stakeholder_standards.md`

### Workflow 2: Analyze Stakeholder Characteristics

Gather detailed information about each stakeholder group's attributes, needs, and constraints.

**Data Collection Techniques:**

**1. Surveys:**
- Pre-launch surveys for potential students
- Market research on target audience demographics
- Competitor audience analysis surveys
- Business buyer needs assessment surveys

**2. Interviews:**
- One-on-one with representative stakeholders
- Focus groups with student cohorts
- Subject matter expert consultations
- Corporate training manager interviews

**3. Observation:**
- Analyze existing content engagement patterns
- Review course completion rate data
- Monitor forum discussions and common questions
- Track tool usage and adoption patterns

**4. Market Research:**
- Industry reports on educational technology trends
- Professional association demographics
- Job market data for target roles
- Competitive analysis of similar content

**Information to Gather:**

**For Students/Learners:**
- Current role and responsibilities
- Technical proficiency level (beginner/intermediate/advanced/expert)
- Learning goals (career advancement, skill acquisition, certification, problem-solving)
- Time availability for learning (weekly hours, scheduling flexibility)
- Budget constraints (personal vs. company-funded, price sensitivity)
- Learning style preferences (video, text, hands-on, interactive)
- Tool access and limitations (software restrictions, hardware capabilities)
- Motivation drivers and pain points
- Prior knowledge and prerequisites

**For Business Decision-Makers:**
- Organization size and industry
- Training budget and ROI requirements
- Number of employees to train (scale needs)
- Skills gap needing addressed (business problem)
- Timeline for skill development (urgency)
- Success metrics and reporting needs
- Existing training infrastructure and integration requirements
- Procurement process and approval requirements

**Output:** Detailed stakeholder profiles documented in stakeholder register

**Reference:** See "Stakeholder Analysis Process > Step 2: Analyze Stakeholder Characteristics" in `/references/pmi_stakeholder_standards.md`

### Workflow 3: Assess Power and Interest

Evaluate each stakeholder's power to affect project success and their level of interest in the outcome.

**Assessment Process:**

1. **Evaluate Power (1-5 scale):**
   - Decision-making authority (approve, veto, fund)
   - Budget control (direct access to resources)
   - Implementation authority (deploy, mandate usage)
   - Network influence (thought leaders, community influencers, social media reach)
   - Subject matter expertise (credibility, validation authority)

2. **Evaluate Interest (1-5 scale):**
   - Direct benefit from project success
   - Active participation willingness
   - Time commitment availability
   - Feedback responsiveness
   - Advocacy potential

3. **Create Power/Interest Grid:**
   - Plot each stakeholder group on grid (Power Y-axis, Interest X-axis)
   - Divide into four quadrants
   - Assign engagement strategy based on quadrant

**Power/Interest Quadrants:**

**High Power, High Interest → Manage Closely:**
- Most critical stakeholders
- Require active engagement and regular communication
- Example: Primary paying students, large corporate clients, key subject matter experts

**High Power, Low Interest → Keep Satisfied:**
- Influential but not deeply engaged
- Require efficient communication focused on their needs
- Example: Budget approvers, platform administrators, senior executives

**Low Power, High Interest → Keep Informed:**
- Engaged but limited influence
- Regular updates and community building
- Example: Free content viewers, community members, early adopters

**Low Power, Low Interest → Monitor:**
- Minimal engagement required
- Track for changes in power or interest
- Example: General public, passive observers, competitors

**Output:** Power/Interest Grid with stakeholder positioning and engagement strategy assignment

**Reference:** See "Stakeholder Analysis Process > Step 3: Assess Stakeholder Influence and Interest" and "Power/Interest Grid" in `/references/pmi_stakeholder_standards.md`

### Workflow 4: Identify and Prioritize Requirements

Elicit specific requirements from stakeholders and prioritize based on stakeholder power and project goals.

**Requirements Elicitation Process:**

1. **Gather Requirements by Technique:**
   - **Workshops:** Facilitated sessions with student representatives, corporate training requirements sessions
   - **Interviews:** Structured interviews with business decision-makers, semi-structured with student personas
   - **Prototyping:** Sample content and mockups with feedback gathering
   - **Questionnaires:** Learning objective priorities, tool preferences, price sensitivity surveys

2. **Categorize Requirements:**
   - **Functional:** What the content must do (teach specific skills, provide practice, offer certification)
   - **Non-Functional:** How the content must be (video quality, accessibility, platform compatibility)
   - **Business:** Project constraints (completion rate targets, pricing, timeline, differentiation)

3. **Trace Requirements to Source:**
   - Document which stakeholder group originated each requirement
   - Create requirements traceability matrix
   - Enable impact analysis when requirements conflict

4. **Prioritize Using MoSCoW:**
   - **Must Have:** Essential for project success, deal-breaker if missing
   - **Should Have:** Important but not critical, workarounds possible
   - **Could Have:** Nice-to-have, include if resources permit
   - **Won't Have:** Explicitly out of scope for this release

5. **Apply Value vs Effort Analysis:**
   - High Value, Low Effort → Quick wins, prioritize highly
   - High Value, High Effort → Strategic investments, plan carefully
   - Low Value, Low Effort → Fill-ins if resources available
   - Low Value, High Effort → Avoid or defer

6. **Weight by Stakeholder Power:**
   - Requirements from high-power stakeholders get higher priority
   - Balance competing requirements based on power/interest assessment
   - Justify priority decisions with stakeholder analysis

**Output:** Prioritized requirements list with traceability to stakeholder sources

**Reference:** See "Stakeholder Analysis Process > Steps 4-5" in `/references/pmi_stakeholder_standards.md`

### Workflow 5: Develop Engagement Strategies

Create specific engagement plans for each stakeholder group based on their power/interest classification.

**For Manage Closely Stakeholders (High Power, High Interest):**

**Strategy Focus:** Active partnership and regular engagement
**Communication Approach:**
- Frequent, detailed communication
- Multiple channels (email, platform notifications, community forums, direct support)
- Proactive outreach for feedback and input
- Transparent roadmap and decision-making

**Engagement Activities:**
- Beta testing new content (early access)
- Student showcase opportunities (share what they've built)
- Regular feedback surveys (course quality, topic requests)
- Challenge events and community activities
- Office hours or Q&A sessions
- Rapid response to issues and questions

**Example: Primary Paying Students**
- Weekly email during active learning (new content, tips, progress encouragement)
- In-platform notifications for relevant updates
- Active community forum moderation and participation
- Monthly feedback surveys
- Immediate support for technical issues

**For Keep Satisfied Stakeholders (High Power, Low Interest):**

**Strategy Focus:** Efficient communication on their key concerns
**Communication Approach:**
- Less frequent but highly relevant communication
- Focus on outcomes and metrics important to them
- Executive-level summaries, not detailed updates
- Formal reporting when required

**Engagement Activities:**
- Monthly or quarterly business reviews (corporate clients)
- ROI reports and success metrics
- Streamlined decision-making processes
- Dedicated account management (for large accounts)
- Issue escalation paths

**Example: Corporate Training Decision-Makers**
- Monthly usage and completion reports
- Quarterly business reviews for large accounts
- ROI and productivity impact documentation
- Immediate escalation for critical issues

**For Keep Informed Stakeholders (Low Power, High Interest):**

**Strategy Focus:** Community building and value demonstration
**Communication Approach:**
- Regular updates through scalable channels
- Community-oriented communication
- Clear upgrade path messaging
- Appreciation and recognition

**Engagement Activities:**
- Consistent publishing schedule (builds trust)
- Community forums and discussions
- Social media engagement
- Newsletter opt-in for deeper engagement
- Polls and feedback opportunities
- Recognition for contributions

**Example: Free Content Viewers on YouTube**
- Weekly video releases
- Daily comment responses (first 24-48 hours)
- Community posts and polls
- Bi-weekly newsletter option
- Showcase viewer questions and projects

**For Monitor Stakeholders (Low Power, Low Interest):**

**Strategy Focus:** Minimal engagement, track for changes
**Communication Approach:**
- General public communications only
- No proactive outreach
- Monitor for power or interest changes

**Output:** Stakeholder engagement plan with communication channels, frequency, key messages, and activities for each stakeholder group

**Reference:** See "Stakeholder Engagement Strategies" in `/references/pmi_stakeholder_standards.md`

### Workflow 6: Create Stakeholder Register

Document all stakeholder analysis information in a comprehensive stakeholder register.

**Stakeholder Register Components:**

For each stakeholder group, document:

1. **Identification Information:**
   - Stakeholder group name
   - Type (Primary/Secondary/External)
   - Category (Students/Business Decision-Makers/Content Creators/etc.)
   - Representative count or size
   - How identified

2. **Characteristics:**
   - Technical level
   - Current role/organization
   - Learning goals (for students) or business goals (for decision-makers)
   - Budget constraints and pricing sensitivity
   - Time availability
   - Tool access and limitations
   - Motivation drivers
   - Pain points and challenges

3. **Influence Assessment:**
   - Power level (1-5 rating)
   - Sources of power
   - Interest level (1-5 rating)
   - Drivers of interest
   - Power/Interest classification

4. **Requirements:**
   - Functional requirements (Must/Should/Could/Won't Have)
   - Non-functional requirements
   - Business requirements
   - Priority rationale

5. **Engagement Strategy:**
   - Approach (Manage Closely/Keep Satisfied/Keep Informed/Monitor)
   - Communication channels
   - Communication frequency
   - Key messages
   - Engagement activities

6. **Risks and Mitigation:**
   - Potential negative impacts from stakeholder
   - Mitigation strategies

**Output:** Complete stakeholder register serving as central reference document

**Template:** See "Stakeholder Register Template" in `/references/pmi_stakeholder_standards.md`

**Reference:** For complete example, see Example 1 in `/references/stakeholder_examples.md` (AI Education Platform stakeholder register)

### Workflow 7: Validate and Iterate Stakeholder Analysis

Stakeholder analysis is not one-time activity. Validate assumptions and iterate throughout project lifecycle.

**Validation Process:**

1. **Initial Validation (Before Production):**
   - Review stakeholder analysis with project team
   - Validate characteristics through pilot surveys or interviews
   - Test engagement strategies with small group
   - Confirm requirements prioritization aligns with business goals

2. **Ongoing Validation (During Production):**
   - Monitor stakeholder engagement metrics (response rates, satisfaction, feedback quality)
   - Track requirement changes and new requirements
   - Assess engagement strategy effectiveness
   - Identify new stakeholder groups that emerge

3. **Post-Launch Validation:**
   - Evaluate stakeholder satisfaction through surveys
   - Analyze actual vs. expected engagement patterns
   - Assess power/interest accuracy based on behavior
   - Document lessons learned for future projects

**Iteration Triggers:**

Conduct stakeholder analysis update when:
- Significant scope changes announced
- New stakeholder groups discovered
- Changes in stakeholder power or interest observed
- Major feedback indicates misaligned requirements
- Market shifts affect audience needs
- Phase transitions in project (e.g., creation to maintenance)

**Update Process:**
1. Review current stakeholder register for accuracy
2. Reassess power and interest levels
3. Update requirements based on new information
4. Adjust engagement strategies based on effectiveness
5. Communicate changes to project team
6. Document rationale for updates

**Output:** Updated stakeholder register reflecting current understanding

## Stakeholder Analysis for Different Content Levels

Content targeting different technical levels requires understanding distinct stakeholder characteristics.

### Foundation Level Stakeholders

**Typical Characteristics:**
- No prior knowledge of topic
- May be intimidated by technical content
- Need extensive guidance and examples
- Higher likelihood of giving up if confused
- Seeking confidence as much as competence

**Requirements Implications:**
- Extremely clear, jargon-free explanations
- Step-by-step instructions with screenshots
- Frequent practice and feedback opportunities
- Encouragement and confidence building
- Simple before complex, practical before abstract

**Engagement Needs:**
- Patient, responsive support for "basic" questions
- Non-judgmental community atmosphere
- Celebration of progress and wins
- Clear prerequisites and what-to-expect messaging

### Intermediate Level Stakeholders

**Typical Characteristics:**
- Completed foundation content or have equivalent experience
- Comfortable with basic concepts and terminology
- Seeking to build on foundation with complex scenarios
- Can connect concepts with guidance
- Want learning efficiency (less hand-holding)

**Requirements Implications:**
- Build on foundation without re-teaching basics
- Multi-step workflows and integration examples
- "Why" in addition to "how"
- Comparison of approaches and trade-offs
- Challenging practice with real-world application

**Engagement Needs:**
- More sophisticated community discussions
- Peer learning and collaboration opportunities
- Clear advancement path to expert level

### Advanced Level Stakeholders

**Typical Characteristics:**
- Solid intermediate mastery
- Seeking optimization and edge cases
- Want architectural understanding
- Focus on decision-making rationale
- Can adapt patterns to specific contexts

**Requirements Implications:**
- Optimization techniques and performance
- Edge case handling and error recovery
- System design and architecture patterns
- Trade-off analysis and decision frameworks
- Production considerations (security, scale, reliability)

**Engagement Needs:**
- High-level technical discussions and debates
- Opportunity to share own experiences and approaches
- Advanced challenges and real-world scenarios
- Peer review and collaboration

### Expert Level Stakeholders

**Typical Characteristics:**
- Advanced proficiency in domain
- Building custom solutions and tools
- Interested in underlying principles and protocols
- Contributing back to community
- Innovating beyond standard patterns

**Requirements Implications:**
- Design principles and protocol specifications
- Building from scratch (not just using existing tools)
- Production at scale (performance, security, monitoring)
- Extensibility and customization patterns
- Integration with complex ecosystems

**Engagement Needs:**
- Peer collaboration and knowledge sharing
- Platform for showcasing innovations
- Direct access to instructor/expert for deep technical discourse
- Contribution opportunities (content, tools, community leadership)

## Common Stakeholder Analysis Pitfalls

### Pitfall 1: Incomplete Stakeholder Identification

**Problem:** Missing stakeholder groups leads to unmet requirements and engagement gaps.

**Prevention:**
- Use multiple identification techniques (brainstorming, predecessor analysis, documentation review)
- Consider entire project lifecycle (creation, distribution, consumption, maintenance)
- Review with diverse team members for different perspectives
- Validate stakeholder list with subject matter experts

**Reference:** See "Common Scope Pitfalls" in `/references/pmi_stakeholder_standards.md`

### Pitfall 2: Superficial Characteristics Analysis

**Problem:** Insufficient understanding of stakeholder needs and constraints leads to poor requirements and engagement strategies.

**Prevention:**
- Invest time in multiple data collection techniques (surveys, interviews, observation)
- Gather both quantitative data (technical level, budget) and qualitative insights (motivations, pain points)
- Create detailed stakeholder profiles, not just demographic summaries
- Validate assumptions through pilot testing or prototype feedback

### Pitfall 3: Treating All Stakeholders Equally

**Problem:** Resource exhaustion from attempting to manage all stakeholders closely; critical stakeholders may be under-served.

**Prevention:**
- Rigorously apply power/interest assessment
- Use grid to assign clear engagement strategies
- Focus resources on Manage Closely stakeholders
- Use efficient communication for lower-priority groups
- Regularly reassess as power/interest may change

### Pitfall 4: Static Stakeholder Analysis

**Problem:** Stakeholder needs, power, and interest change over time; outdated analysis leads to misaligned engagement.

**Prevention:**
- Schedule regular stakeholder analysis reviews (quarterly minimum)
- Monitor engagement metrics for changes in behavior
- Establish clear triggers for stakeholder analysis updates
- Maintain living stakeholder register, not point-in-time snapshot
- Document and communicate changes to project team

### Pitfall 5: Requirements Without Traceability

**Problem:** Cannot justify scope or priority decisions; stakeholder needs may be overlooked.

**Prevention:**
- Create and maintain requirements traceability matrix
- Document source stakeholder for every requirement
- Link requirements to power/interest assessment for priority justification
- Review traceability during scope and priority discussions

## Integration with Other Skills

**Scope Management Skill:**
- Stakeholder characteristics determine appropriate content depth (Foundation vs. Expert)
- Stakeholder requirements drive scope definition (in-scope and out-of-scope topics)
- Power/interest analysis informs feature prioritization
- Target audience definition comes from stakeholder analysis

**Project Management Skill:**
- Stakeholder analysis provides input to project charter (stakeholder identification)
- Engagement strategies inform communication planning
- Requirements prioritization aligns with project goals
- Stakeholder satisfaction metrics inform project success criteria

**Human Writing Skill:**
- Audience characteristics guide tone and language level
- Stakeholder learning goals inform content structure and examples
- Communication preferences affect documentation style

**Technical Documentation Skill:**
- Stakeholder technical level determines documentation depth and detail
- Learning goals guide example selection and practice exercises
- Support needs inform FAQ and troubleshooting content

## Quick Reference

### When Starting Project
1. Read `/references/pmi_stakeholder_standards.md` section "Stakeholder Analysis Process"
2. Identify all stakeholder groups (brainstorm, predecessor analysis, documentation review)
3. For each group, gather characteristics (technical level, goals, constraints)
4. Assess power and interest, create Power/Interest Grid
5. Elicit and prioritize requirements from stakeholders

### When Creating Content
1. Reference stakeholder profiles for target audience characteristics
2. Ensure content depth matches stakeholder technical level
3. Validate learning objectives align with stakeholder goals
4. Check requirements traceability (are stakeholder needs being met?)

### During Production
1. Monitor stakeholder engagement metrics
2. Gather ongoing feedback through surveys and support interactions
3. Track requirement changes
4. Adjust engagement strategies based on effectiveness

### After Launch
1. Evaluate stakeholder satisfaction
2. Analyze engagement pattern accuracy
3. Identify new stakeholder groups
4. Update stakeholder register and engagement strategies
5. Document lessons learned

## Examples

For detailed stakeholder analysis examples from the AI Education Platform project, see `/references/stakeholder_examples.md`:
- Example 1: Complete stakeholder register with all primary and secondary stakeholders
- Power/Interest Grid visualization
- Requirements traceability matrix
- Stakeholder engagement calendar
- Lessons learned from stakeholder analysis

## References

**Bundled References:**
- `/references/pmi_stakeholder_standards.md` - Complete PMI stakeholder analysis standards adapted for educational content
- `/references/stakeholder_examples.md` - Real-world stakeholder analysis from AI Education Platform project

**PMI Sources:**
- PMBOK Guide Seventh Edition - Stakeholder Performance Domain
- Requirements Management: A Practice Guide - Stakeholder identification and requirements elicitation
- Practice Standard for Work Breakdown Structures - Stakeholder inputs to scope definition

## Success Indicators

Effective stakeholder analysis produces:
- Comprehensive stakeholder identification (no surprise groups discovered late)
- Well-documented stakeholder characteristics and needs
- Clear requirements traceability to source stakeholders
- Appropriate engagement strategies for each stakeholder group
- High stakeholder satisfaction with relevance and value
- Efficient resource allocation focused on high-priority stakeholders
- Minimal scope changes due to missed requirements
- Strong adoption and engagement from target stakeholders
- Smooth project execution with aligned expectations

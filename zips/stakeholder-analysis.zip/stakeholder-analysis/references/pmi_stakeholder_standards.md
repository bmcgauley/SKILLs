# PMI Stakeholder Analysis Standards

## Overview

Stakeholder analysis identifies individuals and groups affected by or affecting the project, analyzes their characteristics and needs, and develops strategies for effective engagement. For educational content projects, stakeholders include students, business decision-makers, collaborators, and the broader community.

**Source:** Requirements Management: A Practice Guide; PMBOK Guide Seventh Edition - Stakeholder Performance Domain

## Core Stakeholder Analysis Principles

### 1. Identify All Stakeholder Groups

Comprehensive stakeholder identification prevents missed requirements and engagement gaps.

**For Educational Content Projects:**

**Primary Stakeholders:**
- **Students/Learners:** Direct consumers of educational content
- **Business Decision-Makers:** Purchasers of training for their organizations
- **Content Creators:** Instructors, subject matter experts, production team
- **Academic Partners:** Collaborating professors or institutions

**Secondary Stakeholders:**
- **Platform Users:** YouTube viewers, free content consumers
- **Technical Community:** Advanced users who may contribute feedback
- **Competitors:** Other course creators in same space
- **Technology Providers:** Tool vendors whose products are taught

**External Stakeholders:**
- **Regulatory Bodies:** Educational standards organizations (if applicable)
- **Industry Groups:** Professional associations (e.g., PMI for project management content)
- **Marketing Channels:** Platforms used to reach audience

### 2. Analyze Stakeholder Characteristics

Understanding stakeholder characteristics enables effective communication and requirement elicitation.

**Key Characteristics to Analyze:**

**Technical Level:**
- Current knowledge and skills
- Learning style preferences
- Technical vocabulary comprehension
- Comfort with technology and tools

**Needs and Expectations:**
- What problems are they trying to solve?
- What outcomes do they seek?
- What success looks like to them
- What constraints do they face?

**Influence and Power:**
- Decision-making authority
- Budget control
- Ability to affect project success
- Network and reach

**Interest and Engagement:**
- Level of interest in project outcome
- Willingness to participate
- Time availability for feedback
- Responsiveness to communication

**Communication Preferences:**
- Preferred communication channels
- Frequency of updates desired
- Level of detail needed
- Formal vs informal communication

### 3. Prioritize Stakeholders

Not all stakeholders have equal impact on project success. Prioritization enables efficient resource allocation.

**Prioritization Framework:**

**Power/Interest Grid:**

| High Power, High Interest | High Power, Low Interest |
|--------------------------|-------------------------|
| MANAGE CLOSELY | KEEP SATISFIED |
| Key decision-makers, primary students | Budget approvers, platform administrators |

| Low Power, High Interest | Low Power, Low Interest |
|-------------------------|------------------------|
| KEEP INFORMED | MONITOR |
| Free content viewers, community members | General public, passive observers |

**For Educational Content:**
- Primary students (paying customers) → Manage Closely
- Business decision-makers (purchasers) → Manage Closely or Keep Satisfied
- Free content viewers → Keep Informed
- Subject matter experts → Manage Closely (during creation)
- Technical community → Keep Informed or Monitor

### 4. Map Requirements to Stakeholders

Trace each requirement to its originating stakeholder group to ensure all needs are addressed.

**Requirements Mapping:**
- Learning objectives ← Students' skill development needs
- Content depth ← Students' technical level
- Video duration ← Students' attention span and schedule constraints
- Pricing structure ← Business decision-makers' budget constraints
- Tool selection ← Students' existing tools and willingness to adopt new ones
- Documentation quality ← Students' need for reference materials
- Assessment methods ← Business decision-makers' need to verify skill acquisition

## Stakeholder Analysis Process

### Step 1: Identify Stakeholders

Systematically discover all individuals and groups affected by or affecting the project.

**Techniques:**

**1. Brainstorming:**
- List all groups who will use, benefit from, or be affected by educational content
- Consider entire content lifecycle: creation, distribution, consumption, application
- Include both obvious and non-obvious stakeholders

**2. Stakeholder Categories:**
- Who will consume the content? (learners, viewers)
- Who will purchase the content? (individuals, businesses)
- Who will create the content? (instructors, SMEs, production team)
- Who will distribute the content? (platforms, marketing channels)
- Who provides the tools taught? (technology vendors)
- Who sets standards? (regulatory, professional associations)

**3. Predecessor Project Analysis:**
- Review similar educational content projects
- Identify stakeholders from those projects
- Adapt to current project context

**4. Documentation Review:**
- Examine project charter for mentioned stakeholders
- Review market research for target audience descriptions
- Analyze competition to understand their stakeholder focus

**Output:** Comprehensive stakeholder list with initial categorization

### Step 2: Analyze Stakeholder Characteristics

Gather detailed information about each stakeholder group's attributes and needs.

**Data Collection Techniques:**

**1. Surveys:**
- Pre-launch surveys for potential students
- Existing audience surveys (if building on previous work)
- Business buyer surveys for corporate training needs

**2. Interviews:**
- One-on-one with representative stakeholders
- Focus groups with student cohorts
- Stakeholder representatives (e.g., department heads for corporate training)

**3. Observation:**
- Analyze current behavior (e.g., YouTube video engagement patterns)
- Review existing course completion rates
- Monitor forum discussions and questions

**4. Market Research:**
- Industry reports on educational technology trends
- Competitor analysis of their target audiences
- Professional association demographics

**Information to Gather:**

**For Students:**
- Current role and responsibilities
- Technical proficiency level (beginner, intermediate, advanced)
- Learning goals (career advancement, skill acquisition, certification)
- Time availability for learning
- Budget constraints
- Learning style preferences (video, text, hands-on)
- Tool access and limitations
- Motivation and pain points

**For Business Decision-Makers:**
- Organization size and industry
- Training budget and ROI requirements
- Number of employees to train
- Skills gap needing addressed
- Timeline for skill development
- Success metrics and reporting needs
- Existing training infrastructure

**Output:** Detailed stakeholder profiles with characteristics documented

### Step 3: Assess Stakeholder Influence and Interest

Evaluate each stakeholder's power to affect project success and their level of interest in the outcome.

**Assessment Criteria:**

**Power/Influence:**
- Decision-making authority (approve, veto, fund)
- Budget control (direct access to resources)
- Implementation authority (deploy, mandate usage)
- Network influence (thought leaders, community influencers)
- Subject matter expertise (credibility, validation)

**Interest:**
- Direct benefit from project success
- Active participation willingness
- Time commitment availability
- Feedback responsiveness
- Advocacy potential

**Scoring Method:**
Rate each stakeholder group on power (1-5) and interest (1-5)
- 5 = Very High
- 4 = High
- 3 = Medium
- 2 = Low
- 1 = Very Low

**Output:** Power/Interest grid with stakeholder positioning

### Step 4: Identify Stakeholder Requirements

Elicit specific requirements from each stakeholder group.

**Elicitation Techniques:**

**1. Requirements Workshops:**
- Facilitated sessions with student representatives
- Corporate training requirements gathering sessions
- Subject matter expert content review sessions

**2. Interviews:**
- Structured interviews with business decision-makers
- Semi-structured interviews with student personas
- Expert interviews for technical content validation

**3. Prototyping:**
- Create sample video content and gather feedback
- Test course platform mockups with potential students
- Pilot pricing models with market segments

**4. Questionnaires:**
- Learning objective priorities survey
- Tool and technology preferences survey
- Price sensitivity and willingness-to-pay survey

**Requirements Categories:**

**Functional Requirements (What the content must do):**
- Teach specific skills (e.g., "Students must be able to create GitHub repository")
- Provide practice opportunities
- Offer certification or credentials
- Include downloadable resources

**Non-Functional Requirements (How the content must be):**
- Video quality standards (resolution, audio clarity)
- Accessibility requirements (captions, transcripts)
- Platform compatibility (desktop, mobile, tablet)
- Response time for student support

**Business Requirements (Project constraints and objectives):**
- Completion rate targets
- Pricing constraints
- Production timeline
- Market differentiation needs

**Output:** Requirements list with traceability to source stakeholders

### Step 5: Prioritize Stakeholder Requirements

Not all requirements can be satisfied equally. Prioritization ensures most critical needs are met.

**Prioritization Criteria:**

**MoSCoW Method:**
- **Must Have:** Essential for project success, deal-breaker if missing
- **Should Have:** Important but not critical, workarounds possible
- **Could Have:** Nice-to-have, include if resources permit
- **Won't Have:** Explicitly out of scope for this release

**Value vs Effort Matrix:**
- **High Value, Low Effort** → Quick wins, prioritize highly
- **High Value, High Effort** → Strategic investments, plan carefully
- **Low Value, Low Effort** → Fill-ins if resources available
- **Low Value, High Effort** → Avoid or defer

**Stakeholder Power Weighting:**
- Requirements from high-power stakeholders get higher priority
- Balance high-power/low-interest stakeholders (keep satisfied)
- High-interest stakeholders get more communication even if lower power

**For Educational Content:**
1. **Must Have:**
   - Clear learning objectives
   - Accurate, tested content
   - Appropriate difficulty level for target audience
   - Core topics for skill development

2. **Should Have:**
   - Practice exercises and assessments
   - Supplemental documentation
   - Community forum or discussion
   - Certificate of completion

3. **Could Have:**
   - Advanced bonus content
   - Live Q&A sessions
   - Mobile app
   - Gamification features

4. **Won't Have (This Release):**
   - Content in multiple languages
   - Enterprise SSO integration
   - Custom branding for organizations
   - Live instructor-led sessions

**Output:** Prioritized requirements list aligned with stakeholder needs

## Stakeholder Engagement Strategies

### For Primary Students (High Power, High Interest)

**Engagement Approach: Manage Closely**

**Strategies:**
- Regular communication throughout content development and release
- Active feedback solicitation (surveys, beta testing, community forums)
- Responsive support (Q&A, technical help, content clarifications)
- Transparent roadmap sharing (what's coming, when)
- Early access opportunities (beta content, preview upcoming series)

**Communication Channels:**
- Email newsletters
- Community forums
- Social media engagement
- In-platform notifications
- Direct support tickets

**Frequency:**
- Weekly during active learning (progress updates, new content alerts)
- Bi-weekly during gaps between series
- Immediate for critical issues (content errors, platform issues)

### For Business Decision-Makers (High Power, Low/Medium Interest)

**Engagement Approach: Keep Satisfied**

**Strategies:**
- Focus on ROI and business outcomes
- Provide usage reports and completion metrics
- Case studies demonstrating skill application
- Streamlined purchase and deployment process
- Dedicated account management for enterprise customers

**Communication Channels:**
- Formal reports (quarterly or as requested)
- Executive briefings
- Business-focused content (white papers, ROI calculators)
- Direct sales/account manager contact

**Frequency:**
- Monthly summary reports
- Quarterly business reviews
- On-demand for specific inquiries

### For Free Content Viewers (Low Power, High Interest)

**Engagement Approach: Keep Informed**

**Strategies:**
- Consistent publishing schedule (builds trust and anticipation)
- Community building (comments, forums, social media)
- Clear upgrade path communication (benefits of premium content)
- Valuable free content (not just teasers, genuine value)
- Engagement incentives (polls, challenges, recognition)

**Communication Channels:**
- YouTube community posts
- Social media (Twitter, LinkedIn)
- Newsletter opt-in
- Video descriptions and pinned comments

**Frequency:**
- Weekly new content releases
- Daily social media engagement
- Bi-weekly newsletter

### For Subject Matter Experts (High Power, High Interest - During Creation)

**Engagement Approach: Manage Closely (During Involvement)**

**Strategies:**
- Clear scope of involvement and expectations
- Recognition and credit for contributions
- Review cycles with reasonable turnaround expectations
- Incorporation of feedback with explanation if not included

**Communication Channels:**
- Direct email or collaboration tools
- Scheduled review meetings
- Shared documentation (Google Docs, notion)

**Frequency:**
- Weekly during active content creation
- As-needed during review cycles
- Monthly check-ins during maintenance phases

## Stakeholder Analysis for Different Content Levels

### Foundation Level Content

**Primary Stakeholder: Complete Beginners**

**Characteristics:**
- No prior knowledge of topic
- May be intimidated by technical content
- Need extensive hand-holding and examples
- Higher likelihood of giving up if confused
- Seeking confidence as much as competence

**Requirements Implications:**
- Extremely clear explanations with no assumed knowledge
- Step-by-step instructions with screenshots
- Frequent check-ins and practice opportunities
- Encouragement and confidence building
- Simple, practical examples before abstract concepts

**Engagement Needs:**
- Responsive support for "basic" questions
- Patient, non-judgmental community
- Celebration of small wins and progress

### Intermediate Level Content

**Primary Stakeholder: Students with Foundation Knowledge**

**Characteristics:**
- Completed prerequisite content or have equivalent experience
- Comfortable with basic concepts and terminology
- Seeking to build on foundation with more complex scenarios
- Can connect concepts independently with guidance
- Want efficiency in learning (less hand-holding)

**Requirements Implications:**
- Build on foundation without re-teaching basics
- Multi-step workflows and integration scenarios
- "Why" in addition to "how"
- Comparison of approaches and trade-offs
- More challenging practice exercises

**Engagement Needs:**
- More sophisticated discussions in community
- Peer learning opportunities
- Clear path to advanced content

### Advanced Level Content

**Primary Stakeholder: Proficient Practitioners**

**Characteristics:**
- Solid intermediate mastery
- Seeking optimization and edge cases
- Want architectural understanding
- Focus on decision-making rationale
- Can adapt patterns to specific needs

**Requirements Implications:**
- Optimization techniques and performance considerations
- Edge case handling and error recovery
- System design and architecture patterns
- Trade-off analysis between approaches
- Production considerations

**Engagement Needs:**
- High-level discussions and debates
- Opportunity to share own experiences
- Advanced challenges and real-world scenarios

### Expert Level Content

**Primary Stakeholder: Advanced Practitioners Building Custom Solutions**

**Characteristics:**
- Advanced proficiency across the domain
- Building custom tools and solutions
- Interested in underlying principles and protocols
- Contributing back to community
- Innovating beyond standard patterns

**Requirements Implications:**
- Design principles and protocol details
- Building from scratch rather than using existing tools
- Production considerations (security, scale, monitoring)
- Extensibility and customization patterns
- Integration with other systems

**Engagement Needs:**
- Peer collaboration opportunities
- Platform for sharing own innovations
- Access to instructor/expert for deep technical discussions

## Stakeholder Register Template

Document all stakeholder analysis information in a stakeholder register.

```markdown
# Stakeholder Register: [Project Name]

## Stakeholder Group: [Name]
**Type:** [Primary/Secondary/External]
**Category:** [Students/Business Decision-Makers/Content Creators/etc.]

### Identification
- **Representative Count:** [Number or range]
- **How Identified:** [Brainstorming/Market Research/etc.]

### Characteristics
- **Technical Level:** [Foundation/Intermediate/Advanced/Expert]
- **Current Role:** [Job title or role description]
- **Learning Goals:** [What they want to achieve]
- **Budget Constraints:** [Price sensitivity, budget authority]
- **Time Availability:** [How much time for learning]
- **Tool Access:** [What tools/platforms they can use]
- **Motivation:** [Why they seek this training]
- **Pain Points:** [Current problems they face]

### Influence Assessment
- **Power Level:** [1-5 rating]
- **Power Sources:** [Budget control, decision authority, network influence, etc.]
- **Interest Level:** [1-5 rating]
- **Interest Drivers:** [Direct benefit, active participation, advocacy potential]
- **Power/Interest Classification:** [Manage Closely/Keep Satisfied/Keep Informed/Monitor]

### Requirements
**Functional:**
- [Requirement 1]
- [Requirement 2]

**Non-Functional:**
- [Requirement 1]
- [Requirement 2]

**Business:**
- [Requirement 1]
- [Requirement 2]

**Priority:** [Must Have/Should Have/Could Have/Won't Have]

### Engagement Strategy
- **Approach:** [Manage Closely/Keep Satisfied/Keep Informed/Monitor]
- **Communication Channels:** [List preferred channels]
- **Communication Frequency:** [How often to communicate]
- **Key Messages:** [What to emphasize with this group]
- **Engagement Activities:** [Specific actions to engage]

### Risks and Issues
- **Risk:** [Potential negative impact]
- **Mitigation:** [How to address]

### Notes
[Additional observations or considerations]
```

## Stakeholder Analysis Tools and Techniques

### Power/Interest Grid

Visual tool for prioritizing stakeholder engagement efforts.

**How to Create:**
1. List all identified stakeholder groups
2. Rate each on Power (1-5) and Interest (1-5)
3. Plot on grid (Power on Y-axis, Interest on X-axis)
4. Divide into four quadrants
5. Apply appropriate engagement strategy to each quadrant

**Example:**
```
High Power  |  Keep Satisfied    |  Manage Closely   |
(Budget)    |  (IT Admin)        |  (Students, SMEs) |
            |                    |                   |
            |--------------------+-------------------|
            |                    |                   |
Low Power   |  Monitor           |  Keep Informed    |
(Public)    |  (Observers)       |  (Free viewers)   |
            +--------------------+-------------------+
            Low Interest              High Interest
```

### Stakeholder Cube

Three-dimensional analysis considering Power, Interest, and Influence.

**Dimensions:**
- **Power:** Authority and resources
- **Interest:** Level of engagement
- **Influence:** Ability to affect others

**Use:** For complex projects with multiple stakeholder groups where network effects matter (e.g., influencers with low direct power but high ability to affect community sentiment).

### Salience Model

Considers three attributes to determine stakeholder priority:
- **Power:** Ability to impose will
- **Legitimacy:** Appropriate and proper relationship
- **Urgency:** Need for immediate attention

**Stakeholder Types:**
- **Definitive:** All three attributes → Highest priority
- **Dominant:** Power + Legitimacy → Manage closely
- **Dependent:** Legitimacy + Urgency → Keep satisfied
- **Dangerous:** Power + Urgency → Keep satisfied, monitor
- **Dormant:** Power only → Monitor
- **Discretionary:** Legitimacy only → Keep informed
- **Demanding:** Urgency only → Monitor

**Application for Educational Content:**
- Students (paying): Definitive (Power through revenue, Legitimacy as customers, Urgency for skill development)
- Business decision-makers: Definitive or Dominant
- Free viewers: Discretionary (Legitimacy as audience)
- Subject matter experts: Dominant (during creation phase)

### Requirements Traceability Matrix

Link requirements to their source stakeholders.

| Requirement ID | Requirement Description | Source Stakeholder | Priority | Status |
|---------------|------------------------|-------------------|----------|--------|
| REQ-001 | Clear learning objectives | Students | Must Have | Met |
| REQ-002 | Practice exercises | Students, Business | Should Have | Met |
| REQ-003 | Certificate of completion | Business | Should Have | Planned |
| REQ-004 | Mobile app | Students | Could Have | Deferred |

**Benefits:**
- Ensures all stakeholder needs considered
- Justifies scope decisions
- Facilitates requirement prioritization
- Enables impact analysis when requirements change

## Integration with Scope Management

Stakeholder analysis directly informs scope decisions.

**Stakeholder Analysis Outputs → Scope Inputs:**

1. **Target Audience Characteristics** → **Content Depth and Technical Level**
   - Beginner stakeholders → Foundation-level scope
   - Advanced stakeholders → Expert-level scope

2. **Stakeholder Requirements** → **In-Scope and Out-of-Scope Topics**
   - High-priority stakeholder needs → In scope
   - Low-priority or low-power stakeholder requests → Deferred or out of scope

3. **Power/Interest Analysis** → **Feature Prioritization**
   - Manage Closely stakeholders → Must Have features
   - Keep Satisfied stakeholders → Should Have features
   - Keep Informed/Monitor stakeholders → Could Have features

4. **Communication Preferences** → **Content Format and Delivery**
   - Video preference → Video-based primary content
   - Text preference → Comprehensive written documentation
   - Interactive preference → Practice exercises and assessments

5. **Learning Goals** → **Learning Objectives**
   - Stakeholder desired outcomes → Specific learning objectives
   - Skill demonstration needs → Success criteria in scope statement

## Continuous Stakeholder Analysis

Stakeholder analysis is not one-time activity. Iterate throughout project lifecycle.

**Initial Analysis (Project Initiation):**
- Identify all stakeholder groups
- Conduct comprehensive characteristics analysis
- Establish baseline requirements
- Create stakeholder register

**Ongoing Analysis (During Production):**
- Monitor stakeholder engagement and feedback
- Track requirement changes
- Adjust engagement strategies based on response
- Update stakeholder register

**Post-Launch Analysis:**
- Evaluate stakeholder satisfaction
- Assess engagement strategy effectiveness
- Identify new stakeholder groups (e.g., unexpected audience segments)
- Plan for next series or content updates

**Triggers for Re-Analysis:**
- Significant scope changes
- New stakeholder groups identified
- Changes in stakeholder power or interest
- Major feedback indicating misaligned requirements
- Market shifts affecting audience needs

## Success Indicators

Effective stakeholder analysis produces:
- Comprehensive stakeholder identification (no surprise groups discovered late)
- Well-understood stakeholder needs and characteristics
- Requirements clearly traced to source stakeholders
- Appropriate engagement strategies for each stakeholder group
- High stakeholder satisfaction with content relevance
- Efficient resource allocation to high-priority stakeholders
- Minimal scope changes due to missed requirements
- Strong adoption and engagement from target stakeholders

---
name: project-management
description: Comprehensive project management skill aligned with PMBOK Guide 7th Edition and PMI Practice Standards. This skill should be used when Claude is helping to initiate, plan, execute, monitor, or close projects, or when applying project management principles, performance domains, and methodologies. Use for project charters, WBS creation, schedule development, risk management, stakeholder engagement, requirements management, and configuration management.
license: Complete terms in LICENSE.txt
---

# Project Management Skill

This skill provides comprehensive project management guidance aligned with the PMBOK® Guide 7th Edition, PMI Practice Standards, and established PM methodologies.

## Purpose

This skill transforms Claude into a specialized project management assistant that applies PMI standards and best practices consistently across all project phases and performance domains. It ensures alignment with the PMBOK Guide 7th Edition's principle-based approach while maintaining compatibility with process-based methodologies from earlier editions.

## When to Use This Skill

Use this skill when:

- Initiating new projects and developing project charters
- Planning project scope, schedule, cost, quality, resources, communications, risk, procurement, or stakeholder engagement
- Creating Work Breakdown Structures (WBS) and defining project deliverables
- Developing project schedules using network diagrams, critical path analysis, or agile methods
- Managing project requirements throughout the life cycle
- Conducting risk assessments and developing risk response strategies
- Executing project work and managing project teams
- Monitoring and controlling project performance using earned value management or other metrics
- Closing projects or phases with proper knowledge transfer and lessons learned
- Tailoring project management approaches to fit organizational context
- Applying configuration management practices
- Managing change in organizations through project delivery
- Selecting and implementing appropriate development approaches (predictive, adaptive, hybrid)

## Core Project Management Principles

The PMBOK Guide 7th Edition defines 12 principles that underpin effective project management. Apply these principles throughout all project activities:

1. **Stewardship** - Act responsibly with integrity and care for the greater good
2. **Team** - Create collaborative environments that enable high performance
3. **Stakeholders** - Engage proactively with stakeholders to manage expectations
4. **Value** - Focus continuously on delivering intended outcomes and benefits
5. **Systems Thinking** - Recognize and respond to system interactions
6. **Leadership** - Demonstrate appropriate leadership behaviors throughout the project
7. **Tailoring** - Adapt the approach based on context and constraints
8. **Quality** - Build quality into processes and deliverables
9. **Complexity** - Navigate complexity through adaptability and resilience
10. **Risk** - Optimize responses to uncertainty and threats/opportunities
11. **Adaptability and Resiliency** - Build in the ability to respond to change
12. **Change** - Enable organizational transformation through structured approaches

## Eight Performance Domains

The PMBOK Guide 7th Edition organizes project management into eight interactive, interdependent performance domains. Address all domains throughout the project life cycle:

### 1. Stakeholder Performance Domain

**Purpose**: Ensure productive stakeholder relationships throughout the project.

**Key Activities**:
- Identify all stakeholders (individuals, groups, organizations affected by or affecting the project)
- Analyze stakeholder characteristics: power, interest, influence, impact
- Prioritize stakeholder engagement based on analysis
- Engage stakeholders through appropriate communication and collaboration methods
- Monitor stakeholder engagement effectiveness and adapt approaches

**Desired Outcomes**:
- Productive working relationships with stakeholders
- Stakeholder agreement with project objectives
- Stakeholders who are supportive of project outcomes
- Increased understanding of potential project benefits and impacts

### 2. Team Performance Domain

**Purpose**: Establish and develop project teams capable of delivering project outcomes.

**Key Activities**:
- Form project teams with appropriate skills and competencies
- Develop shared ownership and collaborative team culture
- Provide appropriate leadership adapted to team needs and context
- Enable team empowerment and accountability
- Build high-performing teams through trust, collaboration, and adaptation

**Leadership Styles to Apply**:
- Laissez-faire: High autonomy for experienced teams
- Transactional: Clear roles and rewards for structured work
- Servant: Support team self-organization (especially agile)
- Transformational: Inspire change and innovation
- Charismatic: Motivate through energy and conviction
- Interactional: Combine multiple approaches as needed

**Desired Outcomes**:
- Shared ownership of project deliverables
- High-performing, collaborative teams
- Applicable leadership skills demonstrated throughout the team

### 3. Development Approach and Life Cycle Performance Domain

**Purpose**: Select and implement appropriate development approaches and life cycle phases.

**Development Approaches**:

**Predictive**:
- Scope, time, and cost determined early
- Detailed upfront planning
- Sequential phase execution
- Use when: Requirements stable, low uncertainty, regulatory compliance needed

**Adaptive (Agile)**:
- Incremental, iterative delivery
- Requirements evolve
- Frequent feedback and adaptation
- Use when: High uncertainty, innovation required, fast feedback needed

**Hybrid**:
- Combine elements of predictive and adaptive
- Tailor based on deliverable characteristics
- Use when: Mixed certainty levels, organizational constraints, multiple deliverable types

**Delivery Cadence**:
- Single delivery: One final deliverable at project end
- Multiple deliveries: Periodic releases at planned intervals
- Periodic deliveries: Frequent iterative releases (sprints, iterations)

**Life Cycle Phases**:
Structure projects into phases with entry/exit criteria aligned to:
- Project start-up and initiation
- Organizing and preparing (planning)
- Carrying out work (executing)
- Monitoring and controlling
- Ending the project or phase (closing)

**Desired Outcomes**:
- Development approaches consistent with project deliverables
- Life cycle phases that connect value delivery from beginning to end
- Phases that facilitate the selected delivery cadence and development approach

### 4. Planning Performance Domain

**Purpose**: Proactively organize, elaborate, and coordinate project work.

**Planning Variables**:

**Deliverables and Requirements**:
- Elicit, analyze, document, and validate requirements
- Define scope and boundaries
- Create requirements traceability matrix
- Establish requirements baseline

**Work Breakdown Structure (WBS)**:
- Decompose scope into manageable work packages
- Organize hierarchically by deliverable or phase
- Define work to 8-80 hour level for control accounts
- Use 100% rule: WBS includes all project work
- Reference: `references/wbs_guidelines.md`

**Estimating**:
- Use appropriate estimation methods (analogous, parametric, three-point, bottom-up)
- Consider precision needs vs. effort required
- Document assumptions and constraints
- Apply contingency reserves for known-unknowns

**Schedule Development**:
- Define activities from WBS work packages
- Sequence activities using precedence relationships
- Estimate activity durations
- Develop schedule using critical path method, critical chain, or agile planning
- Reference: `references/scheduling_guidelines.md`

**Budget and Cost Management**:
- Aggregate cost estimates to establish baseline
- Include management reserves for unknown-unknowns
- Plan for cost monitoring using earned value management
- Reference: `references/estimating_guidelines.md`

**Resource Planning**:
- Identify physical and team resource needs
- Plan resource acquisition and development
- Consider resource constraints and dependencies

**Communication Planning**:
- Identify stakeholder information needs
- Define communication methods, frequency, and responsibilities
- Plan for both push and pull communication

**Procurement Planning**:
- Determine make-or-buy decisions
- Define procurement approach and contract types
- Plan for vendor management

**Desired Outcomes**:
- Project progresses in organized, coordinated, deliberate manner
- Holistic approach to delivering outcomes
- Appropriate planning time for situation
- Information sufficient to manage stakeholder expectations
- Adaptation process for emerging needs

### 5. Project Work Performance Domain

**Purpose**: Establish project processes and manage physical resources effectively.

**Key Activities**:
- Establish project processes (communication, physical resource management, procurement, learning)
- Manage physical resources efficiently
- Work with procurements through bid process and contracting
- Foster learning and knowledge transfer throughout project
- Manage project changes through integrated change control

**Process Management**:
- Define work processes tailored to project needs
- Ensure process conformance and quality
- Balance efficiency with effectiveness
- Enable continuous improvement

**Desired Outcomes**:
- Efficient and effective project performance
- Suitable processes throughout project
- Effective stakeholder communication
- Managed physical resources
- Procurement strategies that deliver value
- Team learning and project knowledge improvements

### 6. Delivery Performance Domain

**Purpose**: Deliver scope and quality that meet project objectives.

**Key Activities**:
- Deliver value incrementally throughout project
- Ensure deliverables meet acceptance criteria and quality requirements
- Focus on both project scope (work to deliver) and product scope (features/functions)
- Conduct quality management through planning, assurance, and control
- Manage subprojects and multiple deliverables
- Align deliveries with stakeholder expectations

**Quality Management**:
- Plan Quality: Define quality standards and metrics
- Manage Quality: Build quality into processes (quality assurance)
- Control Quality: Inspect deliverables and measure results

**Desired Outcomes**:
- Projects contribute to business objectives and strategy
- Projects realize intended outcomes
- Benefits realized in planned time frame
- Clear understanding of requirements
- Stakeholder acceptance and satisfaction with deliverables

### 7. Measurement Performance Domain

**Purpose**: Assess project performance and take corrective actions.

**Key Measurement Areas**:

**Deliverables**:
- Acceptance criteria status
- Delivered value vs. planned value
- Defect rates and quality metrics
- Customer satisfaction

**Baseline Performance**:
- Schedule variance (SV) and schedule performance index (SPI)
- Cost variance (CV) and cost performance index (CPI)
- Scope completion percentage
- Earned value metrics (EV, AC, PV, EAC, ETC, VAC)

**Resources**:
- Planned vs. actual resource utilization
- Resource efficiency and productivity
- Team morale and turnover

**Business Value**:
- Benefits realization tracking
- Return on investment (ROI) calculations
- Value delivered vs. planned

**Stakeholders**:
- Engagement effectiveness
- Satisfaction levels
- Issue and risk trends

**Forecasting**:
- Estimate at Completion (EAC)
- Estimate to Complete (ETC)
- Variance at Completion (VAC)
- To-Complete Performance Index (TCPI)

**Desired Outcomes**:
- Reliable understanding of project status
- Actionable data to facilitate decision making
- Timely actions to keep performance on track
- Achieved project objectives and benefits realization

### 8. Uncertainty Performance Domain

**Purpose**: Navigate uncertainty through risk and opportunity management.

**Risk Management Process**:

1. **Plan Risk Management**
   - Define risk management approach
   - Establish risk thresholds and categories
   - Define roles and responsibilities

2. **Identify Risks**
   - Use brainstorming, checklists, interviews, SWOT analysis
   - Document in risk register
   - Consider both threats and opportunities

3. **Analyze Risks (Qualitative)**
   - Assess probability and impact
   - Use probability-impact matrix
   - Prioritize for further analysis

4. **Analyze Risks (Quantitative)** (when appropriate)
   - Use Monte Carlo simulation, decision trees, sensitivity analysis
   - Calculate expected monetary value (EMV)
   - Inform contingency reserve requirements

5. **Plan Risk Responses**
   - Threats: Avoid, Transfer, Mitigate, Accept
   - Opportunities: Exploit, Share, Enhance, Accept
   - Assign risk owners
   - Define contingency plans and triggers

6. **Implement Risk Responses**
   - Execute planned responses
   - Monitor trigger conditions
   - Activate contingency plans as needed

7. **Monitor Risks**
   - Track identified risks
   - Identify new risks
   - Execute response plans
   - Review risk process effectiveness

**Complexity Considerations**:
- Human behavior complexity: Team dynamics, politics, motivations
- System behavior complexity: Dependencies, interactions, ambiguity
- Ambiguity and emergence: Unknown unknowns, emerging patterns

**Desired Outcomes**:
- Awareness of uncertain environment
- Understanding of threats and opportunities
- Proactive exploration and response to uncertainty
- Improved project performance through risk management
- Realistic cost and schedule objectives based on uncertainty

## Best Practices

1. **Always start with clear objectives** - Ensure project alignment with organizational strategy
2. **Engage stakeholders proactively** - Identify early, analyze thoroughly, communicate consistently
3. **Tailor appropriately** - Adapt processes and artifacts to fit project context
4. **Focus on value delivery** - Prioritize activities that contribute to intended outcomes
5. **Manage uncertainty systematically** - Identify, analyze, and respond to both threats and opportunities
6. **Build quality in** - Prevent defects rather than detecting and correcting them
7. **Enable team performance** - Create collaborative environment with appropriate leadership
8. **Measure what matters** - Select metrics that drive decisions and actions
9. **Document and share knowledge** - Capture lessons learned and transfer knowledge
10. **Close properly** - Ensure formal closure with benefits realization and knowledge transfer

## Citations

All guidance derived from PMI standards:
- PMBOK® Guide – Seventh Edition (2021)
- Requirements Management: A Practice Guide (2016)
- Practice Standard for Work Breakdown Structures – Third Edition (2019)
- Practice Standard for Scheduling – Third Edition (2019)
- Practice Standard for Project Estimating – Second Edition (2019)
- Practice Standard for Project Configuration Management (2007)
- Agile Practice Guide (2017)
- Governance of Portfolios, Programs, and Projects: A Practice Guide (2016)
- Managing Change in Organizations: A Practice Guide (2013)

---
name: scope-management
description: Comprehensive scope management skill for educational content development following PMI standards. This skill should be used when defining video or series scope, preventing scope creep during content production, balancing depth versus breadth, or creating learning objectives for educational deliverables. Augments the project-management skill with specialized workflows for video-based learning content.
license: Complete terms in LICENSE.txt
---

# Scope Management for Educational Content

This skill provides comprehensive scope management workflows specifically adapted for educational video content development. It augments the project-management skill by applying PMI scope management principles to the unique challenges of video-based learning deliverables.

## Purpose

Educational content faces unique scope challenges: balancing comprehensive coverage with digestible video length, matching content depth to audience technical level, and maintaining clear learning objectives while avoiding tangential topics. This skill addresses these challenges through PMI-aligned scope definition, control, and validation processes adapted for educational content production.

## When to Use This Skill

**Primary Use Cases:**
- Defining scope for video series or individual videos
- Creating learning objectives aligned to content scope
- Preventing scope creep during script writing or recording
- Balancing depth versus breadth for target audience level
- Planning content progression across multiple videos or series
- Managing scope changes based on student feedback

**Integration with Project Management:**
- Works with project-management skill for WBS decomposition
- Provides educational content-specific scope templates
- Adapts PMI scope management processes for learning deliverables
- Aligns scope with stakeholder analysis from stakeholder-analysis skill

## Core Scope Workflows

### Workflow 1: Define Series-Level Scope

Establish overall series scope before decomposing to individual videos.

**Process:**
1. Identify target audience and technical level (Foundation, Intermediate, Advanced, Expert)
2. Define series learning objectives (3-5 major outcomes students will achieve)
3. List prerequisites (required knowledge or completed content)
4. Estimate series duration (number of videos, total production time)
5. Create in-scope and out-of-scope topic lists
6. Document dependencies on other series or content

**Reference:** Use Series Scope Statement Template in `/references/pmi_scope_standards.md` under "Templates and Tools"

**Output:** Completed Series Scope Statement defining boundaries and expectations

### Workflow 2: Decompose Series to Video Work Packages

Apply WBS principles to break series scope into manageable video units.

**Process:**
1. Group related topics into thematic modules (Level 2 WBS)
2. Decompose modules into individual video topics (Level 3 WBS - work packages)
3. Ensure each video has single clear learning objective or closely related set
4. Establish logical learning progression across videos
5. Validate each video can be completed in 15-35 minutes
6. Verify work packages can be estimated, assigned, and tracked independently

**Validation Criteria:**
- Each video serves specific learning objective
- Clear prerequisites and dependencies between videos
- Balanced distribution of content complexity
- Appropriate scope for target duration

**Reference:** See "Scope Definition Process > Step 2: Decompose to Video Work Packages" in `/references/pmi_scope_standards.md`

### Workflow 3: Create Individual Video Scope Statements

Define explicit scope for each video work package before scripting.

**Process:**
1. Write specific, measurable learning objectives (what students will be able to DO)
2. List prerequisites (prior knowledge or completed videos required)
3. Define target duration range (e.g., 18-22 minutes)
4. List topics explicitly in scope with brief descriptions
5. List demonstrations or examples to include
6. Define practice exercise scope
7. List topics explicitly out of scope with rationale (deferred to other videos, too advanced, etc.)
8. Define success criteria (how students demonstrate learning)
9. Estimate production effort (scripting, recording, editing, documentation)

**Reference:** Use Video Scope Statement Template in `/references/pmi_scope_standards.md` under "Templates and Tools"

**Output:** Completed Video Scope Statement providing clear boundaries for script development

### Workflow 4: Balance Depth Versus Breadth

Determine appropriate coverage level for each topic within video scope.

**Decision Framework:**
For each potential topic, evaluate:

1. **Go Deep If:**
   - Core concept requiring solid understanding
   - Common source of errors or confusion
   - Foundation for future content
   - High student value per minute of instruction
   - Students need to DO this task independently

2. **Go Wide If:**
   - Survey of related options needed (awareness level sufficient)
   - Students can self-learn details from external resources
   - "Nice to know" context but not critical skill
   - Good reference documentation already exists

3. **Defer If:**
   - Too advanced for current audience level
   - Tangential to current learning objectives
   - Requires additional prerequisites not yet covered
   - Better suited to different video or series

**Application:**
- Apply framework during video scope definition
- Reference during script writing to prevent depth scope creep
- Use to justify scope decisions in documentation

**Reference:** See "Core Scope Principles > Step 4: Balance Depth vs. Breadth" in `/references/pmi_scope_standards.md`

### Workflow 5: Control Scope During Production

Prevent scope creep during script writing and recording.

**Techniques:**

**1. Script Review Against Scope:**
- Compare draft script to defined video scope statement
- Flag content not listed in "In Scope"
- Verify all "In Scope" topics adequately covered
- Check script duration estimate against target range

**Scope Creep Indicators:**
- Script longer than target duration by >20%
- Topics not in original scope statement appearing
- Multiple new learning objectives added during writing
- Content requiring prerequisites not listed
- Explanations going deeper than target audience level

**Response Options:**
- Cut scope-creeping content (most common)
- Split into two videos if both topics valuable
- Defer to future video/series if advanced
- Add to "Further Resources" without detailed coverage

**2. "Just One More Thing" Prevention:**
- Reference written scope during all production activities
- Schedule scope review breaks during script writing
- Timebox content sections during recording
- Maintain "Future Content" list for deferred ideas

**Reference:** See "Scope Control for Series Production" in `/references/pmi_scope_standards.md`

### Workflow 6: Validate Scope Alignment

Verify scope decisions align with learning objectives and audience needs.

**Validation Checkpoints:**

1. **Series Planning Complete:**
   - Review against project objectives from project charter
   - Verify alignment with target audience characteristics
   - Confirm appropriate technical level for audience
   - Validate learning progression across series

2. **Video Scripts Complete:**
   - Review each script against video scope statement
   - Confirm all "In Scope" topics adequately covered
   - Verify no out-of-scope topics included
   - Check learning objectives achievable with content

3. **Production Complete:**
   - Compare actual vs. planned scope
   - Document any scope changes with rationale
   - Analyze scope variance for lessons learned
   - Update future video scopes based on patterns

4. **Student Feedback Received:**
   - Validate scope met student needs and expectations
   - Identify scope gaps (insufficient coverage)
   - Identify scope excess (unnecessary depth)
   - Adjust remaining video scopes accordingly

**Validation Questions:**
- Do learning objectives align with target audience needs?
- Does content depth match audience technical level?
- Are prerequisites clearly defined and accurate?
- Can students achieve stated objectives with this content?
- Is duration appropriate for content complexity?

**Reference:** See "Scope Validation" in `/references/pmi_scope_standards.md`

### Workflow 7: Manage Scope Changes

Handle scope modifications through structured change management.

**Valid Reasons for Scope Change:**
- Student feedback reveals coverage gaps or excess
- Tool/technology changes make content obsolete
- Dependencies discovered requiring additional content
- Market research shows different demand than anticipated
- Production reveals unrealistic time estimates

**Change Process:**
1. **Document Proposed Change:**
   - What scope element will change
   - Why change is necessary
   - How change affects learning objectives

2. **Analyze Impact:**
   - Timeline impact (delays, acceleration)
   - Budget impact (additional resources needed)
   - Quality impact (improvement or compromise)
   - Stakeholder impact (who benefits, who is affected)

3. **Make Decision:**
   - Approve, reject, or modify proposed change
   - Document decision rationale
   - Identify mitigation for negative impacts

4. **Update Documentation:**
   - Update series and video scope statements
   - Adjust production schedule and resource allocation
   - Revise WBS and dependencies
   - Update project charter if series-level change

5. **Communicate Changes:**
   - Notify stakeholders of scope modification
   - Explain rationale and benefits
   - Clarify impact on timeline and deliverables

**Reference:** See "Scope Change Process" and Example 4 in `/references/scope_examples.md`

## Scope for Different Audience Levels

Content depth must match target audience technical sophistication.

### Foundation Level
**Scope Characteristics:**
- Assume no prior knowledge of topic
- Define all technical terms on first use
- Focus on practical application over theory
- Limit complexity and abstraction
- Provide step-by-step procedures
- Include more hand-holding and examples

**Example In-Scope:** "How to create a GitHub repository" with click-by-click instructions
**Example Out-of-Scope:** "Git internals and object storage model"

### Intermediate Level
**Scope Characteristics:**
- Assume foundational knowledge from previous series
- Build on established concepts without re-teaching
- Introduce multi-step workflows
- Balance theory with practice
- Expect students to connect concepts independently
- Cover "why" in addition to "how"

**Example In-Scope:** "Branching strategies for team collaboration" comparing approaches
**Example Out-of-Scope:** "Basic repository creation" (covered in Foundation)

### Advanced Level
**Scope Characteristics:**
- Assume intermediate mastery
- Focus on optimization and edge cases
- Introduce architectural patterns
- Emphasize decision-making rationale
- Cover trade-offs between approaches
- Expect students to adapt patterns to their needs

**Example In-Scope:** "Multi-MCP orchestration patterns" with architecture considerations
**Example Out-of-Scope:** "What is an MCP?" (covered in Intermediate)

### Expert Level
**Scope Characteristics:**
- Assume advanced proficiency
- Focus on building custom solutions from scratch
- Emphasize design principles and architectural decisions
- Include production considerations (security, performance, monitoring)
- Cover system design and integration challenges
- Expect students to extend and innovate

**Example In-Scope:** "Building custom MCP servers" with protocol implementation details
**Example Out-of-Scope:** "Using existing MCPs" (covered in Advanced)

## Common Scope Pitfalls and Prevention

### Pitfall 1: Scope Creep During Production
**Problem:** "Just one more thing" syndrome during scripting or recording leads to videos exceeding target duration and covering unplanned topics.

**Prevention:**
- Reference written scope document during all production
- Schedule scope review breaks during script writing (every 5-10 pages)
- Timebox content sections during recording
- Maintain "Future Content" list for valuable deferred ideas
- Get peer review on script before recording

**Reference:** See "Common Scope Pitfalls > Scope Creep During Production" in `/references/pmi_scope_standards.md`

### Pitfall 2: Insufficient Scope Definition
**Problem:** Vague scope leads to wandering content without clear focus.

**Prevention:**
- Always write explicit, measurable learning objectives
- List specific topics and examples before scripting
- Define success criteria (what students can DO after completing)
- Get peer review on scope before scripting begins
- Use provided templates consistently

### Pitfall 3: Scope Too Broad
**Problem:** Trying to cover too much results in superficial treatment of all topics.

**Prevention:**
- Limit to 3-5 learning objectives per video
- Focus on depth for core concepts
- Defer related topics to other videos in series
- Remember: series provides breadth, individual videos provide depth
- Apply depth vs. breadth decision framework

### Pitfall 4: Scope Too Narrow
**Problem:** Content too simple or incomplete for target audience level.

**Prevention:**
- Validate against target audience needs via stakeholder analysis
- Include sufficient practice opportunities
- Cover edge cases and common errors
- Provide next steps for continued learning
- Review with subject matter expert

## Integration with Other Skills

**Project Management Skill:**
- Scope management provides inputs to WBS decomposition
- Scope statements inform schedule and resource estimates
- Scope control aligns with overall project change management

**Stakeholder Analysis Skill:**
- Stakeholder needs and characteristics drive scope decisions
- Audience technical level determines scope depth
- Stakeholder priorities influence scope trade-offs

**Human Writing Skill:**
- Scope defines content boundaries for script writing
- Learning objectives guide content structure
- Scope control prevents script expansion

**Technical Documentation Skill:**
- Video scope informs supplemental documentation scope
- Documentation follows same in-scope/out-of-scope topics
- Success criteria guide documentation examples and exercises

## Quick Reference

### When Starting New Series
1. Read `/references/pmi_scope_standards.md` section "Scope Definition Process"
2. Use Series Scope Statement Template
3. Identify target audience level and prerequisites
4. Define 3-5 series learning objectives
5. Create in-scope and out-of-scope topic lists

### When Planning Individual Video
1. Reference series scope statement
2. Use Video Scope Statement Template
3. Define specific learning objectives for this video
4. Apply depth vs. breadth decision framework
5. List explicit in-scope and out-of-scope topics

### When Writing Script
1. Reference video scope statement constantly
2. Watch for scope creep indicators
3. Apply "Go Deep or Go Wide" framework to each topic
4. Defer valuable tangents to "Future Content" list

### When Reviewing Content
1. Compare actual content to scope statement
2. Validate all in-scope topics covered adequately
3. Check for out-of-scope topics included
4. Verify learning objectives achievable

### When Student Feedback Arrives
1. Analyze for scope gaps or excess
2. Document proposed scope changes
3. Follow structured change management process
4. Update remaining content scopes based on learnings

## Examples

For detailed scope statement examples from the AI Education Platform project, see `/references/scope_examples.md`:
- Example 1: Series-level scope (GitHub Fundamentals series)
- Example 2: Video-level scope (Collaboration Basics video)
- Example 3: Module-level scope (Capstone project)
- Example 4: Scope change management (GitHub Actions expansion)

## References

**Bundled References:**
- `/references/pmi_scope_standards.md` - Complete PMI scope management standards adapted for educational content
- `/references/scope_examples.md` - Real-world scope statements from AI Education Platform project

**PMI Sources:**
- PMBOK Guide Seventh Edition - Project Performance Domains (Scope management integrated across domains)
- Practice Standard for Work Breakdown Structures, Third Edition - WBS decomposition principles
- Requirements Management: A Practice Guide - Scope verification and requirements traceability

## Success Indicators

Effective scope management produces:
- Clear, specific learning objectives for every video
- Consistent video durations within target ranges
- Minimal scope creep during production
- High student satisfaction with content coverage
- Balanced depth and breadth appropriate to audience
- Efficient production (minimal rework due to scope issues)
- Clear progression across video series

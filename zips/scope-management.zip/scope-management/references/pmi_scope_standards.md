# PMI Scope Management Standards

## Overview

Scope management for educational content follows PMI principles adapted for video-based learning deliverables. The goal is to define what content gets included in each video and series while preventing scope creep during production.

**Source:** PMBOK Guide Seventh Edition; Practice Standard for Work Breakdown Structures, Third Edition

## Core Scope Principles for Educational Content

### 1. Define Clear Boundaries

Scope defines what IS and IS NOT included in a deliverable. For video content:

**In Scope:**
- Learning objectives explicitly stated
- Topics listed in content outline
- Prerequisites and follow-up content
- Practice exercises and assessments
- Supporting documentation

**Out of Scope:**
- Tangential topics not serving learning objectives
- Advanced concepts beyond target audience level
- Topics covered in other series/videos
- Features or tools not yet available
- Content requiring extensive prerequisites

### 2. Align to Learning Objectives

Every piece of content must serve at least one learning objective. If content doesn't directly contribute to what students should be able to DO after completing the video, it's scope creep.

**Test Questions:**
- Does this content help students achieve a stated learning objective?
- Can students demonstrate this skill after watching?
- Is this the right video for this content, or should it go elsewhere?

### 3. Respect Target Audience Level

Content depth must match audience technical level and prerequisites.

**Foundation Level:**
- Assume no prior knowledge
- Define all technical terms
- Focus on practical application
- Limit complexity and abstraction

**Intermediate Level:**
- Assume foundational knowledge from previous series
- Build on established concepts
- Introduce multi-step workflows
- Balance theory with practice

**Advanced Level:**
- Assume intermediate mastery
- Focus on optimization and edge cases
- Introduce architectural patterns
- Emphasize decision-making rationale

**Expert Level:**
- Assume advanced proficiency
- Focus on building custom solutions
- Emphasize design principles and trade-offs
- Include production considerations

### 4. Balance Depth vs. Breadth

Educational content faces a constant tension: go deep on fewer topics or cover more topics with less depth.

**Depth Indicators (Go Deep):**
- Core concept requiring solid understanding
- Common source of errors or confusion
- Foundation for future content
- High student value per minute of instruction

**Breadth Indicators (Go Wide):**
- Survey of related options
- Awareness-level coverage sufficient
- Students can self-learn details later
- Reference material available

**Decision Framework:**
For each topic, ask:
1. Is this foundational knowledge? → Go deep
2. Will students need to DO this? → Go deep
3. Is this "nice to know" context? → Go wide or defer
4. Are there good external resources? → Go wide with references

## Scope Definition Process

### Step 1: Establish Series Scope

Define the overall scope for the series before individual videos.

**Required Artifacts:**
1. Series learning objectives (3-5 major outcomes)
2. Target audience definition (technical level, prerequisites)
3. Series prerequisites (what must be completed first)
4. Series duration estimate (number of videos, total time)
5. In-scope and out-of-scope topics list

### Step 2: Decompose to Video Work Packages

Break series scope into individual video topics using WBS principles.

**Work Package Criteria:**
- Single clear learning objective or closely related set
- Can be estimated (duration, production effort)
- Can be assigned and tracked independently
- Logically ordered in learning progression
- Completable in 15-35 minutes of video

**WBS Level Structure:**
```
Level 1: Series
Level 2: Modules (thematic groups of videos)
Level 3: Individual Videos (work packages)
```

### Step 3: Define Individual Video Scope

For each video work package, create a scope statement:

**Video Scope Template:**
```
Video Title: [Specific, descriptive]
Learning Objectives:
- [Action verb] [specific skill/knowledge]
- [Action verb] [specific skill/knowledge]
- [Action verb] [specific skill/knowledge]

Prerequisites:
- [Required prior knowledge or completed videos]

Duration: [Target range, e.g., 18-22 minutes]

In Scope:
- [Specific topics/concepts to cover]
- [Demonstration or example 1]
- [Demonstration or example 2]
- [Practice exercise topic]

Out of Scope:
- [Related topics deferred to other videos]
- [Advanced variations not covered]
- [Common misconceptions or tangents to avoid]

Success Criteria:
- Students can [demonstrate specific skill]
- Students can [answer specific questions]
- Students can [complete specific exercise]
```

### Step 4: Script Review Against Scope

During script development, constantly verify against defined scope.

**Scope Creep Indicators:**
- Script longer than target duration by >20%
- Topics not listed in "In Scope"
- Multiple learning objectives added during writing
- Content requiring additional prerequisites
- Explanations going deeper than target audience level

**Response Options:**
1. Cut the scope-creeping content
2. Split into two videos if both topics are valuable
3. Defer to future video/series if advanced
4. Add to "Further Resources" without detailed coverage

## Scope Control for Series Production

### Progressive Refinement

Scope understanding improves as content is created. Early videos inform later video scopes.

**Feedback Loop:**
1. Create video based on scope definition
2. Review actual production time vs estimate
3. Gather student feedback on completeness
4. Refine remaining video scopes accordingly
5. Update series-level scope if patterns emerge

### Scope Change Process

Sometimes scope must change. Follow structured change management:

**Valid Reasons for Scope Change:**
- Student feedback reveals gaps in coverage
- Tool/technology changes make content obsolete
- Dependencies discovered requiring additional content
- Market research shows different demand

**Change Documentation:**
1. Document proposed scope change
2. Analyze impact on timeline, budget, quality
3. Identify affected videos/series
4. Get stakeholder approval
5. Update all scope documentation
6. Communicate changes to students

### Scope Validation

Verify scope decisions align with project goals:

**Validation Checkpoints:**
- Series planning complete → Review against project objectives
- Video scripts complete → Review against series scope
- Production complete → Review actual vs planned scope
- Student feedback received → Validate scope met needs

**Validation Questions:**
- Do learning objectives align with target audience needs?
- Does content depth match audience technical level?
- Are prerequisites clearly defined and accurate?
- Can students achieve stated objectives with this content?
- Is duration appropriate for content complexity?

## Common Scope Pitfalls

### 1. Scope Creep During Production

**Problem:** "Just one more thing" syndrome during scripting or recording.

**Prevention:**
- Reference written scope document during all production
- Schedule scope review breaks during script writing
- Timebox content sections during recording
- Defer valuable ideas to "Future Content" list

### 2. Insufficient Scope Definition

**Problem:** Vague scope leads to wandering content.

**Prevention:**
- Always write explicit learning objectives
- List specific topics and examples before scripting
- Define success criteria (what students can DO)
- Get peer review on scope before scripting

### 3. Scope Too Broad

**Problem:** Trying to cover too much, resulting in superficial treatment.

**Prevention:**
- Limit to 3-5 learning objectives per video
- Focus on depth for core concepts
- Defer related topics to other videos
- Remember: series provides breadth, videos provide depth

### 4. Scope Too Narrow

**Problem:** Content too simple or incomplete for target audience.

**Prevention:**
- Validate against target audience needs
- Include sufficient practice opportunities
- Cover edge cases and common errors
- Provide next steps for continued learning

## Templates and Tools

### Video Scope Statement Template

Use this template for every video:

```markdown
# Video Scope Statement: [Video Title]

## Metadata
- Series: [Series Name]
- Module: [Module Name]
- Order: [Position in series]
- Level: [Foundation/Intermediate/Advanced/Expert]
- Target Duration: [15-35 minutes]

## Learning Objectives
After completing this video, students will be able to:
1. [Action verb] [specific skill/knowledge]
2. [Action verb] [specific skill/knowledge]
3. [Action verb] [specific skill/knowledge]

## Prerequisites
Students must have:
- [Completed video/series]
- [Technical knowledge/tool]
- [Installed software/tool]

## In Scope
Topics explicitly covered:
1. [Topic 1 with brief description]
2. [Topic 2 with brief description]
3. [Topic 3 with brief description]

Demonstrations/Examples:
1. [Example 1]
2. [Example 2]

Practice Exercise:
- [Exercise description]

## Out of Scope
Topics explicitly NOT covered:
1. [Topic deferred to other video with reason]
2. [Advanced variation with reason]
3. [Related topic with reason]

## Success Criteria
Students can demonstrate learning by:
1. [Completing specific task]
2. [Answering specific questions]
3. [Explaining specific concept]

## Estimated Effort
- Script: [X hours]
- Recording: [X hours]
- Editing: [X hours]
- Documentation: [X hours]
```

### Series Scope Statement Template

```markdown
# Series Scope Statement: [Series Name]

## Overview
[2-3 sentence series description]

## Target Audience
- Technical Level: [Foundation/Intermediate/Advanced/Expert]
- Prerequisites: [Required knowledge/skills]
- Student Persona: [Brief description of ideal student]

## Series Learning Objectives
After completing this series, students will be able to:
1. [Major skill/capability 1]
2. [Major skill/capability 2]
3. [Major skill/capability 3]
4. [Major skill/capability 4]
5. [Major skill/capability 5]

## Series Structure
- Total Videos: [Number]
- Free Videos: [Number]
- Premium Videos: [Number]
- Total Duration: [Estimated time]
- Production Timeline: [Weeks/months]

## Content Modules
### Module 1: [Name]
- Videos: [List]
- Focus: [Brief description]

### Module 2: [Name]
- Videos: [List]
- Focus: [Brief description]

## In Scope (Series Level)
Major topics covered:
1. [Topic area 1]
2. [Topic area 2]
3. [Topic area 3]

## Out of Scope (Series Level)
Topics explicitly deferred:
1. [Topic → Reason/Where it belongs]
2. [Topic → Reason/Where it belongs]
3. [Topic → Reason/Where it belongs]

## Dependencies
- Prerequisite Series: [List]
- Follow-up Series: [List]
- Related Series: [List]

## Success Metrics
- Completion Rate Target: [%]
- Satisfaction Score Target: [Score]
- Skill Demonstration: [Assessment method]
```

## Integration with Project Management

Scope management integrates with other PM performance domains:

**Stakeholder Engagement:** Scope derives from stakeholder needs analysis
**Planning:** Scope informs schedule and resource allocation
**Project Work:** Scope guides daily production decisions
**Delivery:** Scope defines completion criteria
**Measurement:** Scope provides baseline for variance analysis
**Uncertainty:** Scope changes respond to identified risks
